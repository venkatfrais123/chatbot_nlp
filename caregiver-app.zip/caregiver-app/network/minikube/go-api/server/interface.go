package server

// Service ..
type Service interface {
	Init(port int) error
	Start()
}

// NewServer ..
func NewServer() Service {
	return &Server{}
}
