/*{
	"patientID": "1",
	"appointmentID": "1"
} */

package appointments

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"

	"github.com/gorilla/mux"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

// QueryAll ...
func QueryAll(w http.ResponseWriter, r *http.Request) {

	UserID := mux.Vars(r)["UserID"]
	Orgname := mux.Vars(r)["Orgname"]

	if Orgname == "providerorg" {
		org = "provider"
	} else if Orgname == "caregiverorg" {
		org = "caregiver"
	} else if Orgname == "patientorg" {
		org = "patient"
	} else {
		fmt.Println("Invalid Argument")
		w.Write([]byte(string("Invalid Organization Name!!")))
	}

	ccpEnv := os.Getenv("HYPERLEDGER_CONFIG_PATH")
	ccpPath := filepath.Join(
		ccpEnv,
		"config_"+org+".yaml",
	)

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH")
	walletPath := filepath.Join(walletEnv, org)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mainchannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")

	//node
	//result, err := contract.EvaluateTransaction("listAppointment", queryAppointment.PatientID, queryAppointment.AppointmentID)
	//go
	result, err := contract.EvaluateTransaction("ListAllApps")
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to submit transaction!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
