/*{
	"firstName": "Mark",
	"lastName": "Ruffalo",
	"email": "mark.r@abc.com",
	"phone": "987654",
	"address1": "12, Whittakers Rd",
	"address2": "Cadbury colony",
	"city": "Mason",
	"state": "OH",
	"zip": "123",
	"providerID": "1",
	"providerType": "knee",
	"institutionName": "ins1",
	"institutionPhone": "123",
	"institutionEmail": "ins1@ab.com",
	"insaddress1": "ins1ad1",
	"insaddress2": "ins1ad2",
	"inscity": "Mason",
	"insstate": "OH",
	"inszip": "2132",
	"userID": "pro1"
} */

package providers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"

	"github.com/gorilla/mux"

	"caregiver-app/network/minikube/go-api/models"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

// ProviderUpdate ..
type ProviderUpdate struct {
	models.Person
	ProviderID       string `json:"providerID"`
	ProviderType     string `json:"providerType"`
	InstitutionName  string `json:"institutionName"`
	InstitutionPhone string `json:"institutionPhone"`
	InstitutionEmail string `json:"institutionEmail"`
	models.Address
}

// Update ..
func Update(w http.ResponseWriter, r *http.Request) {
	var newProvider ProviderUpdate

	UserID := mux.Vars(r)["UserID"]

	//orgname := "providerorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &newProvider)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(newProvider)

	fmt.Println("Provider: ", newProvider)
	fmt.Println("Pro Details: ", UserID)

	ccpEnv := os.Getenv("HYPERLEDGER_CONFIG_PATH")
	ccpPath := filepath.Join(
		ccpEnv,
		"config_provider.yaml",
	)

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH")
	walletPath := filepath.Join(walletEnv, "provider")

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mainchannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("providercontract")

	personresponse, err := json.Marshal(newProvider.Person)
	if err != nil {
		fmt.Println("Error: ", err)
	}

	addresponse, err := json.Marshal(newProvider.Address)
	if err != nil {
		fmt.Println("Error: ", err)
	}

	result, err := contract.SubmitTransaction("UpdateProvider", UserID, string(personresponse), newProvider.ProviderID, newProvider.ProviderType, newProvider.InstitutionName, newProvider.InstitutionPhone, newProvider.InstitutionEmail, string(addresponse))
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
