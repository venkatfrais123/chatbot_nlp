/*{
	"userID": "pro1",
	"providerID": "1"
} */

package providers

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"

	"github.com/gorilla/mux"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

// QueryPro ...
func QueryPro(w http.ResponseWriter, r *http.Request) {

	UserID := mux.Vars(r)["UserID"]
	//ProviderID := mux.Vars(r)["ProviderID"]

	//var queryProvider QueryDetails
	//orgname := "providerorg"

	ccpEnv := os.Getenv("HYPERLEDGER_CONFIG_PATH")
	ccpPath := filepath.Join(
		ccpEnv,
		"config_provider.yaml",
	)

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH")
	walletPath := filepath.Join(walletEnv, "provider")

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mainchannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("providercontract")

	result, err := contract.EvaluateTransaction("ListProvider", UserID)
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		////os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
