package users

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type usersignup struct {
	UserID  string `json:"userid"`
	Orgname string `json:"orgname"`
}

type allUsers []usersignup

// Users ..
var Users = allUsers{}

var org = ""
var orgmsp = ""

// Index ..
func Index(w http.ResponseWriter, r *http.Request) {
	var newUser usersignup

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details")
	}

	json.Unmarshal(reqBody, &newUser)
	Users = append(Users, newUser)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(newUser)

	fmt.Println(newUser.UserID)
	fmt.Println(newUser.Orgname)

	/*err1 := os.Setenv("DISCOVERY_AS_LOCALHOST", "true")
	if err1 != nil {
		log.Fatalf("Error setting Discovery: %v", err1)
	}*/

	if newUser.Orgname == "providerorg" {
		//org = "org1"
		orgmsp = "provider"
	} else if newUser.Orgname == "caregiverorg" {
		//org = "org2"
		orgmsp = "caregiver"
	} else if newUser.Orgname == "patientorg" {
		//org = "org4"
		orgmsp = "patient"
	} else {
		fmt.Println("Invalid Argument")
	}

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH") /*filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		newUser.Orgname,
		"identity",
		"user",
		newUser.UserID,
		"wallet",
	)*/

	walletPath := filepath.Join(walletEnv, orgmsp)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte("Failed to create wallet!!"))
	}

	if !wallet.Exists(newUser.UserID) {
		err = populateWallet(wallet, newUser.UserID)
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte("User Signed Up!!"))
		//json.NewEncoder(w).Encode(newUser)
		if err != nil {
			log.Fatalf("Failed to populate wallet contents: %v", err)
			//os.Exit(1)
			w.Write([]byte("Failed to populate wallet contents!!"))
		}
	} else {
		fmt.Println("An user with same identity " + newUser.UserID + " exists for " + newUser.Orgname + "")
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte("Already Exists!!"))
	}
}

func populateWallet(wallet *gateway.Wallet, userId string) error {
	log.Println("Populating Wallet")
	credEnv := os.Getenv("HYPERLEDGER_CRED_PATH")
	credPath := filepath.Join(
		credEnv,
		"peerOrganizations",
		orgmsp,
		"users",
		"User1@"+orgmsp+"",
		"msp",
	)

	certPath := filepath.Join(credPath, "signcerts", "User1@"+orgmsp+"-cert.pem")

	cert, err := ioutil.ReadFile(filepath.Clean(certPath))
	if err != nil {
		return err
	}

	keyDir := filepath.Join(credPath, "keystore", "pvt-cert.pem")
	//keyPath := filepath.Join(keyDir, "priv_sk")
	key, err := ioutil.ReadFile(filepath.Clean(keyDir))
	if err != nil {
		return err
	}

	fmt.Println("User ID: ", userId)
	fmt.Println("MSP: ", orgmsp)
	fmt.Println("Cred Path: ", credPath)
	fmt.Println("Cert Path: ", certPath)
	fmt.Println("Key Path: ", keyDir)

	identity := gateway.NewX509Identity(orgmsp, string(cert), string(key))

	return wallet.Put(userId, identity)
}
