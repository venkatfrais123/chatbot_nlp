/*{
	"patientID": "1",
	"appointmentID": "1",
	"updateDate": "12/11/2020",
	"acceptedByCaregiver": "true",
	"cancellationReason": "NA"
	"userID": "cg1"
}*/

package caregivers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type appointmentdetails struct {
	PatientID           string `json:"patientID"`
	AppointmentID       string `json:"appointmentID"`
	UpdateDate          string `json:"appointmentUpdateDate"`
	AcceptedByCaregiver string `json:"acceptedByCaregiver"`
	CancellationReason  string `json:"cancellationReason"`
	UserID              string `json:"userID"`
}

// Appointmentupdate ...
func Appointmentupdate(w http.ResponseWriter, r *http.Request) {
	var appointment appointmentdetails
	//orgname := "caregiverorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &appointment)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(appointment)

	fmt.Println("appointment: ", appointment)
	fmt.Println("CG Details: ", appointment.UserID)

	ccpEnv := os.Getenv("HYPERLEDGER_CONFIG_PATH")
	ccpPath := filepath.Join(
		ccpEnv,
		"config_caregiver.yaml",
	)

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH")
	walletPath := filepath.Join(walletEnv, "caregiver")

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, appointment.UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mainchannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")

	result, err := contract.SubmitTransaction("UpdateAppointmentCg", appointment.PatientID, appointment.AppointmentID, appointment.UpdateDate, appointment.AcceptedByCaregiver, appointment.CancellationReason)
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
