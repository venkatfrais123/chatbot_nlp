/*{
	"userID": "cg1",
	"personFirstName": "Vincent",
	"personLastName": "Don",
	"personEmail": "vincent.d@abc.com",
	"personPhone": "123443",
	"personAddress1": "12, Holiday st.",
	"personAddress2": "Henry's Ave",
	"personCity": "Mason",
	"personState": "OH",
	"personZip": "123",
	"caregiverID": "1"
} */

package caregivers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"

	"github.com/gorilla/mux"

	"caregiver-app/network/minikube/go-api/models"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

// CaregiverUpdate ..
type CaregiverUpdate struct {
	models.Person
	CaregiverID string `json:"caregiverID"`
}

//Update ..
func Update(w http.ResponseWriter, r *http.Request) {
	var newCaregiver CaregiverUpdate

	UserID := mux.Vars(r)["UserID"]

	//orgname := "caregiverorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &newCaregiver)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(newCaregiver)

	fmt.Println("Caregiver: ", newCaregiver)
	fmt.Println("CG Details: ", UserID)

	ccpEnv := os.Getenv("HYPERLEDGER_CONFIG_PATH")
	ccpPath := filepath.Join(
		ccpEnv,
		"config_caregiver.yaml",
	)

	walletEnv := os.Getenv("HYPERLEDGER_WALLET_PATH")
	walletPath := filepath.Join(walletEnv, "caregiver")

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))

	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mainchannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("caregivercontract")

	personresponse, err := json.Marshal(newCaregiver.Person)
	if err != nil {
		fmt.Println("Error: ", err)
	}

	result, err := contract.SubmitTransaction("UpdateCaregiver", UserID, string(personresponse), newCaregiver.CaregiverID)
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
