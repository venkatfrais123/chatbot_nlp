package main

import "caregiver-app/network/minikube/go-api/server"

func main() {
	s := server.NewServer()

	if err := s.Init(4000); err != nil {
		panic(err)
	}

	s.Start()
}
