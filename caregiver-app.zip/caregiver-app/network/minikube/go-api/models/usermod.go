package models

type Person struct {
	PersonFirstName string `json:"personFirstName"`
	PersonLastName  string `json:"personLastName"`
	PersonEmail     string `json:"personEmail"`
	PersonPhone     string `json:"personPhone"`
	PersonAddress1  string `json:"personAddress1"`
	PersonAddress2  string `json:"personAddress2"`
	PersonCity      string `json:"personCity"`
	PersonState     string `json:"personState"`
	PersonZip       string `json:"personZip"`
}

type Address struct {
	Address1 string `json:"insaddress1"`
	Address2 string `json:"insaddress2"`
	City     string `json:"inscity"`
	State    string `json:"insstate"`
	Zip      string `json:"inszip"`
}
