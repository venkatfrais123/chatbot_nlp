## K8S Setup

minikube start

eval $(minikube docker-env)

kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v0.41.2/deploy/static/provider/cloud/deploy.yaml => For Ingress/Nginx enabling. Once done, `minikube tunnel` for exposing it. 

---

kubectl apply -f network/minikube/storage/pvc.yaml

kubectl apply -f network/minikube/storage/tests

`
kubectl exec -it $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//") -- mkdir -p /host/files/scripts
kubectl exec -it $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//") -- mkdir -p /host/files/chaincode

kubectl cp ./scripts $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
kubectl cp ./network/minikube/configtx.yaml $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
kubectl cp ./network/minikube/config_patient.yaml $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
kubectl cp ./network/minikube/config_provider.yaml $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
kubectl cp ./network/minikube/config_caregiver.yaml $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
//node
kubectl cp ./core-files/organization/patientorg/contract $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files/chaincode
//go
kubectl cp ./network/contract/appointment $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files/chaincode
kubectl cp ./network/contract/caregiver $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files/chaincode
kubectl cp ./network/contract/patient $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files/chaincode
kubectl cp ./network/contract/provider $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files/chaincode
kubectl cp ./network/bin $(kubectl get pods -o=name | grep example1 | sed "s/^.\{4\}//"):/host/files
`

`
kubectl apply -f network/minikube/cas
`

Bash into any one container to perform below
...
cd /host/files

rm -rf orderer channels
mkdir -p orderer channels

bin/configtxgen -profile OrdererGenesis -channelID syschannel -outputBlock ./orderer/genesis.block
bin/configtxgen -profile MainChannel -outputCreateChannelTx ./channels/mainchannel.tx -channelID mainchannel
bin/configtxgen -profile MainChannel -outputAnchorPeersUpdate ./channels/patient-anchors.tx -channelID mainchannel -asOrg patient
bin/configtxgen -profile MainChannel -outputAnchorPeersUpdate ./channels/provider-anchors.tx -channelID mainchannel -asOrg provider
bin/configtxgen -profile MainChannel -outputAnchorPeersUpdate ./channels/caregiver-anchors.tx -channelID mainchannel -asOrg caregiver
```

# Starting orderers

kubectl apply -f network/minikube/orderers


# Starting peers

kubectl apply -f network/minikube/orgs/patient/couchdb
kubectl apply -f network/minikube/orgs/provider/couchdb
kubectl apply -f network/minikube/orgs/caregiver/couchdb

kubectl apply -f network/minikube/orgs/patient/
kubectl apply -f network/minikube/orgs/provider/
kubectl apply -f network/minikube/orgs/caregiver/

kubectl apply -f network/minikube/orgs/patient/cli
kubectl apply -f network/minikube/orgs/provider/cli
kubectl apply -f network/minikube/orgs/caregiver/cli

---

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel create -c mainchannel -f ./channels/mainchannel.tx -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'cp mainchannel.block ./channels/'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel join -b channels/mainchannel.block'

sleep 5

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel update -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem -c mainchannel -f channels/patient-anchors.tx'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel update -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem -c mainchannel -f channels/provider-anchors.tx'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer channel update -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem -c mainchannel -f channels/caregiver-anchors.tx'
```
#worked
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer chaincode invoke -C mainchannel -n appointmentcontract -c '\''{"Args":["createPatient","user1","pat1","1","AHC","pro1","pro1name","cg1","cg1name","{\"firstName\": \"tony\", \"lastName\": \"stark\", \"email\": \"tony.s@abc.com\", \"phone\": \"1232\", \"address1\": \"Addr1\", \"address2\": \"add2\", \"city\": \"City1\", \"state\": \"TN\", \"zip\": \"123\"}"]}'\'' -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem'


kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer chaincode query -C mainchannel -n appointmentcontract -c '\''{"Args":["ListPatient","pat1","1"]}'\'' -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem'
```

------------------------
# Chaincode GO

1. Packaging Chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package appointment.tar.gz --path /opt/gopath/src/appointment --lang golang --label appointment_1'

2. Install the chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz &> appointment.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz &> appointment.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz &> appointment.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install appointment.tar.gz'

3. Approve for my org

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name appointmentcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 appointment.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name appointmentcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 appointment.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name appointmentcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 appointment.txt | awk '\''NF>1{print $NF}'\'')'

4. Commit

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode commit -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name appointmentcontract --version 1.0 --sequence 1'

# Repeating the same for other chaincodes

# Patient

1. Packaging Chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package patient.tar.gz --path /opt/gopath/src/patient --lang golang --label patient_1'

2. Install the chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz &> patient.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz &> patient.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz &> patient.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install patient.tar.gz'

3. Approve for my org

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name patientcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 patient.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name patientcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 patient.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name patientcontract --version 1.0 --sequence 1 --package-id $(tail -n 1 patient.txt | awk '\''NF>1{print $NF}'\'')'

4. Commit

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode commit -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name patientcontract --version 1.0 --sequence 1'

# Caregiver

1. Packaging Chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package caregiver.tar.gz --path /opt/gopath/src/caregiver --lang golang --label caregiver_1'

2. Install the chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz &> caregiver.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz &> caregiver.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz &> caregiver.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install caregiver.tar.gz'

3. Approve for my org

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name caregivercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 caregiver.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name caregivercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 caregiver.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name caregivercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 caregiver.txt | awk '\''NF>1{print $NF}'\'')'

4. Commit

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode commit -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name caregivercontract --version 1.0 --sequence 1'

# Provider

1. Packaging Chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode package provider.tar.gz --path /opt/gopath/src/provider --lang golang --label provider_1'

2. Install the chaincodes

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz &> provider.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz &> provider.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz &> provider.txt'
kubectl exec -it $(kubectl get pods -o=name | grep cli-peer1-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode install provider.tar.gz'

3. Approve for my org

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name providercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 provider.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-provider-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name providercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 provider.txt | awk '\''NF>1{print $NF}'\'')'

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-caregiver-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode approveformyorg -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name providercontract --version 1.0 --sequence 1 --package-id $(tail -n 1 provider.txt | awk '\''NF>1{print $NF}'\'')'

4. Commit

kubectl exec -it $(kubectl get pods -o=name | grep cli-peer0-patient-deployment | sed "s/^.\{4\}//") -- bash -c 'peer lifecycle chaincode commit -o orderer0-service:7050 --tls --cafile=/etc/hyperledger/orderers/msp/tlscacerts/orderers-ca-service-7054.pem --channelID mainchannel --name providercontract --version 1.0 --sequence 1'

------------------------

Dockerizing API

docker build -t venkatnm/booking-go-api:latest -f ./go-api/Dockerfile ./go-api

docker push venkatnm/booking-go-api:latest



----


