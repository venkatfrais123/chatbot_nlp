import React from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
    Box,
    Grid,
    Card,
    TextField,
    CardContent,
    Checkbox,
    Avatar,
    Typography,
    Button,
    Drawer,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    FormControl,
    FormControlLabel,
    FormHelperText,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Switch,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TablePagination,
    TableRow,
    LinearProgress,
    Tooltip,
    withStyles
} from '@material-ui/core';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import VisibilityIcon from '@material-ui/icons/Visibility';
import CancelIcon from '@material-ui/icons/Cancel';
import ArrowBackIcon from '@material-ui/icons/ArrowBackIos';
import AlarmIcon from '@material-ui/icons/Alarm';
import Schedule from '@material-ui/icons/Schedule';
import Update from '@material-ui/icons/Update';
import { DateRange } from 'react-date-range';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interaction from '@fullcalendar/interaction';
import bootstrapPlugin from '@fullcalendar/bootstrap';
import dayListPlugin from '@fullcalendar/list';
import AddIcon from '@material-ui/icons/Add';
import moment from 'moment';
import { getInitials, convertResponseToAppointmentVO, filterAppointmentByDate } from '../utils/helper';
import { fetchAllPatientsAPI, fetchAllCaregiversAPI, fetchAllProvidersAPI, fetchAppointmentsAPI, createAppointmentAPI, updateAppointmentAPI } from "../utils/service";
import { connect } from 'react-redux';

const providerMap = new Map([
    ["appointmentStart", "Appointment Start is required"],
    ["appointmentEnd", "Appointment End is required"],
    ["patientID", "Patient is required"],
    ["appointmentType", "Appointment Type is required"],
    ["appointmentDescription", "Appointment Description is required"]
]);

const patientMap = new Map([
    ["appointmentStart", "Appointment Start is required"],
    ["appointmentEnd", "Appointment End is required"],
    ["appointmentType", "Appointment Type is required"],
    ["appointmentDescription", "Appointment Description is required"],
    ["providerID", "Provider is required"]
]);

const caregiverMap = new Map([
    ["appointmentStart", "Appointment Start is required"],
    ["appointmentEnd", "Appointment End is required"],
    ["patientID", "Patient is required"],
    ["appointmentType", "Appointment Type is required"],
    ["appointmentDescription", "Appointment Description is required"],
    ["providerID", "Provider is required"]
]);

const CompletionLinearProgress = withStyles((theme) => ({
    root: {
        height: 4
    },
    colorPrimary: {
        backgroundColor: theme.palette.grey[theme.palette.type === 'light' ? 200 : 700]
    },
    bar: {
        backgroundColor: '#00cc00'
    }
}))(LinearProgress);

const CancelledLinearProgress = withStyles((theme) => ({
    root: {
        height: 4
    },
    colorPrimary: {
        backgroundColor: theme.palette.grey[theme.palette.type === 'light' ? 200 : 700]
    },
    bar: {
        backgroundColor: 'red'
    }
}))(LinearProgress);

const PendingLinearProgress = withStyles((theme) => ({
    root: {
        height: 4
    },
    colorPrimary: {
        backgroundColor: theme.palette.grey[theme.palette.type === 'light' ? 200 : 700]
    },
    bar: {
        backgroundColor: '#1a90ff'
    }
}))(LinearProgress);

const accepted = 'Accepted';
const rejected = 'Rejected';
const created = 'Created';
const update = 'Update';
const disableGridStyle = { opacity: 0.45, border: '0.1px solid gray' };

class Appointment extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isActive: true,
            user: this.props.user,
            userType: this.props.user.userType,
            userId: this.props.user.userID,
            pastAppointments: 0,
            disableFields: true,
            upcomingAppointments: 0,
            scheduledAppointments: 0,
            pendingAppointments: 0,
            anchor: false,
            calendarView: false,
            startRecord: 0,
            endRecord: 10,
            limit: 10,
            page: 0,
            acceptModal: false,
            rejectModal: false,
            expanded: 'panel1',
            calendarEvents: [],
            dateSelection: [{
                startDate: new Date(),
                endDate: null,
                key: 'selection'
            }],
            usersList: [],
            appointmentDetails: {},
            enableButtons: false,
            appointmentStartError: false, appointmentStartErrorText: "",
            appointmentEndError: false, appointmentEndErrorText: "",
            purposeError: false, purposeErrorText: "",
            patientIDError: false, patientIDErrorText: "",
            caregiverIDError: false, caregiverIDErrorText: "",
            providerIDError: false, providerIDErrorText: "",
            appointmentTypeError: false, appointmentTypeErrorText: "",
            appointmentDescriptionError: false, appointmentDescriptionErrorText: "",
            emailError: false, emailErrorText: "",
            memberIDError: false, memberIDErrorText: "",
            memberOrganizationError: false, memberOrganizationErrorText: "",
            cancellationReasonError: false, cancellationReasonErrorText: "",
            appointments: [],
            appointmentsByMe: false,
            pendingAppointmentsList: [],
            bookingTimeWarningMsg: '',
            providerScheduledTimings: [],
            showPendingAppointments: false,
            filteredAppointments: [],
            caregiverMap: new Map(),
            providerMap: new Map(),
            patientMap: new Map()
        };

        this.filterAppointments = this.filterAppointments.bind(this);
        this.resetAppointmentDetails = this.resetAppointmentDetails.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleUserNameChange = this.handleUserNameChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handlePanelChange = this.handlePanelChange.bind(this);
        this.changeDate = this.changeDate.bind(this);
        this.handleNewProviderId = this.handleNewProviderId.bind(this);
        this.getAppointments = this.getAppointments.bind(this);
        this.createNewAppointment = this.createNewAppointment.bind(this);
        this.updateAppointment = this.updateAppointment.bind(this);
        this.acceptAppointment = this.acceptAppointment.bind(this);
        this.rejectAppointment = this.rejectAppointment.bind(this);
        this.fetchAllProvidersAPI = this.fetchAllProvidersAPI.bind(this);
        this.fetchAllCaregiversAPI = this.fetchAllCaregiversAPI.bind(this);
        this.updateAppointmentObj = this.updateAppointmentObj.bind(this);
        this.updateStatus = this.updateStatus.bind(this);
        this.loadPendingAppointments = this.loadPendingAppointments.bind(this);
        this.validateAppointmentTiming = this.validateAppointmentTiming.bind(this);
        this.props.parentCallback(true, true);
    }

    resetAppointmentDetails() {
        var appointment = {
            "class": '',
            key: '',
            currentState: null,
            userID: '',
            orgname: '',
            appointmentID: '',
            patientID: '',
            firstName: '',
            lastName: '',
            providerID: '',
            newProviderID: '',
            caregiverID: '',
            appointmentStart: '',
            appointmentEnd: '',
            appointmentDescription: '',
            appointmentType: '',
            email: '',
            memberID: '',
            memberOrganization: '',
            acceptedByPatient: '',
            acceptedByProvider: '',
            acceptedByCaregiver: '',
            appointmentStatus: '',
            enableAccept: true,
            enableReject: true,
            appointmentCreationDate: '',
            appointmentUpdateDate: '',
            appointmentCurrentState: '',
            cancellationReason: ''
        };
        if(this.state.userType === 'patient') {
            appointment.patientID = this.props.user.userID;
        }
        
        this.setState({
            anchor: false,
            disableFields: false,
            appointmentDetails: appointment
        })
    }

    componentDidMount() {
        this.resetAppointmentDetails();
        this.props.spinnerLoader(true);
        fetchAllPatientsAPI()
            .then(response => {
                this.props.spinnerLoader(false);
                if(Array.isArray(response.data)) {
                    this.setState({
                        usersList: response.data
                    });
                }
                this.fetchAllCaregiversAPI();
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    fetchAllCaregiversAPI() {
        this.props.spinnerLoader(true);
        fetchAllCaregiversAPI().then(response => {
            this.props.spinnerLoader(false);
            if(Array.isArray(response.data)) {
                this.setState({
                    usersList: this.state.usersList.concat(response.data)
                });
            }
            this.fetchAllProvidersAPI();
        }).catch((error) => {
            this.props.spinnerLoader(false);
            console.log('Error', error);
        });
    }
    
    fetchAllProvidersAPI() {
        this.props.spinnerLoader(true);
        fetchAllProvidersAPI()
            .then(response => {
                this.props.spinnerLoader(false);
                if(Array.isArray(response.data)) {
                    this.setState({
                        usersList: this.state.usersList.concat(response.data)
                    });
                }
                this.getAppointments(false);
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    getAppointments(appointmentsByMe) {
        this.props.spinnerLoader(true);
        fetchAppointmentsAPI(this.state.userId, this.state.userType)
            .then(res => {
                console.log('fetchAppointmentsAPI ', res);
                const appointments = convertResponseToAppointmentVO(res.data === 'Failed to submit transaction!!' ? [] : res.data, this.state.usersList, this.props.user, appointmentsByMe);
                if(res.data === 'Failed to submit transaction!!') {
                    alert('Error occured while fetching appointments...')
                }
                var events = [];
                for(let appointment of appointments.appointmentList) {
                    var color = 'red';
                    if(appointment.cancellationReason === 'NA') {
                        if(appointment.percentage === 100) {
                            color = '#00cc00';
                        } else {
                            color = '#1a90ff';
                        }
                    }
                    events.push({
                        id: JSON.stringify(appointment),
                        title: `${appointment.appointmentType} ${appointment.appointmentDescription}`,
                        start: appointment.appointmentStart,
                        end : appointment.appointmentEnd,
                        backgroundColor: color,
                        borderColor: color
                    });
                }
                
                this.setState({
                    appointments: appointments.appointmentList,
                    caregiverMap: appointments.caregiverMap,
                    providerMap: appointments.providerMap,
                    patientMap: appointments.patientMap,
                    pastAppointments: appointments.pastAppointments,
                    upcomingAppointments: appointments.upcomingAppointments,
                    scheduledAppointments: appointments.scheduledAppointments,
                    pendingAppointments: appointments.pendingAppointments,
                    pendingAppointmentsList: appointments.pendingAppointmentsList,
                    calendarEvents: events
                });
                this.filterAppointments(this.state.showPendingAppointments);
                this.props.spinnerLoader(false);
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    async createNewAppointment() {
        var appointment = this.state.appointmentDetails;
        this.updateAppointmentObj(created, appointment);
        appointment.appointmentCreationDate = new Date().toString();
        appointment.appointmentUpdateDate = new Date().toString();
        appointment.appointmentID = '';
        if(moment(appointment.appointmentStart).isSameOrAfter(moment(appointment.appointmentEnd))) {
            this.setState({
                appointmentEndError: true,
                appointmentEndErrorText: 'End time should be greater than Start time'
            });
        } else {
            this.setState({
                disableFields: true
            });
            const isOverlap = await this.validateAppointmentTiming(appointment);
            if (!isOverlap) {
                this.props.spinnerLoader(true);
                createAppointmentAPI(appointment)
                    .then(res => {
                        this.props.spinnerLoader(false);
                        if (res.data === 'Request Failed!!') {
                            this.setState({
                                disableFields: false
                            });
                            alert('Appointment not created...');
                        } else {
                            this.getAppointments(this.state.appointmentsByMe);
                            this.resetAppointmentDetails();
                            alert('Appointment created successfully...');
                        }
                    })
                    .catch(err => {
                        this.props.spinnerLoader(false);
                        this.resetAppointmentDetails();
                        alert('Error occured while creating/response...');
                        console.log("failure ", err);
                    });
            } else {
                this.setState({
                    disableFields: false
                });
            }
        }
    }

    async validateAppointmentTiming(newAppointment) {
        this.setState({
            bookingTimeWarningMsg: '',
            providerScheduledTimings: []
        });
        this.props.spinnerLoader(true);
        var isOverlap = false;
        await fetchAppointmentsAPI(newAppointment.newProviderID === 'NA' ? newAppointment.providerID : newAppointment.newProviderID, 'provider')
            .then(res => {
                if(res.data === 'Failed to submit transaction!!') {
                    alert('Error occured while fetching appointments for validation...');
                } else {
                    // A.end >= B.start AND A.start <= B.end
                    // (StartDate1 <= EndDate2) and (StartDate2 <= EndDate1)
                    for(let proAppointment of res.data) {
                        if((new Date(newAppointment.appointmentStart) < new Date(proAppointment.appointmentEnd)) &&
                            (new Date(proAppointment.appointmentStart) < new Date(newAppointment.appointmentEnd))) {
                                var scheduledTimings = [];
                                for(let app of res.data) {
                                    if(newAppointment.appointmentStart.split('T')[0] === app.appointmentStart.split('T')[0]) {
                                        scheduledTimings.push(moment(app.appointmentStart).format('LT') + ' - ' + moment(app.appointmentEnd).format('LT'));
                                    }
                                }
                            this.setState({
                                bookingTimeWarningMsg: 'Appointment timing overlays with Provider\'s another appointment. Please select different timing.',
                                providerScheduledTimings: scheduledTimings
                            });
                            isOverlap = true;
                        }
                    }
                }
                this.props.spinnerLoader(false);
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                isOverlap = true;
                console.log("failure ", err);
            });
            return isOverlap;
    }

    updateAppointment(action) {
        var appointmentDetails = this.state.appointmentDetails;
        appointmentDetails.appointmentUpdateDate = new Date().toString();
        appointmentDetails.userID = this.state.userId;
        this.updateAppointmentObj(action, appointmentDetails);
        console.log('appointmentDetails update ', appointmentDetails)
        this.props.spinnerLoader(true);
        updateAppointmentAPI(appointmentDetails, this.state.userType)
            .then(res => {
                if(res.data === 'Request Failed!!') {
                    alert('Appointment updated failed...');
                } else {
                    this.getAppointments(this.state.appointmentsByMe);
                    alert('Appointment updated successfully...');
                }
                this.props.spinnerLoader(false);
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure " + err);
            });
    }

    acceptAppointment = () => {
        this.updateAppointment(accepted);
        this.setState({
            acceptModal: false
        })
    };

    rejectAppointment = () => {
        let appointment = this.state.appointmentDetails;
        this.setState({
            cancellationReasonError: false,
            cancellationReasonErrorText: "",
        });
        if((appointment.cancellationReason !== 'NA' || appointment.cancellationReason !== '') && appointment.cancellationReason.trim().length > 0) {
            this.updateAppointment(rejected);
            this.setState({
                rejectModal: false
            })
        } else {
            this.setState({
                cancellationReasonError: true,
                cancellationReasonErrorText: "Cancellation Reason is required"
            });
        }
    };

    updateStatus(action, appointment) {
        const userType = this.state.userType;
        if (userType === 'provider') {
            if(action === accepted || action === created) {
                appointment.acceptedByProvider = 'true';
            }
            appointment.appointmentStatus = 'Appointment' + action + 'ByProvider';
        } else if (userType === 'caregiver') {
            if(action === accepted || action === created) {
                appointment.acceptedByCaregiver = 'true';
                appointment.acceptedByProvider = 'NA';
            }
            appointment.appointmentStatus = 'Appointment' + action + 'ByCaregiver';
        } else {
            if(action === accepted || action === created) {
                appointment.acceptedByPatient = 'true';
            }
            appointment.appointmentStatus = 'Appointment' + action + 'ByPatient';
        }
    }

    updateAppointmentObj(action, appointment) {
        appointment.userID = this.state.user.userID;
        var patUser = this.state.patientMap.get(appointment.patientID);
        if(action === created) {
            var provider = this.state.providerMap.get(appointment.providerID);
            if(this.state.userType === 'patient') {
                appointment.caregiverID = this.state.user.caregiverID;
                appointment.caregiverName = this.state.user.caregiverName;
                appointment.patientID = this.state.user.patientID;
                appointment.providerName =  provider.person.personFirstName + ' ' + provider.person.personLastName;
            } else if(this.state.userType === 'caregiver') {
                appointment.providerName =  provider.person.personFirstName + ' ' + provider.person.personLastName;
                appointment.caregiverID = this.state.user.userID;
                appointment.caregiverName = this.state.user.person.personFirstName + ' ' + this.state.user.person.personLastName;
            } else {
                appointment.providerID = this.state.user.userID;
                appointment.providerName =  this.state.user.person.personFirstName + ' ' + this.state.user.person.personLastName;
                appointment.caregiverID = patUser.caregiverID;
                appointment.caregiverName = patUser.caregiverName;
            }

            if(appointment.caregiverID === '') {
                appointment.caregiverID = 'NA';
            }

            appointment.patientName = patUser.person.personFirstName + ' ' + patUser.person.personLastName;
            appointment.acceptedByCaregiver = 'NA';
            appointment.acceptedByPatient = 'NA';
            appointment.acceptedByProvider = 'NA';
            appointment.cancellationReason = 'NA';
            appointment.orgname = this.state.userType + 'org';
            if(appointment.newProviderID === this.state.userId) {
                appointment.newProviderID = 'NA';
            }
            this.updateStatus(action, appointment);
            
            if(appointment.newProviderID === 'NA' || appointment.newProviderID === '') {
                appointment.newProviderID = 'NA';
                if(appointment.acceptedByPatient !== 'true' && appointment.caregiverID === 'NA' && appointment.acceptedByProvider === 'true') {
                    appointment.percentage = '50';
                    appointment.pendingWith = appointment.patientID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.patientName;
                }
                else if(appointment.acceptedByCaregiver === 'true' || (appointment.acceptedByPatient === 'true' && (appointment.caregiverID === 'NA' || appointment.caregiverID === ''))) {
                    appointment.percentage = '50';
                    appointment.pendingWith = appointment.providerID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.providerName;
                } else if(appointment.acceptedByProvider === 'true' || (appointment.acceptedByPatient === 'true' && appointment.caregiverID !== 'NA' && appointment.caregiverID !== '')) {
                    appointment.percentage = '33';
                    appointment.pendingWith = appointment.caregiverID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.caregiverName;
                }
            }
            else {
                appointment.isReferral = "true";
                const referedProvider = this.state.providerMap.get(appointment.newProviderID);
                appointment.newProviderName = referedProvider.person.personFirstName + ' ' + referedProvider.person.personLastName;
                appointment.appointmentStatus = "Appointment referred to new Provider";
                appointment.percentage = '25';
                appointment.pendingWith = appointment.newProviderID;
                appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.newProviderName;
            }
        } else if(action === update) {
            if(appointment.newProviderID !== 'NA' && appointment.newProviderID !== '') {
                appointment.isReferral = "true";
                const referedProvider = this.state.providerMap.get(appointment.newProviderID);
                appointment.newProviderName = referedProvider.person.personFirstName + ' ' + referedProvider.person.personLastName;
                appointment.appointmentStatus = "Appointment referred to new Provider";
                appointment.acceptedByProvider = 'NA';
                appointment.percentage = '25';
                appointment.pendingWith = appointment.caregiverID;
                appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.caregiverName;
            } else {
                appointment.newProviderID = 'NA';
                appointment.newProviderName = 'NA';
            }
        } else if(action === rejected) {
            this.updateStatus(action, appointment);
            appointment.percentage = '100';
            appointment.pendingWith = 'NA';
            appointment.acceptedByProvider = 'NA';
            appointment.isReferral = 'NA';
            appointment.appointmentCurrentState = 'Rejected by ' + this.props.user.person.personFirstName + ' ' + this.props.user.person.personLastName 
                                                    + '. Reason - ' + appointment.cancellationReason;

        } else if(action === accepted) {
            this.updateStatus(action, appointment);
            if(appointment.newProviderID === 'NA' || appointment.newProviderID === '') {
                if(appointment.acceptedByPatient === 'true' && appointment.acceptedByProvider === 'true' && appointment.caregiverID === 'NA') {
                    appointment.percentage = '100';
                    appointment.pendingWith = 'NA';
                    appointment.appointmentCurrentState = 'Appointment Scheduled';
                }
                else if((appointment.acceptedByPatient === 'true' && appointment.acceptedByProvider === 'true') ||
                        (appointment.acceptedByCaregiver === 'true' && appointment.acceptedByProvider === 'true')) {
                    appointment.percentage = '100';
                    appointment.pendingWith = 'NA';
                    appointment.appointmentCurrentState = 'Appointment Scheduled';
                } else if(appointment.acceptedByCaregiver === 'true' && appointment.acceptedByProvider !== 'true') {
                    appointment.percentage = '66';
                    appointment.pendingWith = appointment.providerID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.providerName;
                }
            } else {
                if(appointment.acceptedByCaregiver !== 'true' && appointment.acceptedByProvider === 'true') {
                    appointment.percentage = '50';
                    appointment.pendingWith = appointment.caregiverID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.caregiverName;
                } else if(appointment.acceptedByCaregiver === 'true' && appointment.acceptedByProvider !== 'true') {
                    appointment.percentage = '75';
                    appointment.pendingWith = appointment.newProviderID;
                    appointment.appointmentCurrentState = 'Pending Confirmation with ' + appointment.newProviderName;
                } else if(appointment.acceptedByCaregiver === 'true' && appointment.acceptedByProvider === 'true') {
                    appointment.percentage = '100';
                    appointment.pendingWith = 'NA';
                    appointment.appointmentCurrentState = 'Appointment Scheduled';
                }
            }
        }

        /*if(appointment.newProviderID === '' || appointment.newProviderID === 'NA') {
            appointment.isReferral = "NA";
        } else {
            appointment.isReferral = "true";
            const referedProvider = this.state.providerMap.get(appointment.newProviderID);
            appointment.newProviderName = referedProvider.person.personFirstName + ' ' + referedProvider.person.personLastName;
            if(!(action === accepted && action === rejected)) {
                appointment.acceptedByProvider = 'NA';
                appointment.acceptedByCaregiver = 'NA';
            } else {
                appointment.isReferral = "NA";
            }
        }*/
    }

    filterAppointments(showPending) {
        const startDate = moment(this.state.dateSelection[0].startDate).format('YYYY-MM-DD');
        const endDate = this.state.dateSelection[0].endDate !== null ? moment(this.state.dateSelection[0].endDate).format('YYYY-MM-DD') : null;
        const filtered = filterAppointmentByDate(showPending ? this.state.pendingAppointmentsList : this.state.appointments, startDate, endDate);
        this.setState({
            filteredAppointments: filtered
        });
    }

    loadPendingAppointments = (showPending) => {
        this.setState ({
            showPendingAppointments: showPending,
            startRecord: 0,
            limit: 10,
            endRecord: 10,
            page: 0
        });
        this.filterAppointments(showPending);
    }

    handleLimitChange = (event) => {
        this.setState({
            limit: event.target.value,
            page: 0,
            startRecord: 0,
            endRecord: event.target.value
        });
    };

    handlePageChange = (event, newPage) => {
        const startRecord = newPage === 0 ? 0 : (this.state.limit * newPage);
        this.setState({
            page: newPage,
            startRecord: startRecord,
            endRecord: startRecord + this.state.limit
        });
    };

    toggleDrawer = (open, editable, appointment) => (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        var enableButtons = true;
        if(appointment === null) {
            appointment = {
                "class": '',
                key: '',
                currentState: null,
                userID: '',
                orgname: '',
                appointmentID: '',
                patientID: '',
                firstName: '',
                lastName: '',
                providerID: '',
                newProviderID: '',
                caregiverID: '',
                appointmentStart: '',
                appointmentEnd: '',
                appointmentDescription: '',
                appointmentType: '',
                email: '',
                memberID: '',
                memberOrganization: '',
                acceptedByPatient: '',
                acceptedByProvider: '',
                acceptedByCaregiver: '',
                appointmentStatus: '',
                enableAccept: true,
                enableReject: true,
                appointmentCreationDate: '',
                appointmentUpdateDate: '',
                cancellationReason: ''
            };
            if(this.state.userType === 'provider') {
                appointment.appointmentType = this.state.providerMap.get(this.state.userId).providerType;
            }else if(this.state.userType === 'patient') {
                appointment.patientID = this.props.user.userID;
            }
            enableButtons = false;
        }
        this.setState({
            anchor: open,
            disableFields: editable,
            appointmentDetails: appointment,
            enableButtons: enableButtons,
            bookingTimeWarningMsg: '',
            appointmentStartError: false, appointmentStartErrorText: "",
            appointmentEndError: false, appointmentEndErrorText: "",
            purposeError: false, purposeErrorText: "",
            patientIDError: false, patientIDErrorText: "",
            caregiverIDError: false, caregiverIDErrorText: "",
            providerIDError: false, providerIDErrorText: "",
            appointmentTypeError: false, appointmentTypeErrorText: "",
            appointmentDescriptionError: false, appointmentDescriptionErrorText: "",
            cancellationReasonError: false, cancellationReasonErrorText: ""
        });
    };

    handlePanelChange = (panel) => (event, isExpanded) => {
        this.setState({
            expanded: panel
        });
    };

    handleClickAcceptModalOpen = (appointment) => {
        this.setState({
            acceptModal: true,
            appointmentDetails: appointment
        });
    };

    handleAcceptModalClose = () => {
        this.setState({
            acceptModal: false
        });
    };

    handleClickRejectModalOpen = (appointment) => {
        this.setState({
            rejectModal: true,
            appointmentDetails: appointment
        });
    };

    handleRejectModalClose = () => {
        this.setState({
            rejectModal: false
        });
    };

    changeDate(item) {
        const startDate = moment(item[0].startDate).format('YYYY-MM-DD');
        const endDate = item[0].endDate !== null ? moment(item[0].endDate).format('YYYY-MM-DD') : null;
        this.setState({
            dateSelection: item,
            filteredAppointments: filterAppointmentByDate(this.state.showPendingAppointments ? this.state.pendingAppointmentsList : this.state.appointments, startDate, endDate)
        });
    }

    handleUserNameChange(event) {
        const key = event.target.value;
        let appointmentDetails = this.state.appointmentDetails;
        appointmentDetails.patientID = key;
        //const patientMap = this.state.patientMap;
        //appointmentDetails.firstName = patientMap.get(key).person.personFirstName;
        //appointmentDetails.lastName = patientMap.get(key).person.personlastName;
        this.setState({
            appointmentDetails: appointmentDetails
        });
    }

    handleNewProviderId(event) {
        let appointmentDetails = this.state.appointmentDetails;
        appointmentDetails.newProviderID = event.target.value;
        appointmentDetails.appointmentStatus = 'Appointment referred to new Provider';
        appointmentDetails.appointmentType = this.state.providerMap.get(appointmentDetails.newProviderID).providerType;
        if (event.target.value === null || event.target.value === '') {
            appointmentDetails.newProviderID = '';
            appointmentDetails.appointmentStatus = '';
        }
        this.setState({
            appointmentDetails: appointmentDetails
        });
    }

    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;
        let appointmentDetails = this.state.appointmentDetails;
        appointmentDetails[name] = value;
        if(name === 'providerID') {
            appointmentDetails.appointmentType = this.state.providerMap.get(value).providerType;
        }
        this.setState({
            appointmentDetails: appointmentDetails
        });
    }

    handleSubmit(event) {
        event.preventDefault();
        if (this.formValid()) {
            if (this.state.appointmentDetails.appointmentID === '') {
                this.createNewAppointment();
            } else {
                this.updateAppointment(update);
            }
        }
    }

    formValid() {
        var valid = true;
        const appointment = this.state.appointmentDetails;
        const map = this.state.userType === 'provider' ? providerMap : (this.state.userType === 'patient' ? patientMap : caregiverMap);
        for (const key of map.keys()) {
            const name = key;
            const error = name + 'Error';
            const errorText = name + 'ErrorText';

            if (appointment[name].length === 0) {
                valid = false;
                this.setState({
                    [error]: true,
                    [errorText]: map.get(name)
                });
            } else {
                this.setState({
                    [error]: false,
                    [errorText]: ''
                });
            }
        }
        return valid;
    }

    render() {
        return (
            <div style={{ padding: '10px' }}>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined" style={ this.state.showPendingAppointments ? disableGridStyle : {} } >
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Past Appointments
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.pastAppointments}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#2684FF', height: 56, width: 56 }}>
                                            <VisibilityOffIcon />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined" style={ this.state.showPendingAppointments ? disableGridStyle : {} }>
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Upcoming Appointments
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.upcomingAppointments}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#3f51b5', height: 56, width: 56 }}>
                                            <AlarmIcon />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined" style={ this.state.showPendingAppointments ? disableGridStyle : {} }>
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Confirmed
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.scheduledAppointments}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#00b359', height: 56, width: 56 }}>
                                            <Schedule />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined" onClick={() => this.loadPendingAppointments(!this.state.showPendingAppointments)} style={ this.state.showPendingAppointments ?  {border: '1px solid #1a90ff'} : {} }>
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Pending
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.pendingAppointments}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: 'orange', height: 56, width: 56 }}>
                                            <Update />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={12}>
                        <Card variant="outlined">
                            <CardContent>
                                <p style={{ float: 'left', fontSize: '1.0125rem', fontWeight: '500', paddingRight: '20px', marginTop: '8px', marginBottom: '8px' }}>Appointments dashboard</p>
                                <p style={{ float: 'left', marginTop: '0px', marginBottom: '8px' }}>
                                    <FormControlLabel
                                        control={
                                            <Switch
                                                checked={this.state.calendarView}
                                                onChange={(event) => this.setState({ calendarView: event.target.checked })}
                                                name="checkedB"
                                                color="primary"
                                            />
                                        }
                                        label="Calendar View"
                                        labelPlacement="start"
                                        style={{fontSize: '20px'}}
                                    />
                                </p>
                                {this.state.userType === 'provider' &&
                                <p style={{ float: 'left', marginLeft: '100px', marginTop: '0px', marginBottom: '8px' }}>
                                    <FormControlLabel
                                        value={this.state.appointmentsByMe}
                                        checked={this.state.appointmentsByMe}
                                        onChange={(event) => {this.setState({ appointmentsByMe: event.target.checked }); this.getAppointments(event.target.checked)}}
                                        name="appointmentsByMe"
                                        control={<Checkbox color="primary" />}
                                        label="Appointments Referred "
                                        labelPlacement="end"
                                    />
                                </p>
                                }
                                <p style={{ float: 'right', marginTop: '8px', marginBottom: '8px' }}>
                                    <Button variant="contained" color="primary" size="small" onClick={this.toggleDrawer(true, false, null)}>
                                        <AddIcon /> &nbsp;Schedule
                                    </Button>
                                </p>
                            </CardContent>
                            <CardContent>

                                {this.state.calendarView ?
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} sm={1}></Grid>
                                        <Grid item xs={12} sm={10}>
                                            <FullCalendar
                                                plugins={[interaction, dayListPlugin, dayGridPlugin, bootstrapPlugin, timeGridPlugin, listPlugin]}
                                                defaultView="dayGridMonth"
                                                height= '700px'
                                                events={this.state.calendarEvents}
                                                headerToolbar={{left: 'prev,next today',center: 'title',right: 'dayGridMonth,timeGridWeek,timeGridDay'}}
                                                eventClick={(element) => {
                                                    this.setState({
                                                        anchor: true,
                                                        disableFields: true,
                                                        appointmentDetails: JSON.parse(element.event.id),
                                                        enableButtons: true
                                                    });
                                                }}
                                            />
                                            <div>
                                                <span style={{color:'#00cc00'}}>Scheduled &nbsp;&nbsp;</span>
                                                <span style={{color:'#1a90ff'}}>Pending &nbsp;&nbsp;</span>
                                                <span style={{color:'red'}}>Rejected</span>
                                            </div>
                                        </Grid>
                                    </Grid>
                                    :
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} sm={4}>
                                            <DateRange
                                                editableDateInputs={true}
                                                onChange={item => this.changeDate([item.selection])}
                                                moveRangeOnFirstSelection={false}
                                                ranges={this.state.dateSelection}
                                                plugins={[interaction, dayListPlugin, dayGridPlugin, bootstrapPlugin, timeGridPlugin]}
                                                themeSystem="bootstrap"
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={8} >
                                            <Card>
                                                <PerfectScrollbar>
                                                    <Box>
                                                        <Table>
                                                            <TableHead>
                                                                <TableRow>
                                                                    {this.state.userType !== 'patient' &&
                                                                        <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                            Name
                                                                        </TableCell>
                                                                    }
                                                                    <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                        Appointment Details
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                        Status
                                                                    </TableCell>
                                                                    {this.state.userType !== 'provider' &&
                                                                        <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                            Provider
                                                                    </TableCell>
                                                                    }
                                                                    {this.state.userType !== 'caregiver' &&
                                                                        <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                            Caregiver
                                                                    </TableCell>
                                                                    }
                                                                    <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                        Actions
                                                                </TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {this.state.filteredAppointments.slice(this.state.startRecord, this.state.endRecord).map((appointment) => (
                                                                    <TableRow
                                                                        hover
                                                                        key={appointment.appointmentID}
                                                                    >
                                                                        {this.state.userType !== 'patient' &&
                                                                            <TableCell style={{ padding: '12px 16px' }}>
                                                                                <Box
                                                                                    alignItems="center"
                                                                                    display="flex"
                                                                                >
                                                                                    <Avatar
                                                                                        src={appointment.avatarUrl}
                                                                                    >
                                                                                        {getInitials(appointment.patientName)}
                                                                                    </Avatar>
                                                                                    <div style={{ fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '0.850rem' }}>
                                                                                        &nbsp;{appointment.patientName}
                                                                                    </div>
                                                                                </Box>
                                                                            </TableCell>
                                                                        }
                                                                        <TableCell style={{ padding: '12px 16px', fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '0.850rem' }}>
                                                                            <div><b>{appointment.appointmentID}</b> - {appointment.appointmentType}</div>
                                                                            <div>{appointment.appointmentDescription}</div>
                                                                            <div>{appointment.displayTime}</div>
                                                                        </TableCell>
                                                                        <TableCell style={{ padding: '12px 16px', fontSize: '0.850rem' }}>
                                                                            <div>
                                                                                <div style={{ float: 'left' }}><strong>{appointment.percentage}%</strong></div>
                                                                                <div style={{ float: 'right' }}>
                                                                                    <small style={{ color: '#768192' }}>{appointment.appointmentCurrentState}</small>
                                                                                </div>
                                                                            </div>
                                                                            <br />
                                                                            <Box display="flex" alignItems="center">
                                                                                <Box width="100%">
                                                                                    {(appointment.percentage === 100 && appointment.cancellationReason === 'NA') ?
                                                                                        <CompletionLinearProgress color='red' variant="determinate" value={appointment.percentage} />
                                                                                        :
                                                                                        <div>
                                                                                            {appointment.cancellationReason === 'NA' ?
                                                                                                <PendingLinearProgress percentage={appointment.percentage} variant="determinate" value={appointment.percentage} />
                                                                                                :
                                                                                                <CancelledLinearProgress percentage={appointment.percentage} variant="determinate" value={appointment.percentage} />
                                                                                            }
                                                                                        </div>
                                                                                    }
                                                                                </Box>
                                                                            </Box>
                                                                        </TableCell>
                                                                        {this.state.userType !== 'provider' &&
                                                                            <TableCell style={{ padding: '8px 16px', fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '0.850rem' }}>
                                                                                {(appointment.newProviderID === 'NA' || appointment.newProviderID === '') && <span>{appointment.providerName}</span>}
                                                                                {(appointment.newProviderID !== 'NA' && appointment.newProviderID !== '') && <span>{appointment.newProviderName}</span>}
                                                                            </TableCell>
                                                                        }
                                                                        {this.state.userType !== 'caregiver' &&
                                                                            <TableCell style={{ padding: '8px 16px', fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '0.850rem' }}>
                                                                                {appointment.caregiverName}
                                                                            </TableCell>
                                                                        }
                                                                        <TableCell style={{ padding: '12px 16px' }}>
                                                                            <Tooltip title="View" aria-label="add">
                                                                                <VisibilityIcon color="primary" fontSize='small' onClick={this.toggleDrawer(true, true, appointment)} />
                                                                            </Tooltip>
                                                                            {appointment.enableAccept &&
                                                                                <Tooltip title="Accept" aria-label="add">
                                                                                    <CheckCircleIcon onClick={(e) => this.handleClickAcceptModalOpen(appointment)} style={{ color: "#00cc00", paddingLeft: '10px' }} fontSize='small' />
                                                                                </Tooltip>
                                                                            }
                                                                            {appointment.enableReject &&
                                                                                <Tooltip title="Reject" aria-label="add">
                                                                                    <CancelIcon onClick={(e) => this.handleClickRejectModalOpen(appointment)} style={{ paddingLeft: '10px' }} color="secondary" fontSize='small' />
                                                                                </Tooltip>
                                                                            }
                                                                        </TableCell>
                                                                    </TableRow>
                                                                ))}
                                                            </TableBody>
                                                        </Table>
                                                    </Box>
                                                </PerfectScrollbar>
                                                <TablePagination
                                                    component="div"
                                                    count={this.state.filteredAppointments.length}
                                                    onChangePage={this.handlePageChange}
                                                    onChangeRowsPerPage={this.handleLimitChange}
                                                    page={this.state.page}
                                                    rowsPerPage={this.state.limit}
                                                    rowsPerPageOptions={[5, 10, 25]}
                                                />
                                            </Card>
                                        </Grid>
                                    </Grid>
                                }
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                <React.Fragment>
                    <Drawer variant="temporary" anchor='right' open={this.state.anchor}>
                        <form style={{ width: '40vw' }} onSubmit={this.handleSubmit}>
                            <div style={{ width: '95%' }}>
                                <Grid container spacing={1}>
                                    <Grid item xs={12} sm={1}>
                                        <IconButton color="primary" onClick={this.toggleDrawer(false, true, null)} aria-label="Close">
                                            <ArrowBackIcon />
                                        </IconButton>
                                    </Grid>
                                    <Grid item xs={12} sm={5}>
                                        {!this.state.disableFields && <h3>Schedule Appointment</h3>}
                                        {this.state.disableFields && <h3>Appointment Details</h3>}
                                    </Grid>
                                    <Grid item xs={12} sm={6}></Grid>
                                    <Grid item xs={12} sm={1}></Grid>
                                    <Grid item xs={12} sm={8}>
                                        {/*this.state.enableButtons &&
                                            <div>
                                                {this.state.appointmentDetails.enableAccept && <Button onClick={(e)=>this.acceptAppointment(this.state.appointmentDetails)} color="primary">
                                                    Accept
                                                </Button>
                                                }
                                                {this.state.appointmentDetails.enableReject && <Button onClick={(e)=>this.rejectAppointment(this.state.appointmentDetails)} color="secondary">
                                                    Reject
                                                </Button>
                                                }
                                            </div>
                                        */}
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            autoFocus
                                            id="datetime-local"
                                            label="Appointment Start-time"
                                            type="datetime-local"
                                            name="appointmentStart"
                                            onChange={(event) => this.handleChange(event)}
                                            disabled={this.state.disableFields}
                                            error={this.state.appointmentStartError}
                                            helperText={this.state.appointmentStartErrorText}
                                            value={this.state.appointmentDetails.appointmentStart}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="datetime-local"
                                            label="Appointment End-time"
                                            type="datetime-local"
                                            name="appointmentEnd"
                                            onChange={(event) => this.handleChange(event)}
                                            disabled={this.state.disableFields}
                                            error={this.state.appointmentEndError}
                                            helperText={this.state.appointmentEndErrorText}
                                            value={this.state.appointmentDetails.appointmentEnd}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                        {this.state.userType !== 'patient' &&
                                        <span>
                                        <FormControl>
                                        {this.state.patientIDError && <InputLabel id="patientID" error>Appointment For(Patient)*</InputLabel>}
                                        {!this.state.patientIDError && <InputLabel id="patientID">Appointment For(Patient)*</InputLabel>}
                                            <Select
                                                margin="normal"
                                                style={{ width: '385px' }}
                                                fullWidth
                                                labelId="patientID"
                                                id="patientID"
                                                name="patientID"
                                                disabled={this.state.disableFields}
                                                error={this.state.patientIDError}
                                                helperText={this.state.patientIDErrorText}
                                                value={this.state.appointmentDetails.patientID}
                                                onChange={(event) => this.handleUserNameChange(event)}
                                            >
                                                {
                                                    [...this.state.patientMap].map(([key, value]) => {
                                                        return <MenuItem key={key} value={value.userID}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                    })
                                                }
                                            </Select>
                                            <FormHelperText style={{color: 'red'}}>{this.state.patientIDErrorText}</FormHelperText>
                                        </FormControl>
                                        {/*<TextField
                                            margin="normal"
                                            fullWidth
                                            id="firstName"
                                            label="First Name*"
                                            name="username"
                                            autoComplete="username"
                                            disabled
                                            value={this.state.appointmentDetails.firstName}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="lastName"
                                            label="Last Name*"
                                            name="username"
                                            autoComplete="username"
                                            disabled
                                            value={this.state.appointmentDetails.lastName}
                                        />*/}
                                        </span>
                                        }
                                        {/*this.state.userType !== 'caregiver' &&
                                        <FormControl>
                                            <InputLabel id="caregiverID">Caregiver*</InputLabel>
                                            <Select
                                                margin="normal"
                                                style={{ width: '385px' }}
                                                fullWidth
                                                name="caregiverID"
                                                labelId="caregiverID"
                                                id="caregiverID"
                                                disabled={this.state.disableFields}
                                                error={this.state.caregiverIDError}
                                                helperText={this.state.caregiverIDErrorText}
                                                value={this.state.appointmentDetails.caregiverID}
                                                onChange={(event) => this.handleChange(event)}
                                            >
                                                {
                                                    [...this.state.caregiverMap].map(([key, value]) => {
                                                        return <MenuItem key={key} value={value.userID}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                    })
                                                }
                                            </Select>
                                            </FormControl>
                                            */}
                                        <div style={{ paddingTop: '20px' }}></div>
                                        {this.state.userType !== 'provider' &&
                                        <FormControl>
                                            {this.state.providerIDError && <InputLabel id="providerID" error>Provider*</InputLabel>}
                                            {!this.state.providerIDError && <InputLabel id="providerID">Provider*</InputLabel>}
                                            <Select
                                                margin="normal"
                                                style={{ width: '385px' }}
                                                fullWidth
                                                name="providerID"
                                                labelId="providerID"
                                                id="providerID"
                                                disabled={this.state.disableFields}
                                                error={this.state.providerIDError}
                                                helperText={this.state.providerIDErrorText}
                                                value={this.state.appointmentDetails.providerID}
                                                onChange={(event) => this.handleChange(event)}
                                            >
                                                {
                                                    [...this.state.providerMap].map(([key, value]) => {
                                                        return <MenuItem key={key} value={value.userID}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                    })
                                                }
                                            </Select>
                                            <FormHelperText style={{color: 'red'}}>{this.state.providerIDErrorText}</FormHelperText>
                                        </FormControl>
                                        }
                                        {/*<TextField
                                            margin="normal"
                                            fullWidth
                                            id="caregiverID"
                                            label="Caregiver Id*"
                                            name="caregiverID"
                                            autoComplete="caregiverID"
                                            disabled={this.state.disableFields}
                                            error={this.state.caregiverIDError}
                                            helperText={this.state.caregiverIDErrorText}
                                            value={this.state.appointmentDetails.caregiverID}
                                            onChange={(event) => this.handleChange(event)}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="providerID"
                                            label="Provider Id*"
                                            name="providerID"
                                            autoComplete="providerID"
                                            disabled={this.state.disableFields}
                                            error={this.state.providerIDError}
                                            helperText={this.state.providerIDErrorText}
                                            value={this.state.appointmentDetails.providerID}
                                            onChange={(event) => this.handleChange(event)}
                                        />*/}
                                        {(this.state.userType === 'provider' && this.state.appointmentDetails.appointmentID === '') &&
                                            <FormControl>
                                                <InputLabel id="newProviderID">Refer another Provider</InputLabel>
                                                <Select
                                                    margin="normal"
                                                    style={{ width: '385px' }}
                                                    fullWidth
                                                    name="newProviderID"
                                                    labelId="newProviderID"
                                                    id="newProviderID"
                                                    value={this.state.appointmentDetails.newProviderID}
                                                    onChange={(event) => this.handleNewProviderId(event)}
                                                >
                                                    <MenuItem value=''></MenuItem>
                                                    {
                                                        [...this.state.providerMap].map(([key, value]) => {
                                                            return <MenuItem key={key} value={value.userID}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                        })
                                                    }
                                                </Select>
                                            </FormControl>
                                        }
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="appointmentType"
                                            label="Appointment Type*"
                                            name="appointmentType"
                                            autoComplete="appointmentType"
                                            disabled={this.state.disableFields}
                                            error={this.state.appointmentTypeError}
                                            helperText={this.state.appointmentTypeErrorText}
                                            value={this.state.appointmentDetails.appointmentType}
                                            onChange={(event) => this.handleChange(event)}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="appointmentDescription"
                                            label="Appointment Description*"
                                            name="appointmentDescription"
                                            autoComplete="appointmentDescription"
                                            disabled={this.state.disableFields}
                                            error={this.state.appointmentDescriptionError}
                                            helperText={this.state.appointmentDescriptionErrorText}
                                            value={this.state.appointmentDetails.appointmentDescription}
                                            onChange={(event) => this.handleChange(event)}
                                        />
                                        <div style={{paddingTop:'20px'}}>
                                            {this.state.appointmentDetails.appointmentID !== '' && 
                                                <span>
                                                    <b><u>Other Details:</u></b><br/>
                                                    <b>Current status -</b>{this.state.appointmentDetails.appointmentCurrentState}
                                                    {(this.state.appointmentDetails.cancellationReason !== '' && this.state.appointmentDetails.cancellationReason !== 'NA') &&
                                                    <span><b>Cancellation Reason -</b> {this.state.appointmentDetails.cancellationReason} - {this.state.appointmentDetails.appointmentStatus}<br/>
                                                    </span>}<br/>
                                                    <b>Time of last update -</b> {this.state.appointmentDetails.appointmentUpdateDate}
                                                </span>
                                            }
                                        </div>
                                        {/*<TextField
                                            margin="normal"
                                            fullWidth
                                            id="email"
                                            label="Email Address*"
                                            name="email"
                                            autoComplete="email"
                                            disabled={this.state.disableFields}
                                            error={this.state.emailError}
                                            helperText={this.state.emailErrorText}
                                            value={this.state.appointmentDetails.email}
                                            onChange={(event) => this.handleChange(event)}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="memberID"
                                            label="Member Id*"
                                            name="memberID"
                                            autoComplete="memberID"
                                            disabled={this.state.disableFields}
                                            error={this.state.memberIDError}
                                            helperText={this.state.memberIDErrorText}
                                            value={this.state.appointmentDetails.memberID}
                                            onChange={(event) => this.handleChange(event)}
                                        />
                                        <TextField
                                            margin="normal"
                                            fullWidth
                                            id="memberOrganization"
                                            label="Member Organization*"
                                            name="memberOrganization"
                                            autoComplete="memberOrganization"
                                            disabled={this.state.disableFields}
                                            error={this.state.memberOrganizationError}
                                            helperText={this.state.memberOrganizationErrorText}
                                            value={this.state.appointmentDetails.memberOrganization}
                                            onChange={(event) => this.handleChange(event)}
                                        />*/}
                                        {this.state.bookingTimeWarningMsg !== '' &&
                                            <div style={{color: 'red'}}>
                                                {this.state.bookingTimeWarningMsg} <br/><br/>
                                                Below timings are blocked in Provider's calendar for the appointment date selected:
                                                {this.state.providerScheduledTimings.map((item) =>
                                                    <li>{item}</li>
                                                )}
                                            </div>
                                        }
                                        <div style={{ paddingTop: '20px' }}></div>
                                        {this.state.appointmentDetails.appointmentID === '' &&
                                            <Button
                                                type="submit"
                                                variant="contained"
                                                color="primary"
                                                disabled={this.state.disableFields}
                                            >
                                                Save
                                            </Button>
                                        }
                                        <span style={{ paddingLeft: '20px' }}>
                                            <Button
                                                type="button"
                                                color="primary"
                                                variant="contained"
                                                onClick={this.toggleDrawer(false, true, null)}
                                            >
                                                Cancel
                                        </Button>
                                        </span>
                                    </Grid>
                                </Grid>
                            </div>
                        </form>
                    </Drawer>
                </React.Fragment>
                <Dialog
                    open={this.state.acceptModal}
                    onClose={this.handleAcceptModalClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">{"Accept the appointment"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            Are you sure to accept the appointment ? Please click 'Accept' to schedule the appointment else click 'Close' to cancel the operation.
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.acceptAppointment} color="primary">
                            Accept
                        </Button>
                        <Button onClick={this.handleAcceptModalClose} color="primary" autoFocus>
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>
                <Dialog
                    open={this.state.rejectModal}
                    onClose={this.handleRejectModalClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">{"Reject the appointment"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            Are you sure to reject the appointment ? Please click 'Reject' to reject else click 'Close' to cancel the operation.
                            <TextField
                                margin="normal"
                                fullWidth
                                id="purpose"
                                autoFocus
                                label="Cancellation Reason*"
                                name="cancellationReason"
                                autoComplete="cancellationReason"
                                error={this.state.cancellationReasonError}
                                helperText={this.state.cancellationReasonErrorText}
                                value={this.state.appointmentDetails.cancellationReason}
                                onChange={(event) => this.handleChange(event)}
                            />
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.rejectAppointment} color="secondary">
                            Reject
                        </Button>
                        <Button onClick={this.handleRejectModalClose} color="primary">
                            Close
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

// getting the data
function mapStateToProps(state) {
    return state;
}

export default connect(mapStateToProps)(Appointment);