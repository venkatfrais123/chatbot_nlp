import React from 'react';
import LocalHospital from '@material-ui/icons/LocalHospital';
import PeopleIcon from '@material-ui/icons/PeopleOutlined';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
    Avatar,
    Box,
    Button,
    Card,
    CardContent,
    Grid,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TablePagination,
    TableRow,
    Typography,
    ButtonGroup,
    TextField
} from '@material-ui/core';
import { getInitials, getUserDetailsAsState } from '../utils/helper';
import { fetchAllCaregiversAPI, fetchAllProvidersAPI } from "../utils/service";

class Users extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            totalUsers: 0,
            totalCaregivers: 0,
            totalProviders: 0,
            totalPatients: 0,
            caregiversList: [],
            providersList: [],
            patientsList: [],
            limit: 10,
            page: 0,
            searchType: '',
            searchInput: '',
            users: [],
            filteredList: []
        };

        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.fetchAllProvidersAPI = this.fetchAllProvidersAPI.bind(this);
        this.fetchAllCaregiversAPI = this.fetchAllCaregiversAPI.bind(this);
        this.props.parentCallback(true, true);
    }

    handleInputChange(event) {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    handleChange(event) {
        const value = event.target.value;
        if(value === 'caregiver') {
            this.setState({
                [event.target.name]: value,
                filteredList: this.state.caregiversList 
            });
        } else if(value === 'provider') {
            this.setState({
                [event.target.name]: value,
                filteredList: this.state.providersList 
            });
        } else if(value === 'patient') {
            this.setState({
                [event.target.name]: value,
                filteredList: this.state.patientsList 
            });
        } else {
            this.setState({
                [event.target.name]: value,
                filteredList: this.state.users
            });
        }
    }

    handleLimitChange = (event) => {
        this.setState({
            limit: event.target.value
        });
    };

    handlePageChange = (event, newPage) => {
        this.setState({
            page: newPage
        });
    };

    handleSubmit(event) {
        event.preventDefault();
        const searchType = this.state.searchType;
        const searchInput = this.state.searchInput;
        var userData = [];

        if (searchType === 'patient') {
            userData = this.state.patientsList;
        } else if (searchType === 'caregiver') {
            userData = this.state.caregiversList;
        } else if (searchType === 'provider') {
            userData = this.state.providersList;
        } else {
            userData = this.state.users;
        }

        const data = userData.filter((user) => {
            return (user.username.toUpperCase().includes(searchInput.toUpperCase()) || user.firstName.toUpperCase().includes(searchInput.toUpperCase())
                || user.lastName.toUpperCase().includes(searchInput.toUpperCase()) || user.address1.toUpperCase().includes(searchInput.toUpperCase())
                || user.address2.toUpperCase().includes(searchInput.toUpperCase()) || user.city.toUpperCase().includes(searchInput.toUpperCase())
                || user.state.toUpperCase().includes(searchInput.toUpperCase()) || user.phoneNumber.toUpperCase().includes(searchInput.toUpperCase()));
        });
        this.setState({
            filteredList: data
        });
    }

    componentDidMount() {
        this.props.spinnerLoader(true);
        /*fetchAllPatientsAPI().then(response => {
            console.log('fetchAllPatientsAPI ', response);
            var patientCount = 0;
            const data = response.data.map(function (user) {
                patientCount++;
                var userDt = getUserDetailsAsState(user);
                userDt.userType = 'patient';
                return userDt;
            });
            this.setState({
                totalPatients: patientCount,
                users: data,
                patientsList: data,
                totalUsers: data.length,
                filteredList: data
            });
            this.props.spinnerLoader(false);
            this.fetchAllCaregiversAPI();
        }).catch((error) => {
            this.props.spinnerLoader(false);
            console.log('Error', error);
        });*/
        this.fetchAllCaregiversAPI();
    }
    
    fetchAllCaregiversAPI() {
        this.props.spinnerLoader(true);
        fetchAllCaregiversAPI().then(response => {
            console.log('fetchAllCaregiversAPI ', response);
            if(Array.isArray(response.data)) {
                var caregiverCount = 0;
                const data = response.data.map(function (user) {
                    caregiverCount++;
                    var userDt = getUserDetailsAsState(user);
                    userDt.userType = 'caregiver';
                    return userDt;
                });
                const finalData = this.state.users.concat(data);
                this.setState({
                    totalCaregivers: caregiverCount,
                    caregiversList: data,
                    users: finalData,
                    filteredList: finalData
                });
            }
            this.props.spinnerLoader(false);
            this.fetchAllProvidersAPI();
        }).catch((error) => {
            this.props.spinnerLoader(false);
            console.log('Error', error);
        });
    }
    
    fetchAllProvidersAPI() {
        this.props.spinnerLoader(true);
        fetchAllProvidersAPI()
            .then(response => {
                console.log('fetchAllProvidersAPI ', response);
                if(Array.isArray(response.data)) {
                    var providerCount = 0;
                    const data = response.data.map(function (user) {
                        providerCount++;
                        var userDt = getUserDetailsAsState(user);
                        userDt.userType = 'provider';
                        return userDt;
                    });
                    const finalData = this.state.users.concat(data);
                    this.setState({
                        totalUsers: finalData.length,
                        totalProviders: providerCount,
                        providersList: data,
                        users: finalData,
                        filteredList: finalData
                    });
                }
                this.props.spinnerLoader(false);
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    render() {
        return (
            <div style={{ padding: '10px' }}>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Users
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.totalUsers}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#3f51b5', height: 56, width: 56 }}>
                                            <PeopleIcon />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Caregivers
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            {this.state.totalCaregivers}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#3f51b5', height: 56, width: 56 }}>
                                            <PeopleIcon />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Providers
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            {this.state.totalProviders}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#2684FF', height: 56, width: 56 }}>
                                            <LocalHospital />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/*<Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Patients
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            {this.state.totalPatients}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#2684FF', height: 56, width: 56 }}>
                                            <PeopleIcon />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>*/}
                    <Grid item xs={12} sm={12} style={{minHeight: '490px'}}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid container spacing={2}>
                                    <Grid item xs={12} sm={12}>
                                        <div style={{ float: 'left', fontSize: '1.0125rem', fontWeight: '500', paddingBottom: '10px' }}>
                                            List of Users
                                        </div>
                                    </Grid>
                                    <Grid item xs={12} sm={12}>
                                        <form style={{ width: '100%' }} onSubmit={this.handleSubmit}>
                                            <div style={{ float: 'left' }}>
                                                <ButtonGroup variant="contained" color="primary" aria-label="contained primary button group">
                                                    <FormControl variant="filled" style={{width: '150px'}}>
                                                        <InputLabel id="demo-simple-select-helper-label">Type</InputLabel>
                                                        <Select
                                                            labelId="demo-simple-select-filled-label"
                                                            id="demo-simple-select-filled"
                                                            name="searchType"
                                                            fullWidth
                                                            value={this.state.searchType}
                                                            onChange={(event) => this.handleChange(event)}
                                                        >
                                                            <MenuItem value={''}>All</MenuItem>
                                                            <MenuItem value={'caregiver'}>Caregiver</MenuItem>
                                                            <MenuItem value={'provider'}>Provider</MenuItem>
                                                            {/*<MenuItem value={'patient'}>Patient</MenuItem>*/}
                                                        </Select>
                                                    </FormControl>
                                                    <TextField 
                                                        fullWidth
                                                        style={{width: '300px'}}
                                                        id="outlined-basic" 
                                                        label="Search" 
                                                        variant="outlined"
                                                        name="searchInput"
                                                        value={this.state.searchInput}
                                                        onChange={(event) => this.handleInputChange(event)}
                                                    />
                                                </ButtonGroup>
                                                <Button
                                                    type="submit"
                                                    style={{display: 'none'}}
                                                    fullWidth
                                                    variant="contained"
                                                    color="primary"
                                                >
                                                    Search
                                                </Button>
                                            </div>
                                        </form>
                                    </Grid>
                                </Grid>
                            </CardContent>
                            <CardContent>
                                <Grid container>
                                    <Grid item xs={12} sm={12}>
                                        <Card>
                                            <PerfectScrollbar>
                                                <Box>
                                                    <Table>
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Name
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Type
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Username
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    E-mail
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Phone Number
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Address 1
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    Address 2
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    City
                                                                </TableCell>
                                                                <TableCell style={{ padding: '8px 16px', color: '#768192', backgroundColor: '#d8dbe0', fontWeight: 'bold' }}>
                                                                    State
                                                                </TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {this.state.filteredList.slice(0, this.state.limit).map((customer) => (
                                                                <TableRow
                                                                    hover
                                                                    key={customer.userID}
                                                                >
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        <Box
                                                                            alignItems="center"
                                                                            display="flex"
                                                                        >
                                                                            <Avatar
                                                                                src={customer.avatarUrl}
                                                                            >
                                                                                {getInitials(`${customer.firstName} ${customer.lastName}`)}
                                                                            </Avatar>
                                                                            <div>
                                                                                &nbsp;&nbsp;{customer.firstName} {customer.lastName}
                                                                            </div>
                                                                        </Box>
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.userType}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.username}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.email}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.phoneNumber}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.address1}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.address2}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.city}
                                                                    </TableCell>
                                                                    <TableCell style={{ padding: '12px 16px' }}>
                                                                        {customer.state}
                                                                    </TableCell>
                                                                </TableRow>
                                                            ))}
                                                        </TableBody>
                                                    </Table>
                                                </Box>
                                            </PerfectScrollbar>
                                            <TablePagination
                                                component="div"
                                                count={this.state.filteredList.length}
                                                onChangePage={this.handlePageChange}
                                                onChangeRowsPerPage={this.handleLimitChange}
                                                page={this.state.page}
                                                rowsPerPage={this.state.limit}
                                                rowsPerPageOptions={[5, 10, 25]}
                                            />
                                        </Card>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
            </div>
        );
    }
}

export default Users;