import React from 'react';
import {
    Grid,
    Card,
    CardContent,
    Divider,
    Avatar,
    Typography
} from '@material-ui/core';
import LocalHospital  from '@material-ui/icons/LocalHospital';
import Schedule from '@material-ui/icons/Schedule';
import Update from '@material-ui/icons/Update';
import PieChart from '../charts/PieChart';
import LineChart from '../charts/LineChart';
import AreaChart from '../charts/AreaChart';
import { convertResponseToAppointmentVO } from '../utils/helper';
import { fetchAllPatientsAPI, fetchAllCaregiversAPI, fetchAllProvidersAPI, fetchAppointmentsAPI } from "../utils/service";
import { connect } from 'react-redux';

class Provider extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            anchor: false,
            user: this.props.user,
            pastAppointments: 0,
            upcomingAppointments: 0,
            scheduledAppointments: 0,
            pendingAppointments: 0,
            pendingAppointmentsWithUser: 0,
            pendingAppointmentsWithOtherUser: 0,
            totalProviders: 0,
            totalCaregivers: 0,
            totalPatients: 0,
            totalRefereals: 0,
            caregiverName: '',
            expanded: 'panel1',
            appointments: [],
            caregiverMap: null,
            providerMap: null,
            patientMap: null,
            pieChartData: [],
            lineChartData: null,
            areaChartData: null,
            usersList: []
        };
        this.getChartDetails = this.getChartDetails.bind(this);
        this.getAppointments = this.getAppointments.bind(this);
        this.fetchAllProvidersAPI = this.fetchAllProvidersAPI.bind(this);
        this.fetchAllCaregiversAPI = this.fetchAllCaregiversAPI.bind(this);
        this.props.parentCallback(true, true);
    }

    componentDidMount() {
        this.props.spinnerLoader(true);
        fetchAllPatientsAPI()
            .then(res => {
                this.props.spinnerLoader(false);
                console.log('res patients ', res);
                if (Array.isArray(res.data)) {
                    this.setState({
                        usersList: res.data
                    });
                }
                this.fetchAllCaregiversAPI();
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    fetchAllCaregiversAPI() {
        this.props.spinnerLoader(true);
        fetchAllCaregiversAPI().then(response => {
            this.props.spinnerLoader(false);
            console.log('res caregiver ', response);
            if (Array.isArray(response.data)) {
                this.setState({
                    usersList: this.state.usersList.concat(response.data)
                });
            }
            this.fetchAllProvidersAPI();
        }).catch((error) => {
            this.props.spinnerLoader(false);
            console.log('Error', error);
        });
    }
    
    fetchAllProvidersAPI() {
        this.props.spinnerLoader(true);
        fetchAllProvidersAPI()
            .then(response => {
                console.log('res provider ', response);
                this.props.spinnerLoader(false);
                if (Array.isArray(response.data)) {
                    this.setState({
                        usersList: this.state.usersList.concat(response.data)
                    });
                }
                this.getAppointments();
            })
            .catch(err => {
                this.props.spinnerLoader(false);
                console.log("failure ", err);
            });
    }

    getAppointments() {
        this.props.spinnerLoader(true);
        fetchAppointmentsAPI(this.state.user.userID, this.state.user.userType)
            .then(res => {
                console.log('res fetchAppointmentsAPI ', res);
                const appointments = convertResponseToAppointmentVO(res.data !== 'Failed to submit transaction!!' ? res.data : [], this.state.usersList, this.props.user);
                this.setState({
                    appointments: appointments.appointmentList,
                    caregiverMap: appointments.caregiverMap,
                    providerMap: appointments.providerMap,
                    patientMap: appointments.patientMap,
                    totalPatients: appointments.totalPatients,
                    totalProviders: appointments.totalProviders,
                    totalCaregivers: appointments.totalCaregivers,
                    totalRefereals: appointments.totalRefereals,
                    pastAppointments: appointments.pastAppointments,
                    upcomingAppointments: appointments.upcomingAppointments,
                    scheduledAppointments: appointments.scheduledAppointments,
                    pendingAppointments: appointments.pendingAppointments,
                    caregiverName: appointments.caregiverName,
                    pendingAppointmentsWithUser: appointments.pendingAppointmentsWithUser,
                    pendingAppointmentsWithOtherUser: appointments.pendingAppointmentsWithOtherUser
                });
                try{
                    this.getChartDetails();
                    this.props.spinnerLoader(false);
                } catch(err) {
                    console.log('GetChartDetails Error ', err);
                    this.props.spinnerLoader(false);
                }
            })
            .catch(err => {
                console.log("fetchAppointmentsAPI " + err);
                this.props.spinnerLoader(false);
            });
    }

    getChartDetails() {
        const pieChartData = [
            {
                "label": "Past",
                "value": this.state.pastAppointments
            },
            {
                "label": "Upcoming",
                "value": this.state.upcomingAppointments
            },
            {
                "label": "Scheduled",
                "value": this.state.scheduledAppointments
            },
            {
                "label": "Pending",
                "value": this.state.pendingAppointments
            }
        ];

        const data = this.state.appointments.sort((obj1, obj2) => {
            if (obj1.appointmentStart > obj2.appointmentStart) {
              return 1;
            }
            if (obj1.appointmentStart < obj2.appointmentStart) {
              return -1;
            }
            return 0;
        });

        let group = data.reduce((r, a) => {
            r[a.monthAndYear] = [...r[a.monthAndYear] || [], a];
            return r;
        }, {});

        var labels = [];
        var appointments = [];
        var patients = [];
        var scheduled = [];
        var rejected = [];
        var pending = [];
        var total = [];
        
        for (const [key, monthData] of Object.entries(group)) {
            labels.push(key);
            appointments.push(monthData.length);
            const groupByPatients = monthData.reduce((r, a) => {
                r[a.patientID] = [...r[a.patientID] || [], a];
                return r;
            }, {});
            var scheduledT = 0;
            var rejectedT = 0;
            var pendingT = 0;
            var totalT = 0;
            var pat = 0;
            // eslint-disable-next-line
            for (const [key, value] of Object.entries(groupByPatients)) {
                for(var app of value) {
                    totalT++;
                    if (app.appointmentCurrentState.includes("Scheduled")) {
                        scheduledT++;
                    } else if (app.appointmentCurrentState.includes('Pending')) {
                        pendingT++;
                    } else {
                        rejectedT++;
                    }
                }
                pat++;
            }
            patients.push(pat);
            total.push(totalT);
            scheduled.push(scheduledT);
            rejected.push(rejectedT);
            pending.push(pendingT);
        }

        const lineChartData = {
            labels: labels,
            datasets: [{
                data: patients,
                label: "Patients",
                borderColor: "#3e95cd",
                backgroundColor: "#3e95cd",
                fill: false
            }, {
                data: total,
                label: "Appointments",
                borderColor: "#3cba9f",
                backgroundColor: "#3cba9f",
                fill: false
            }]
        };

        const areaChartData = {
            labels: labels,
            datasets: [
                {
                    data: rejected,
                    label: "Rejected",
                    borderColor: "#ff3333",
                    backgroundColor: "#ff3333",
                    fill: 'origin'
                }, {
                    data: pending,
                    label: "Pending",
                    borderColor: "#4d4dff",
                    backgroundColor: "#4d4dff",
                    fill: 'origin'
                }, {
                    data: scheduled,
                    label: "Confirmed",
                    borderColor: "#3cba9f",
                    backgroundColor: "#3cba9f",
                    fill: 'origin'
                }, {
                    data: total,
                    label: "Total",
                    borderColor: "#3e95cd",
                    backgroundColor: "#3e95cd",
                    fill: 'origin'
                }
            ]
        };

        this.setState({
            pieChartData: pieChartData,
            lineChartData: lineChartData,
            areaChartData: areaChartData
        });
        console.log('this.state charts ', this.state);
    }

    render() {
        return (
            <div style={{ padding: '10px' }}>
                <Grid container spacing={2}>
                <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Scheduled Appointments
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.scheduledAppointments}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#00b359', height: 56, width: 56 }}>
                                            <Schedule />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Refered Appointments
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.totalRefereals}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: '#2684FF', height: 56, width: 56 }}>
                                            <LocalHospital />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Pending with Me
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.pendingAppointmentsWithUser}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: 'orange', height: 56, width: 56 }}>
                                            <Update />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={3}>
                        <Card variant="outlined">
                            <CardContent>
                                <Grid
                                    container
                                    justify="space-between"
                                    spacing={2}
                                >
                                    <Grid item xs={12} sm={8}>
                                        <Typography
                                            color="textSecondary"
                                            gutterBottom
                                            align='left'
                                        >
                                            Pending with Others
                                        </Typography>
                                        <Typography
                                            color="textPrimary"
                                            align='left'
                                        >
                                            Total: {this.state.pendingAppointmentsWithOtherUser}
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Avatar style={{ backgroundColor: 'orange', height: 56, width: 56 }}>
                                            <Update />
                                        </Avatar>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={4}>
                        <Card variant="outlined" style={{padding: '10px'}}>
                            <PieChart 
                              data = {this.state.pieChartData}
                              colors = {['#2684FF', '#3f51b5', '#00b359', 'orange']} />
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={8}>
                        <Card variant="outlined">
                            <LineChart userType = {this.props.user.userType} data = {this.state.lineChartData} />
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={4}>
                        <Card variant="outlined" style={{minHeight:'314px'}}>
                            <p style={{ float: 'left', fontSize: '1.0125rem', fontWeight: '500', paddingLeft: '20px', marginTop: '8px', marginBottom: '8px' }}>Upcoming Appointments</p>
                            <br/>
                            <div>
                            <CardContent>
                                <div style={{maxHeight: '300px', overflowY: 'auto', overflowX:'hidden'}}>
                                    {this.state.appointments.map((appointment) => (
                                        <div key={appointment.appointmentID}>
                                            <Grid container spacing={1} >
                                                <Grid item xs={12} sm={2}>
                                                    <div style={{backgroundColor:'gray', color:'white', borderRadius:'5px'}}><span>{appointment.date} <br/>{appointment.monthAndYear}</span></div>
                                                </Grid>
                                                <Grid item xs={12} sm={10}>
                                                    <span style={{float: 'left',fontSize:'15px', paddingLeft: '10px', paddingTop:'18px'}}>{appointment.timing} - {appointment.appointmentDescription} for {appointment.patientName} </span>
                                                </Grid>
                                            </Grid>
                                            <Divider variant="fullWidth" style={{marginBottom: '5px', marginTop: '5px'}}/>
                                        </div>
                                    ))}
                                    {this.state.appointments.length === 0 &&
                                        <span style={{paddingTop:'100px', paddingLeft:'80px'}}>No Appointments...</span>
                                    }
                                </div>
                            </CardContent>
                            </div>
                        </Card>
                    </Grid>
                    <Grid item xs={12} sm={8}>
                        <Card variant="outlined">
                            <AreaChart data = {this.state.areaChartData} />
                        </Card>
                    </Grid>
                </Grid>
            </div>
        );
    }
}

// getting the data
function mapStateToProps(state) {
    return state;
}

export default connect(mapStateToProps)(Provider);