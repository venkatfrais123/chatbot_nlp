import React from "react";
import CopyrightIcon from '@material-ui/icons/Copyright';
import { withStyles } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';

/*const HtmlTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}))(Tooltip);*/

export default function Footer() {
  return (
    <div style={{backgroundColor:"#37475a", color: "white", minHeight: "50px"}}>
      <div style={{paddingTop:"15px", float:"left"}}>
        <CopyrightIcon fontSize="small"/>
      </div>
      <div style={{paddingTop:"15px", float:"left"}}>
        <span> &nbsp;Anthem Inc 2020 </span>
      </div>
      {/*<div style={{paddingTop:"9px", float:"left"}}>
      <HtmlTooltip
        title={
          <React.Fragment>
            <Typography color="inherit">App Info</Typography>
            <b>{"Version:"}</b>{" 1.0"}<br/>
            <b>{"About:"}</b>{" Book/Confirm/Cancel your appointment in a web"}<br/>
          </React.Fragment>
        }
      >
        <Button style={{color: "white"}}><InfoOutlinedIcon/></Button>
      </HtmlTooltip>
      </div>*/}
      <div style={{paddingTop:"5px", float:"right"}}>
        <img src="assets/anthemLogo.jpg" alt="Anthem" width="140" height="40" />
      </div>
    </div>
  );
}