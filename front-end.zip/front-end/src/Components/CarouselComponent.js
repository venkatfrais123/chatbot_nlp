import React from 'react';
import Carousel from 'react-material-ui-carousel'

export default function CarouselComponent(props)
{
    var items = [
        {
            name: "Provider",
            description: "A doctor is someone who maintains or restores human health through the practice of medicine.!",
            location: "assets/Provider.jpg"
        },
        {
            name: "Care Giver",
            description: "A caregiver is a paid or unpaid member of a person's social network who helps them with activities of daily living.!",
            location: "assets/Caregiver.jpg"
        },
        {
            name: "Patient",
            description: "A person who is receiving medical care, or who is cared for by a particular doctor or dentist when necessary.!",
            location: "assets/Patient.jpg"
        }
    ]
 
    return (
        <Carousel indicators={false} animation={'fade'} timeout={100} navButtonsAlwaysVisible={true}>
            {
                items.map( (item, i) => <Item key={i} item={item} /> )
            }
        </Carousel>
    )
}
 
function Item(props)
{
    return (
        <div style={{color: 'white'}}>
            <img src={props.item.location} alt={props.item.name} width="700" height="528" />
            <span style={{fontSize: "1.5em"}}>{props.item.name}</span><br/>
            <span>{props.item.description}</span>
        </div>
    )
}