import axios from 'axios';

const API = '/api/';
//const API = 'http://localhost:8080/';

const headers = {
    'Content-Type':  'application/json',
    'Accept': 'application/json'
}

export const validateLoginAPI = (data) => {
    return axios(API + 'usersignup', {
        method: 'POST',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const createUserAPI = (data) => {
    return axios(API + 'usersignup', {
        method: 'POST',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const updateUserAPI = (data, loginType) => {
    return axios(API + getUpdateURI(loginType) +'/'+ data.userId, {
        method: 'PUT',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const registerAPI = (data, loginType) => {
    return axios(API + getRegisterURI(loginType), {
        method: 'POST',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const userInfoAPI = (userId, loginType) => {
    return axios(API + getQueryURI(loginType) + '/' + userId + '/', {
        method: 'GET',
        headers: headers,
    });
}

export const fetchAllUsersAPI = () => {
    return axios(API, {
        method: 'GET',
        headers: headers
    });
}

export const fetchAllPatientsAPI = () => {
    return axios(API + 'patqueryall/adminpat', {
        method: 'GET',
        headers: headers
    });
}

export const fetchAllCaregiversAPI = () => {
    return axios(API + 'cgqueryall/admincg', {
        method: 'GET',
        headers: headers
    });
}

export const fetchAllProvidersAPI = () => {
    return axios(API + 'proqueryall/adminpro', {
        method: 'GET',
        headers: headers
    });
}

export const fetchAppointmentsAPI = (userId, userType) => {
    return axios(API + 'userqueryall/' + userId + '/' + userType+'org', {
        method: 'GET',
        headers: headers
    });
}

export const createAppointmentAPI = (data) => {
    return axios(API + 'appcreate', {
        method: 'POST',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const updateAppointmentAPI = (data, userType) => {
    return axios(API + getAppointmentUpdateQueryURI(userType), {
        method: 'POST',
        headers: headers,
        data: JSON.stringify(data)
    });
}

export const fetchProfiles = () => {
    return axios(API, {
        method: 'GET',
        headers: headers
    });
}

export const fetchProfiles1 = async () => {
    let url = API;
    try {
        const response = await axios.get(url);
        return response;
    } catch (error) {
        console.log('failed to fetch Profiles')
        throw Error(error);
    }
}

export const fetchProfiles2 = async () => {
    return await axios.get('https://randomuser.me/api/?results=5').then(res =>{
        return res.data.results;
    });
}

export const POST = (data) => {
    return axios(`${API}/getappointments`, {
        method: 'POST',
        headers,
        data,
    });
}

export function getRegisterURI(loginType) {
    if(loginType === 'caregiver') {
      return 'cgregister';
    } else if(loginType === 'provider') {
      return 'proregister';
    }
    return 'patregister';
}
  
export function getUpdateURI(loginType) {
    if(loginType === 'caregiver') {
      return 'cgupdate';
    } else if(loginType === 'provider') {
      return 'proupdate';
    }
    return 'patupdate';
}

export function getQueryURI(orgType) {
    if(orgType === 'caregiver') {
      return 'cgquery';
    } else if(orgType === 'provider') {
      return 'proquery';
    }
    return 'patquery';
}

export function getAppointmentUpdateQueryURI(orgType) {
    if(orgType === 'caregiver') {
      return 'cgappointmentupdate';
    } else if(orgType === 'provider') {
      return 'proappointmentupdate';
    }
    return 'patappointmentupdate';
}