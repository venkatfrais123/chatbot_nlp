import moment from 'moment';

export function getInitials(name = '') {
    return name
        .replace(/\s+/, ' ')
        .split(' ')
        .slice(0, 2)
        .map((v) => v && v[0].toUpperCase())
        .join('');
}

export function getUserDetailsAsState(data) {
    var obj = {
        firstName: data.person.personFirstName,
        lastName: data.person.personLastName,
        username: data.userID,
        email: data.person.personEmail,
        phoneNumber: data.person.personPhone,
        address1: data.person.personAddress1,
        address2: data.person.personAddress2,
        city: data.person.personCity,
        state: data.person.personState,
        zip: data.person.personZip,
        memberOrganization: data.memberOrganization,
        memberId: data.memberID,
        patientId: data.patientID,
        caregiverName: data.caregiverName,
        caregiverId: data.caregiverID,
        providerId: data.providerID,
        providerType: data.providerType,
        institutionName: data.institutionName,
        institutionPhone: data.institutionPhone,
        institutionEmail: data.institutionEmail
    };

    var institutionAddress = data.institutionAddress;
    if(institutionAddress !== undefined && institutionAddress !== null) {
        obj.institutionAddress1 = institutionAddress.insaddress1;
        obj.institutionAddress2 = institutionAddress.insaddress2;
        obj.institutionCity = institutionAddress.inscity;
        obj.institutionState = institutionAddress.insstate;
        obj.institutionZip = institutionAddress.inszip;
    };
    return obj;
}

export function convertResponseToUserVO(users) {
    const providerMap = new Map();
    const caregiverMap = new Map();
    const patientMap = new Map();

    for(let user of users) {
        if(user.class === 'org.appointmentbook.caregivers' && user.userID !== 'admincg')
            caregiverMap.set(user.userId, user);
        else if(user.class === 'org.appointmentbook.providers' && user.userID !== 'adminpro')
            providerMap.set(user.userId, user);
        else if(user.class === 'org.appointmentbook.patients' && user.userID !== 'adminpat')
            patientMap.set(user.userId, user);
    }

    return {
        caregiverMap: caregiverMap,
        providerMap: providerMap,
        patientMap: patientMap
    }
}

export function convertResponseToAppointmentVO(appointments, users, user, appointmentsByMe) {
    var totalAppointments = 0;
    var pastAppointments = 0;
    var scheduledAppointments = 0;
    var pendingAppointmentsWithUser = 0;
    var pendingAppointmentsWithOtherUser = 0;
    var pendingAppointments = 0;
    var rejectedAppointments = 0;
    var upcomingAppointments = 0;
    var pendingAppointmentsList = [];
    var totalPatients = [];
    var totalProviders = [];
    var totalCaregivers = [];
    var totalRefereals = 0;
    var appointmentList = [];
    const currDate = new Date();
    var providerMap = new Map();
    var caregiverMap = new Map();
    var patientMap = new Map();
    var events = [];
    const userID = user.userID;

    for(let user1 of users) {
        if(user1.class === 'org.appointmentbook.caregivers' && user1.userID !== 'admincg')
            caregiverMap.set(user1.userID, user1);
        else if(user1.class === 'org.appointmentbook.providers' && user1.userID !== 'adminpro')
            providerMap.set(user1.userID, user1);
        else if(user1.class === 'org.appointmentbook.patients' && user1.userID !== 'adminpat')
            patientMap.set(user1.userID, user1);
    }

    for(let appointment of appointments) {
        if(appointment.appointmentCurrentState !== 'Appointment Scheduled') {
            if(user.userType === 'provider' && appointment.acceptedByPatient === 'true' && appointment.caregiverID !== '' && appointment.caregiverID !== 'NA' && appointment.acceptedByCaregiver !== 'true') {
                continue;
            } else if(user.userType === 'patient' && user.caregiverID !== 'NA' && appointment.acceptedByPatient !== 'true' && (appointment.acceptedByCaregiver !== 'true' || appointment.acceptedByProvider !== 'true')) {
                continue;
            } else if(user.userType === 'provider' && appointment.newProviderID !== 'NA' && userID !== appointment.newProviderID && !appointmentsByMe) {
                continue;
            }
        } else if(appointment.appointmentCurrentState === 'Appointment Scheduled' && user.userType === 'provider' && appointment.newProviderID !== 'NA' && userID !== appointment.newProviderID && !appointmentsByMe) {
            continue;
        }
        totalAppointments++;
        var [enableAccept, enableReject, isPending] = [false, false, false];
        var color = 'red';

        if(user.userID === appointment.providerID && appointment.newProviderID !== '' && appointment.newProviderID !== 'NA') {
            totalRefereals++;
        }

        totalPatients.push(appointment.patientID);
        totalProviders.push(appointment.providerID);
        totalCaregivers.push(appointment.caregiverID);

        appointment.percentage = appointment.percentage === '' ? 50 : Number(appointment.percentage);

        if(currDate > new Date(appointment.appointmentStart.split('T')[0])) {
            color = '#00cc00';
            pastAppointments++;
        } else {
            upcomingAppointments++;
            if(appointment.cancellationReason !== 'NA') {
                rejectedAppointments++;
            } else if(appointment.percentage === 100) {
                color = '#00cc00';
                scheduledAppointments++;
            } else {
                isPending = true;
                color = '#1a90ff';
                if(appointment.pendingWith === userID) {
                    pendingAppointmentsWithUser++;
                    appointment.appointmentCurrentState = 'Pending self confirmation';
                    enableAccept = true;
                    enableReject = true;
                } else {
                    pendingAppointmentsWithOtherUser++;
                }
            }
        }

        events.push({
            id: JSON.stringify(appointment),
            title: `${appointment.appointmentType} ${appointment.appointmentDescription}`,
            start: appointment.appointmentStart,
            end: appointment.appointmentEnd,
            backgroundColor: color,
            borderColor: color
        });

        const startDate = appointment.appointmentStart.split('T')[0];
        const endDate = appointment.appointmentEnd.split('T')[0];

        var appointmentObj = appointment;
        appointmentObj.timing = moment(appointment.appointmentStart).format('LT');
        appointmentObj.enableAccept = enableAccept;
        appointmentObj.enableReject = enableReject;
        appointmentObj.monthAndYear = moment(startDate).format('MMM \'YY');
        // appointmentObj.week = moment(startDate).format('YYYY MMM[-]W[st]');
        appointmentObj.date = moment(startDate).format('DD');
        appointmentObj.displayTime = startDate ===  endDate ? moment(appointment.appointmentStart).format('lll') + ' - ' + moment(appointment.appointmentEnd).format('LT'): 
            moment(appointment.appointmentStart).format('lll') + ' - ' + moment(appointment.appointmentEnd).format('lll');
        appointmentObj.avatarUrl = '/static/images/avatars/avatar_10.png';

        if(isPending) {
            pendingAppointments++;
            pendingAppointmentsList.push(appointmentObj);
        }
        
        appointmentList.push(appointmentObj);
    }
    
    appointmentList = appointmentList.sort((obj1, obj2) => {
        if (obj1.appointmentUpdateDate > obj2.appointmentUpdateDate) {
          return 1;
        }
        if (obj1.appointmentUpdateDate < obj2.appointmentUpdateDate) {
          return -1;
        }
        return 0;
    });

    var filteredPatients = totalPatients.filter(function(elem, pos) {return totalPatients.indexOf(elem) === pos;});
    var filteredProviders = totalProviders.filter(function(elem, pos) {return totalProviders.indexOf(elem) === pos;});
    var filteredCaregivers = totalCaregivers.filter(function(elem, pos) {return totalCaregivers.indexOf(elem) === pos;});

    return {
        totalAppointments: totalAppointments,
        pastAppointments: pastAppointments,
        scheduledAppointments: scheduledAppointments,
        pendingAppointments: pendingAppointments,
        pendingAppointmentsWithUser: pendingAppointmentsWithUser,
        pendingAppointmentsWithOtherUser: pendingAppointmentsWithOtherUser,
        rejectedAppointments: rejectedAppointments,
        upcomingAppointments: upcomingAppointments,
        appointmentList: appointmentList,
        pendingAppointmentsList: pendingAppointmentsList,
        caregiverMap: caregiverMap,
        providerMap: providerMap,
        patientMap: patientMap,
        totalPatients: filteredPatients.length,
        totalProviders: filteredProviders.length,
        totalCaregivers: filteredCaregivers.length,
        totalRefereals: totalRefereals,
        events: events
    }
}

export function filterAppointmentByDate(appointmentList, startDate, endDt) {
    var filteredList = [];
    const endDate = (endDt === null ? '9999-12-31' : endDt);
    for(let appointment of appointmentList) {
        const appStartDate = appointment.appointmentStart.split('T')[0];
        const appEndDate = appointment.appointmentEnd.split('T')[0];
        if((appStartDate >= startDate && appStartDate <= endDate) || (appEndDate >= startDate && appEndDate <= endDate)) {
            filteredList.push(appointment);
        }
    }
    return filteredList;
}