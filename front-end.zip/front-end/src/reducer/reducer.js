const local = JSON.parse(localStorage.getItem('state'));
const initialState = {
    user: local != null ? local : {person : {}}
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
       case 'UPDATE':
        localStorage.setItem('state', JSON.stringify(action.payload.user));
        return action.payload
       case 'REMOVE':
        localStorage.clear();
        return initialState
       default: 
        return state
    }
 }
 export default reducer;