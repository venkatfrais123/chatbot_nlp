#!/bin/bash

# Where am I?
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd "${DIR}/providerorg"

source ./providerorg.sh

peer lifecycle chaincode package cp.tar.gz --lang node --path ../patientorg/contract --label cp_0
peer lifecycle chaincode install cp.tar.gz

PACKAGE_ID=$''

while [ ! -n "$PACKAGE_ID" ]; do
    export PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[0].package_id')
    echo $PACKAGE_ID
done


peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA

#Organization - patientorg

cd "${DIR}/../patientorg"

source ./patientorg.sh

peer lifecycle chaincode package cp.tar.gz --lang node --path ./contract --label cp_0
peer lifecycle chaincode install cp.tar.gz

PACKAGE_ID=$''

while [ ! -n "$PACKAGE_ID" ]; do
    export PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[0].package_id')
    echo $PACKAGE_ID
done

peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA


#Organization - caregiverorg

cd "${DIR}/../caregiverorg"

source ./caregiverorg.sh

peer lifecycle chaincode package cp.tar.gz --lang node --path ../patientorg/contract --label cp_0
peer lifecycle chaincode install cp.tar.gz

PACKAGE_ID=$''

while [ ! -n "$PACKAGE_ID" ]; do
    export PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[0].package_id')
    echo $PACKAGE_ID
done


peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA

PACKAGE_ID=$''

peer lifecycle chaincode checkcommitreadiness --channelID mychannel --name appointmentcontract -v 0 --sequence 1

peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --peerAddresses localhost:7051 --tlsRootCertFiles ${PEER0_ORG1_CA} --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --peerAddresses localhost:13051 --tlsRootCertFiles ${PEER0_ORG4_CA} --channelID mychannel --name appointmentcontract -v 0 --sequence 1 --tls --cafile $ORDERER_CA --waitForEvent

#peer chaincode invoke -o localhost:7050  --ordererTLSHostnameOverride orderer.example.com --peerAddresses localhost:7051 --tlsRootCertFiles ${PEER0_ORG1_CA} --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --peerAddresses localhost:13051 --tlsRootCertFiles ${PEER0_ORG4_CA} --channelID mychannel --name appointmentcontract -c '{"Args":["instantiate"]}' ${PEER_ADDRESS_ORG1} ${PEER_ADDRESS_ORG2} ${PEER_ADDRESS_ORG4} --tls --cafile $ORDERER_CA --waitForEvent

#peer chaincode query -o localhost:7050  --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -c '{"Args":["org.hyperledger.fabric:GetMetadata"]}' --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --tls --cafile $ORDERER_CA | jq '.' -C | more