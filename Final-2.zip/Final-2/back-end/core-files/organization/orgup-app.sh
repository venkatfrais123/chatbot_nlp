#!/bin/bash

# Where am I?
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd "${DIR}/providerorg"

source ./providerorg.sh

peer lifecycle chaincode package appointment.tar.gz --lang golang --path ../caregiverorg/appointment-go --label appointment_1
peer lifecycle chaincode install appointment.tar.gz &> appointment.txt

#APP_PACKAGE_ID=$''

sleep 10

#while [ ! -n "$APP_PACKAGE_ID" ]; do
    #export APP_PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[3].package_id')
    export APP_PACKAGE_ID=$(tail -n 1 appointment.txt | awk 'NF>1{print $NF}')
    echo $APP_PACKAGE_ID
#done


peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $APP_PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA

#Organization - patientorg

cd "${DIR}/../patientorg"

source ./patientorg.sh

peer lifecycle chaincode package appointment.tar.gz --lang golang --path ../caregiverorg/appointment-go --label appointment_1
peer lifecycle chaincode install appointment.tar.gz &> appointment.txt

#APP_PACKAGE_ID=$''

sleep 10

#while [ ! -n "$APP_PACKAGE_ID" ]; do
    #export APP_PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[3].package_id')
    export APP_PACKAGE_ID=$(tail -n 1 appointment.txt | awk 'NF>1{print $NF}')
    echo $APP_PACKAGE_ID
#done

peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $APP_PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA


#Organization - caregiverorg

cd "${DIR}/../caregiverorg"

source ./caregiverorg.sh

peer lifecycle chaincode package appointment.tar.gz --lang golang --path ./appointment-go --label appointment_1
peer lifecycle chaincode install appointment.tar.gz &> appointment.txt

#APP_PACKAGE_ID=$''

sleep 10

#while [ ! -n "$APP_PACKAGE_ID" ]; do
    #export APP_PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[3].package_id')
    export APP_PACKAGE_ID=$(tail -n 1 appointment.txt | awk 'NF>1{print $NF}')
    echo $APP_PACKAGE_ID
#done


peer lifecycle chaincode approveformyorg --orderer localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -v 0 --package-id $APP_PACKAGE_ID --sequence 1 --tls --cafile $ORDERER_CA

#APP_PACKAGE_ID=$''

peer lifecycle chaincode checkcommitreadiness --channelID mychannel --name appointmentcontract -v 0 --sequence 1

peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --peerAddresses localhost:7051 --tlsRootCertFiles ${PEER0_ORG1_CA} --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --peerAddresses localhost:13051 --tlsRootCertFiles ${PEER0_ORG4_CA} --channelID mychannel --name appointmentcontract -v 0 --sequence 1 --tls --cafile $ORDERER_CA --waitForEvent

#peer chaincode invoke -o localhost:7050  --ordererTLSHostnameOverride orderer.example.com --peerAddresses localhost:7051 --tlsRootCertFiles ${PEER0_ORG1_CA} --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --peerAddresses localhost:13051 --tlsRootCertFiles ${PEER0_ORG4_CA} --channelID mychannel --name appointmentcontract -c '{"Args":["instantiate"]}' ${PEER_ADDRESS_ORG1} ${PEER_ADDRESS_ORG2} ${PEER_ADDRESS_ORG4} --tls --cafile $ORDERER_CA --waitForEvent

#peer chaincode query -o localhost:7050  --ordererTLSHostnameOverride orderer.example.com --channelID mychannel --name appointmentcontract -c '{"Args":["org.hyperledger.fabric:GetMetadata"]}' --peerAddresses localhost:9051 --tlsRootCertFiles ${PEER0_ORG2_CA} --tls --cafile $ORDERER_CA | jq '.' -C | more

#peer chaincode upgrade -o orderer.example.com:7050 --tls --cafile $ORDERER_CA -C mychannel -n appointmentcontract -v 1.1 -P "OR ('Org1MSP.peer','Org2MSP.peer', 'Org4MSP.peer')"