/*
 * SPDX-License-Identifier: Apache-2.0
 */

package appointmentcontract

import (
	"encoding/json"
	"fmt"
	"strings"

	ledgerapi "booking-app-2/core-files/organization/caregiverorg/appointment-go/ledger-api"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// Contract chaincode that defines
// the business logic for managing commercial
// paper
type Contract struct {
	contractapi.Contract
}

// Instantiate does nothing
func (c *Contract) Instantiate() {
	fmt.Println("Instantiated")
}

// CreateAppointment ....
func (c *Contract) CreateAppointment(ctx TransactionContextInterface, userID string, appointmentID string, patientID string, patientName string, providerID string, providerName string, newProviderID string, newProviderName string, caregiverID string, caregiverName string, appointmentStart string, appointmentEnd string, appointmentDescription string, appointmentType string, percentage string,
	acceptedByPatient string, acceptedByProvider string, acceptedByCaregiver string, appointmentStatus string, pendingWith string, appointmentCreationDate string, appointmentUpdateDate string, appointmentCurrentState string, cancellationReason string) (*AppointmentInfo, error) {

	appointment := AppointmentInfo{UserID: userID, AppointmentID: appointmentID, PatientID: patientID, PatientName: patientName, ProviderID: providerID, ProviderName: providerName, NewProviderID: newProviderID, NewProviderName: newProviderName, CaregiverID: caregiverID, CaregiverName: caregiverName, AppointmentStart: appointmentStart, AppointmentEnd: appointmentEnd, AppointmentDescription: appointmentDescription, AppointmentType: appointmentType, Percentage: percentage, AcceptedByPatient: acceptedByPatient, AcceptedByProvider: acceptedByProvider, AcceptedByCaregiver: acceptedByCaregiver, AppointmentStatus: appointmentStatus, PendingWith: pendingWith, AppointmentCreationDate: appointmentCreationDate, AppointmentUpdateDate: appointmentUpdateDate, AppointmentCurrentState: appointmentCurrentState, CancellationReason: cancellationReason}

	fmt.Println("Inside: ", appointment)
	err := ctx.GetAppointmentList().AddAppointment(&appointment)

	if err != nil {
		return nil, err
	}

	return &appointment, nil
}

// ListAppointment ...
func (c *Contract) ListAppointment(ctx TransactionContextInterface, patientID string, appointmentID string) (*AppointmentInfo, error) {
	fmt.Println("Appointment Query...")

	fmt.Println("AppointmentID: ", appointmentID)
	appointment, err := ctx.GetAppointmentList().GetAppointment(patientID, appointmentID)

	if err != nil {
		return nil, err
	}

	return appointment, nil
}

// UpdateAppointmentPat ...
func (c *Contract) UpdateAppointmentPat(ctx TransactionContextInterface, appointmentID string, patientID string, newProviderID string, newProviderName string, appointmentUpdateDate string, percentage string, pendingWith string, acceptedByPatient string, appointmentCurrentState string, cancellationReason string) (*AppointmentInfo, error) {
	fmt.Println("Appointment Update by patient...")

	appointment, err := ctx.GetAppointmentList().GetAppointment(patientID, appointmentID)
	if err != nil {
		return nil, err
	}
	fmt.Println("Appointment Details Before Update: ", appointment)

	if acceptedByPatient == "true" {
		appointment.SetAcceptedByPatient(acceptedByPatient)
		appointment.SetAppointmentStatus("AppointmentAcceptedByPatient")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
	} else {
		appointment.SetAcceptedByPatient(acceptedByPatient)
		appointment.SetAppointmentStatus("AppointmentRejectedByPatient")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetCancellationReason(cancellationReason)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
	}

	err = ctx.GetAppointmentList().UpdateAppointment(appointment)

	if err != nil {
		return nil, err
	}

	return appointment, nil
}

// UpdateAppointmentPro ...
func (c *Contract) UpdateAppointmentPro(ctx TransactionContextInterface, appointmentID string, patientID string, newProviderID string, newProviderName string, appointmentUpdateDate string, percentage string, pendingWith string, acceptedByProvider string, appointmentCurrentState string, cancellationReason string) (*AppointmentInfo, error) {
	fmt.Println("Appointment Update by provider...")

	appointment, err := ctx.GetAppointmentList().GetAppointment(patientID, appointmentID)
	if err != nil {
		return nil, err
	}
	fmt.Println("Appointment Details Before Update: ", appointment)

	if acceptedByProvider == "true" {
		appointment.SetAcceptedByProvider(acceptedByProvider)
		appointment.SetAppointmentStatus("AppointmentAcceptedByProvider")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
	} else {
		appointment.SetAcceptedByProvider(acceptedByProvider)
		appointment.SetAppointmentStatus("AppointmentRejectedByProvider")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetCancellationReason(cancellationReason)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
	}

	err = ctx.GetAppointmentList().UpdateAppointment(appointment)

	if err != nil {
		return nil, err
	}

	return appointment, nil
}

// ReferAppointment ...
func (c *Contract) ReferAppointment(ctx TransactionContextInterface, appointmentID string, patientID string, newProviderID string, newProviderName string, appointmentUpdateDate string, percentage string, pendingWith string, appointmentCurrentState string) (*AppointmentInfo, error) {
	fmt.Println("Appointment transferred by provider...")

	appointment, err := ctx.GetAppointmentList().GetAppointment(patientID, appointmentID)
	if err != nil {
		return nil, err
	}
	fmt.Println("Appointment Details Before Update: ", appointment)

	appointment.SetNewProviderID(newProviderID)
	appointment.SetNewProviderName(newProviderName)
	appointment.SetAppointmentStatus("Appointment referred to new Provider")
	appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
	// 01/26 updated
	appointment.SetAcceptedByCaregiver("NA")
	appointment.SetPercentage(percentage)
	appointment.SetPendingWith(pendingWith)
	appointment.SetAppointmentCurrentState(appointmentCurrentState)

	err = ctx.GetAppointmentList().UpdateAppointment(appointment)

	if err != nil {
		return nil, err
	}

	return appointment, nil
}

// UpdateAppointmentCg ...
func (c *Contract) UpdateAppointmentCg(ctx TransactionContextInterface, appointmentID string, patientID string, newProviderID string, newProviderName string, appointmentUpdateDate string, percentage string, pendingWith string, acceptedByCaregiver string, appointmentCurrentState string, cancellationReason string) (*AppointmentInfo, error) {
	fmt.Println("Appointment Update by caregiver...")

	appointment, err := ctx.GetAppointmentList().GetAppointment(patientID, appointmentID)
	if err != nil {
		return nil, err
	}
	fmt.Println("Appointment Details Before Update: ", appointment)

	if acceptedByCaregiver == "true" && appointment.NewProviderID == "NA" {
		fmt.Println("New Provider ID: ", appointment.NewProviderID)
		appointment.SetAcceptedByCaregiver(acceptedByCaregiver)
		appointment.SetAppointmentStatus("AppointmentAcceptedByCaregiver")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
		// 01/26 - Case 5
	} else if appointment.NewProviderID != "NA" && acceptedByCaregiver == "true" {
		fmt.Println("New Provider ID: ", appointment.NewProviderID)
		appointment.SetAcceptedByCaregiver(acceptedByCaregiver)
		appointment.SetAcceptedByProvider("NA")
		appointment.SetAppointmentStatus("AppointmentAcceptedByCaregiver")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
	} else {
		appointment.SetAcceptedByCaregiver(acceptedByCaregiver)
		appointment.SetAppointmentStatus("AppointmentRejectedByCaregiver")
		appointment.SetAppointmentUpdateDate(appointmentUpdateDate)
		appointment.SetCancellationReason(cancellationReason)
		appointment.SetPercentage(percentage)
		appointment.SetPendingWith(pendingWith)
		appointment.SetAppointmentCurrentState(appointmentCurrentState)
		appointment.SetNewProviderID(newProviderID)
		appointment.SetNewProviderName(newProviderName)
	}

	err = ctx.GetAppointmentList().UpdateAppointment(appointment)

	if err != nil {
		return nil, err
	}

	return appointment, nil
}

// ListAllApps Query...
func (c *Contract) ListAllApps(ctx TransactionContextInterface) ([]ledgerapi.QueryResult, error) {
	fmt.Println("Appointment Query...")

	index := "" + "~" + "" + "~" + ""

	appointment, err := ctx.GetAppointmentList().GetAppointmentByPartialCompositeKey(index, "APPOINTMENTS")

	if err != nil {
		return nil, err
	}

	return appointment, err
}

// UserApps ..
func (c *Contract) UserApps(ctx TransactionContextInterface, userID string, orgname string) (rets []*AppointmentInfo, err error) {

	var queryString string

	if orgname == "patientorg" {
		queryString = `{"selector": {"patientID":{"$eq":"` + userID + `"}}}`
	} else if orgname == "providerorg" {
		//queryString = `{"selector": {"providerID":{"$eq":"` + userID + `"}}}`
		queryString = `{"selector": {"$or": [{"providerID": {"$eq": "` + userID + `"}},{"newProviderID": {"$eq": "` + userID + `"}}]}}`
	} else {
		queryString = `{"selector": {"caregiverID":{"$eq":"` + userID + `"}}}`
	}

	fmt.Println("QueryStrng: ", queryString)

	resultsIterator, _, err := ctx.GetStub().GetQueryResultWithPagination(queryString, 0, "")
	fmt.Println("ResultIterator: ", resultsIterator)
	if err != nil {
		return
	}
	defer resultsIterator.Close()

	for resultsIterator.HasNext() {
		queryResponse, err2 := resultsIterator.Next()
		if err2 != nil {
			return nil, err2
		}

		fmt.Println("queryresp: ", queryResponse.Value)

		res := new(AppointmentInfo)
		if err = json.Unmarshal(queryResponse.Value, res); err != nil {
			return
		}

		rets = append(rets, res)
	}
	fmt.Println("Rets: ", rets)

	return rets, err
}

// DateRangeQuery ..
func (c *Contract) DateRangeQuery(ctx TransactionContextInterface, userID string, appointmentStart string, appointmentEnd string) (rets []*AppointmentInfo, err error) {

	//queryString := `{"selector": {"$and": [{"appointmentEnd": {"$gte": "` + appointmentStart + `"}},{"appointmentStart": {"$lte": "` + appointmentEnd + `"}}]}}`
	///fmt.Println("QueryStrng: ", queryString)

	appDate := strings.Split(appointmentStart, "T")
	appointmentDate := appDate[0]
	fmt.Println("Appointment Date: ", appointmentDate)

	queryString := `{"selector": {"appointmentStart": {"$regex": "` + appointmentDate + `"}}}`
	iterator, _, err1 := ctx.GetStub().GetQueryResultWithPagination(queryString, 0, "")
	fmt.Println("ResultIterator: ", iterator)
	if err1 != nil {
		return
	}
	defer iterator.Close()

	for iterator.HasNext() {
		queryResponse, err2 := iterator.Next()
		if err2 != nil {
			return nil, err2
		}

		fmt.Println("queryresp: ", queryResponse.Value)

		res := new(AppointmentInfo)
		if err = json.Unmarshal(queryResponse.Value, res); err != nil {
			return
		}

		rets = append(rets, res)
	}
	return rets, err
}
