'use strict';

const fs = require('fs');
const yaml = require('js-yaml');
const { Wallets } = require("fabric-network");

class Initialize {

     static async getContract(gateway) {
    
        const wallet = await Wallets.newFileSystemWallet(
            "../identity/user/user2/wallet/"
          );
        // Check to see if we've already enrolled the user.
        /*const userExists = await wallet.exists('user2');
        if (!userExists) {
            console.log('An identity for the user "user2" does not exist in the wallet');
            return;
        }*/
    
        // const gateway = new Gateway();
        
        const userName = "user2";

        let connectionProfile = yaml.safeLoad(
            fs.readFileSync("../../../../organization/caregiverorg/gateway/connection-org2.yaml", "utf-8")
        );

        let connectionOptions = {
            identity: userName,
            wallet: wallet,
            discovery: { enabled: true, asLocalhost: true },
        };

        console.log("Connect to Fabric Gateway");

        await gateway.connect(connectionProfile, connectionOptions);
                   
        const network = await gateway.getNetwork('mychannel');

        let contract = await network.getContract('appointmentcontract');

        // issue commercial paper
        console.log('Submit create appointment transaction.');

        //console.log(contract);
        return contract;
    }
}

module.exports = Initialize;