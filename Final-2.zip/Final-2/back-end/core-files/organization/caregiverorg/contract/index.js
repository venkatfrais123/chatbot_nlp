
'use strict';

const appointmentcontract = require('./lib/appointmentcontract.js');
module.exports.contracts = [appointmentcontract];