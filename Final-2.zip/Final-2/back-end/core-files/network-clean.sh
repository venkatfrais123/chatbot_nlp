#!/bin/bash
#
# SPDX-License-Identifier: Apache-2.0

echo "deleting files"
cd "/home/venkat/go/src/booking-app-2/core-files/organization/providerorg/identity/user/"
rm -rf *
cd "/home/venkat/go/src/booking-app-2/core-files/organization/patientorg/identity/user/"
rm -rf *
cd "/home/venkat/go/src/booking-app-2/core-files/organization/caregiverorg/identity/user/"
rm -rf *

cd "/home/venkat/go/src/booking-app-2"

function _exit(){
    printf "Exiting:%s\n" "$1"
    exit -1
}

# Exit on first error, print all commands.
set -ev
set -o pipefail

# Where am I?
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo $DIR

export FABRIC_CFG_PATH="${DIR}/config"

cd "${DIR}/test-network/"

docker kill cliProviderOrg cliPatientOrg cliCaregiverOrg logspout || true
./network.sh down

# remove any stopped containers
docker rm $(docker ps -aq)
