package main

import "booking-app-2/core-files/api-layer/go-api/server"

func main() {
	s := server.NewServer()

	if err := s.Init(8080); err != nil {
		//if err := s.Init(80); err != nil {
		panic(err)
	}

	s.Start()
}
