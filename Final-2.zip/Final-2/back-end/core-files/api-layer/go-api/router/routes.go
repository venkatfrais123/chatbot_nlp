package router

import (
	"booking-app-2/core-files/api-layer/go-api/models"
	AppointmentHandler "booking-app-2/core-files/api-layer/go-api/routes/appointments"
	CgHandler "booking-app-2/core-files/api-layer/go-api/routes/caregiver"
	PatientHandler "booking-app-2/core-files/api-layer/go-api/routes/patients"
	ProviderHandler "booking-app-2/core-files/api-layer/go-api/routes/provider"
	UserHandler "booking-app-2/core-files/api-layer/go-api/routes/users"
	"log"
	"os"
)

func GetRoutes() models.Routes {

	err := os.Setenv("DISCOVERY_AS_LOCALHOST", "true")
	if err != nil {
		log.Fatalf("Error setting Discovery: %v", err)
	}

	return models.Routes{
		models.Route{Name: "Users", Method: "POST", Pattern: "/usersignup", HandlerFunc: UserHandler.Index},
		// Patient actions
		models.Route{Name: "Patients", Method: "POST", Pattern: "/patregister", HandlerFunc: PatientHandler.Register},
		models.Route{Name: "Patients", Method: "PUT", Pattern: "/patupdate/{UserID}", HandlerFunc: PatientHandler.Update},
		models.Route{Name: "Patients", Method: "GET", Pattern: "/patquery/{UserID}/", HandlerFunc: PatientHandler.Query},
		models.Route{Name: "Patients", Method: "POST", Pattern: "/patappointmentupdate", HandlerFunc: PatientHandler.Appointmentupdate},
		models.Route{Name: "Patients", Method: "GET", Pattern: "/patqueryall/{UserID}", HandlerFunc: PatientHandler.QueryAll},
		// Caregiver actions
		models.Route{Name: "Caregivers", Method: "POST", Pattern: "/cgregister", HandlerFunc: CgHandler.Register},
		models.Route{Name: "Caregivers", Method: "PUT", Pattern: "/cgupdate/{UserID}", HandlerFunc: CgHandler.Update},
		models.Route{Name: "Caregivers", Method: "GET", Pattern: "/cgquery/{UserID}/", HandlerFunc: CgHandler.Query},
		models.Route{Name: "Caregivers", Method: "POST", Pattern: "/cgappointmentupdate", HandlerFunc: CgHandler.Appointmentupdate},
		models.Route{Name: "Caregivers", Method: "GET", Pattern: "/cgqueryall/{UserID}", HandlerFunc: CgHandler.QueryAll},
		// Provider actions
		models.Route{Name: "Providers", Method: "POST", Pattern: "/proregister", HandlerFunc: ProviderHandler.Register},
		models.Route{Name: "Providers", Method: "PUT", Pattern: "/proupdate/{UserID}", HandlerFunc: ProviderHandler.Update},
		models.Route{Name: "Providers", Method: "POST", Pattern: "/proappointmentupdate", HandlerFunc: ProviderHandler.Appointmentupdate},
		models.Route{Name: "Providers", Method: "GET", Pattern: "/proquery/{UserID}/", HandlerFunc: ProviderHandler.QueryPro},
		models.Route{Name: "Providers", Method: "GET", Pattern: "/proqueryall/{UserID}", HandlerFunc: ProviderHandler.QueryAll},
		// Appointments actions
		models.Route{Name: "Appointments", Method: "POST", Pattern: "/appcreate", HandlerFunc: AppointmentHandler.Create},
		models.Route{Name: "Appointments", Method: "GET", Pattern: "/appquery/{UserID}/{Orgname}/{PatientID}/{AppointmentID}", HandlerFunc: AppointmentHandler.Query},
		models.Route{Name: "Appointments", Method: "GET", Pattern: "/appqueryall/{UserID}/{Orgname}", HandlerFunc: AppointmentHandler.QueryAll},
		models.Route{Name: "Appointments", Method: "GET", Pattern: "/userqueryall/{UserID}/{Orgname}", HandlerFunc: AppointmentHandler.UserQuery},
		// 02/08
		models.Route{Name: "Appointments", Method: "GET", Pattern: "/datequery/{UserID}/{Orgname}/{AppStart}/{AppEnd}", HandlerFunc: AppointmentHandler.DateQuery},
	}
}
