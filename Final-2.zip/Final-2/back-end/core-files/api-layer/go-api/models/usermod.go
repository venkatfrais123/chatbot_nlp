package models

type Person struct {
	PersonFirstName string `json:"personFirstName"`
	PersonLastName  string `json:"personLastName"`
	PersonEmail     string `json:"personEmail"`
	PersonPhone     string `json:"personPhone"`
	PersonAddress1  string `json:"personAddress1"`
	PersonAddress2  string `json:"personAddress2"`
	PersonCity      string `json:"personCity"`
	PersonState     string `json:"personState"`
	PersonZip       string `json:"personZip"`
}

type Address struct {
	InsAddress1 string `json:"insaddress1"`
	InsAddress2 string `json:"insaddress2"`
	InsCity     string `json:"inscity"`
	InsState    string `json:"insstate"`
	InsZip      string `json:"inszip"`
}
