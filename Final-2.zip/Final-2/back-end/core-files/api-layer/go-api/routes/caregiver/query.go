/*{
	"userID": "cg1",
	"caregiverID": "1"
} */

package caregivers

import (
	"fmt"
	"net/http"
	"path/filepath"

	"github.com/gorilla/mux"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

/*
type QueryDetails struct {
	UserID      string `json:"userID"`
	CaregiverID string `json:"caregiverID"`
}
*/

func Query(w http.ResponseWriter, r *http.Request) {
	//var queryCaregiver QueryDetails

	UserID := mux.Vars(r)["UserID"]
	//CaregiverID := mux.Vars(r)["CaregiverID"]

	orgname := "caregiverorg"
	/*
		reqBody, err := ioutil.ReadAll(r.Body)
		if err != nil {
			fmt.Fprintf(w, "Enter correct details!!")
		}

		json.Unmarshal(reqBody, &queryCaregiver)

		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(queryCaregiver)

		fmt.Println("Caregiver: ", queryCaregiver)
		fmt.Println("CG Details: ", queryCaregiver.UserID)
	*/
	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org2.example.com",
		"connection-org2.yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		orgname,
		"identity",
		"user",
		UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("caregivercontract")

	result, err := contract.EvaluateTransaction("ListCaregiver", UserID)
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		fmt.Printf("Failed to submit transaction: %s\n", err)
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
