/*{
	"userID": "pat1",
	"patientID": "1",
	"providerID": "1",
	"providerName": "James",
	"caregiverID": "1",
	"caregiverName": "Harry",
	"personFirstName": "Mark",
	"personLastName": "Ruffalo",
	"personEmail": "mark.r@abc.com",
	"personPhone": "987654",
	"personAddress1": "12, Whittakers Rd",
	"personAddress2": "Cadbury colony",
	"personCity": "Mason",
	"personState": "OH",
	"personZip": "123"
} */

package patients

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"

	"github.com/gorilla/mux"

	"booking-app-2/core-files/api-layer/go-api/models"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type PatientUpdate struct {
	models.Person
	MemberOrganization string `json:"memberOrganization"`
	MemberID           string `json:"memberID"`
	PatientID          string `json:"patientID"`
	ProviderID         string `json:"providerID"`
	ProviderName       string `json:"providerName"`
	CaregiverID        string `json:"caregiverID"`
	CaregiverName      string `json:"caregiverName"`
}

func Update(w http.ResponseWriter, r *http.Request) {
	var newPatient PatientUpdate

	UserID := mux.Vars(r)["UserID"]

	orgname := "patientorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &newPatient)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(newPatient)

	fmt.Println("Patient: ", newPatient)
	fmt.Println("Pat Details: ", UserID)

	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org4.example.com",
		"connection-org4.yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		orgname,
		"identity",
		"user",
		UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("patientcontract")

	personresponse, err := json.Marshal(newPatient.Person)
	if err != nil {
		fmt.Println("Error: ", err)
	}

	//time.Sleep(8 * time.Second)
	//node
	result, err := contract.SubmitTransaction("UpdatePatient", UserID, newPatient.PatientID, newPatient.ProviderID, newPatient.ProviderName, newPatient.CaregiverID, newPatient.CaregiverName, string(personresponse))

	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		fmt.Printf("Failed to submit transaction: %s\n", err)
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
