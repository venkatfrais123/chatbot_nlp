/*{
	"userID": "pat1",
	"patientID": "1"
} */

package patients

import (
	"fmt"
	"net/http"
	"path/filepath"

	"github.com/gorilla/mux"
	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

/*
type QueryDetails struct {
	UserID    string `json:"userID"`
	PatientID string `json:"patientID"`
}
*/
func Query(w http.ResponseWriter, r *http.Request) {
	//var queryPatient QueryDetails

	UserID := mux.Vars(r)["UserID"]
	//PatientID := mux.Vars(r)["PatientID"]

	orgname := "patientorg"
	/*
		reqBody, err := ioutil.ReadAll(r.Body)
		if err != nil {
			fmt.Fprintf(w, "Enter correct details!!")
		}

		json.Unmarshal(reqBody, &queryPatient)

		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(queryPatient)

		fmt.Println("Patient: ", queryPatient)
		fmt.Println("Pat Details: ", queryPatient.UserID)
	*/
	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org4.example.com",
		"connection-org4.yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		orgname,
		"identity",
		"user",
		UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("patientcontract")
	//node
	result, err := contract.EvaluateTransaction("ListPatient", UserID)

	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
