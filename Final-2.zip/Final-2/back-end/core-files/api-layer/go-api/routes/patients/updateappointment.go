/*{
	"patientID": "1",
	"appointmentID": "1",
	"updateDate": "123",
	"acceptedByPatient": "true",
	"cancellationReason": "NA",
	"userID": "pat1"
} */

package patients

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type appointmentdetails struct {
	AppointmentID           string `json:"appointmentID"`
	PatientID               string `json:"patientID"`
	NewProviderID           string `json:"newProviderID"`
	NewProviderName         string `json:"newProviderName"`
	UpdateDate              string `json:"appointmentUpdateDate"`
	Percentage              string `json:"percentage"`
	PendingWith             string `json:"pendingWith"`
	AcceptedByPatient       string `json:"acceptedByPatient"`
	AppointmentCurrentState string `json:"appointmentCurrentState"`
	CancellationReason      string `json:"cancellationReason"`
	UserID                  string `json:"userID"`
}

func Appointmentupdate(w http.ResponseWriter, r *http.Request) {
	var appointment appointmentdetails
	orgname := "patientorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &appointment)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(appointment)

	fmt.Println("Patient: ", appointment)
	fmt.Println("Pat Details: ", appointment.UserID)

	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org4.example.com",
		"connection-org4.yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		orgname,
		"identity",
		"user",
		appointment.UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, appointment.UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")
	//node
	result, err := contract.SubmitTransaction("UpdateAppointmentPat", appointment.AppointmentID, appointment.PatientID, appointment.NewProviderID, appointment.NewProviderName, appointment.UpdateDate, appointment.Percentage, appointment.PendingWith, appointment.AcceptedByPatient, appointment.AppointmentCurrentState, appointment.CancellationReason)

	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
