/*{
	"patientID": "1",
	"appointmentID": "1",
	"updateDate": "12/21/2020",
	"acceptedByProvider": "True",
	"cancellationReason": "NA",
	"userID": "pro1",
	"isReferral": "NA",
	"newProviderID": "NA"
} */

package providers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type appointmentdetails struct {
	AppointmentID           string `json:"appointmentID"`
	PatientID               string `json:"patientID"`
	NewProviderID           string `json:"newProviderID"`
	NewProviderName         string `json:"newProviderName"`
	UpdateDate              string `json:"appointmentUpdateDate"`
	Percentage              string `json:"percentage"`
	PendingWith             string `json:"pendingWith"`
	AcceptedByProvider      string `json:"acceptedByProvider"`
	AppointmentCurrentState string `json:"appointmentCurrentState"`
	CancellationReason      string `json:"cancellationReason"`
	IsReferral              string `json:"isReferral"`
	UserID                  string `json:"userID"`
}

func Appointmentupdate(w http.ResponseWriter, r *http.Request) {
	var appointment appointmentdetails
	//orgname := "providerorg"

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &appointment)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(appointment)

	fmt.Println("Provider: ", appointment)
	fmt.Println("Pro Details: ", appointment.UserID)

	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		"org1.example.com",
		"connection-org1.yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		"providerorg",
		"identity",
		"user",
		appointment.UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, appointment.UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")

	if appointment.IsReferral == "NA" {
		result, err := contract.SubmitTransaction("UpdateAppointmentPro", appointment.AppointmentID, appointment.PatientID, appointment.NewProviderID, appointment.NewProviderName, appointment.UpdateDate, appointment.Percentage, appointment.PendingWith, appointment.AcceptedByProvider, appointment.AppointmentCurrentState, appointment.CancellationReason)
		if err != nil {
			fmt.Printf("Failed to submit transaction: %s\n", err)
			//os.Exit(1)
		}
		fmt.Println(string(result))
		w.Write([]byte(string(result)))
	} else {
		result, err := contract.SubmitTransaction("ReferAppointment", appointment.AppointmentID, appointment.PatientID, appointment.NewProviderID, appointment.NewProviderName, appointment.UpdateDate, appointment.Percentage, appointment.PendingWith, appointment.AppointmentCurrentState)
		if err != nil {
			fmt.Printf("Failed to submit transaction: %s\n", err)
			//os.Exit(1)
			w.Write([]byte(string("Request Failed!!")))
		}
		fmt.Println(string(result))
		w.Write([]byte(string(result)))
	}
}
