/*{
	"patientID": "1",
	"appointmentID": "1"
} */

package appointments

import (
	"fmt"
	"net/http"
	"path/filepath"

	"github.com/gorilla/mux"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

/*
type QueryDetails struct {
	PatientID     string `json:"patientID"`
	AppointmentID string `json:"appointmentID"`
	UserID        string `json:"userID"`
	Orgname       string `json:"orgname"`
}*/

// UserQuery ...
func UserQuery(w http.ResponseWriter, r *http.Request) {
	/*var queryAppointment QueryDetails

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &queryAppointment)

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(queryAppointment)

	fmt.Println("Appointment: ", queryAppointment)
	fmt.Println("User: ", queryAppointment.UserID)
	*/

	UserID := mux.Vars(r)["UserID"]
	Orgname := mux.Vars(r)["Orgname"]
	//PatientID := mux.Vars(r)["PatientID"]
	//AppointmentID := mux.Vars(r)["AppointmentID"]

	if Orgname == "providerorg" {
		org = "org1"
	} else if Orgname == "caregiverorg" {
		org = "org2"
	} else if Orgname == "patientorg" {
		org = "org4"
	} else {
		fmt.Println("Invalid Argument")
	}

	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		""+org+".example.com",
		"connection-"+org+".yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		Orgname,
		"identity",
		"user",
		UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")

	//node
	//result, err := contract.EvaluateTransaction("listAppointment", queryAppointment.PatientID, queryAppointment.AppointmentID)
	//go
	result, err := contract.EvaluateTransaction("UserApps", UserID, Orgname)
	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to submit transaction!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
