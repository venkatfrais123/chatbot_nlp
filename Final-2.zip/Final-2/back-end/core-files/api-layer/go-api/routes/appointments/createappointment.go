/*{
	"patientID": "1",
	"providerID": "1",
	"newProviderID": "NA",
	"caregiverID": "1",
	"appointmentStart": "10",
	"appointmentEnd": "11",
	"appointmentDescription": "Description",
	"appointmentType": "Operation",
	"acceptedByPatient": "True",
	"acceptedByProvider": "NA",
	"acceptedByCaregiver": "NA",
	"appointmentStatus": "Created by Patient",
	"appointmentCreationDate": "12/21",
	"appointmentUpdateDate": "12/22",
	"cancellationReason": "NA",
	"userID": "pat1",
	"orgname": "patientorg"
}

*/

package appointments

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"
	"strconv"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

// Appointment ..
type Appointment struct {
	AppointmentID           string `json:"appointmentID"`
	PatientID               string `json:"patientID"`
	PatientName             string `json:"patientName"`
	ProviderID              string `json:"providerID"`
	ProviderName            string `json:"providerName"`
	NewProviderID           string `json:"newProviderID"`
	NewProviderName         string `json:"newProviderName"`
	CaregiverID             string `json:"caregiverID"`
	CaregiverName           string `json:"caregiverName"`
	AppointmentStart        string `json:"appointmentStart"`
	AppointmentEnd          string `json:"appointmentEnd"`
	AppointmentDescription  string `json:"appointmentDescription"`
	AppointmentType         string `json:"appointmentType"`
	Percentage              string `json:"percentage"`
	AcceptedByPatient       string `json:"acceptedByPatient"`
	AcceptedByProvider      string `json:"acceptedByProvider"`
	AcceptedByCaregiver     string `json:"acceptedByCaregiver"`
	AppointmentStatus       string `json:"appointmentStatus"`
	PendingWith             string `json:"pendingWith"`
	AppointmentCreationDate string `json:"appointmentCreationDate"`
	AppointmentUpdateDate   string `json:"appointmentUpdateDate"`
	AppointmentCurrentState string `json:"appointmentCurrentState"`
	CancellationReason      string `json:"cancellationReason"`
	UserID                  string `json:"userID"`
	Orgname                 string `json:"orgname"`
}

// Appointments ..
type Appointments []Appointment

var allAppointments = Appointments{}

var org = ""

// Create ..
func Create(w http.ResponseWriter, r *http.Request) {
	var newAppointment Appointment

	appointmentLen := len(allAppointments) + 1

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Fprintf(w, "Enter correct details!!")
	}

	json.Unmarshal(reqBody, &newAppointment)
	newAppointment.AppointmentID = "APP" + strconv.Itoa(appointmentLen)
	allAppointments = append(allAppointments, newAppointment)

	w.WriteHeader(http.StatusCreated)
	//json.NewEncoder(w).Encode(newAppointment)

	fmt.Println("Appointment: ", newAppointment)
	fmt.Println("User Details: ", newAppointment.UserID)

	if newAppointment.Orgname == "providerorg" {
		org = "org1"
	} else if newAppointment.Orgname == "caregiverorg" {
		org = "org2"
	} else if newAppointment.Orgname == "patientorg" {
		org = "org4"
	} else {
		fmt.Println("Invalid Argument")
		w.Write([]byte(string("Invalid Organization Name!!")))
	}

	ccpPath := filepath.Join(
		"..",
		"..",
		"..",
		"test-network",
		"organizations",
		"peerOrganizations",
		""+org+".example.com",
		"connection-"+org+".yaml",
	)

	walletPath := filepath.Join(
		"..",
		"..",
		"..",
		"core-files",
		"organization",
		newAppointment.Orgname,
		"identity",
		"user",
		newAppointment.UserID,
		"wallet",
	)

	fmt.Println("Wallet Path: ", walletPath)

	wallet, err := gateway.NewFileSystemWallet(walletPath)
	if err != nil {
		fmt.Printf("Failed to create wallet: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to create wallet!!")))
	}

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, newAppointment.UserID),
	)
	if err != nil {
		fmt.Printf("Failed to Connect to Gateway: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to gateway!!")))
	}
	defer gw.Close()

	network, err := gw.GetNetwork("mychannel")
	if err != nil {
		fmt.Printf("Failed to get network: %s", err)
		//os.Exit(1)
		w.Write([]byte(string("Failed to connect to network!!")))
	}

	contract := network.GetContract("appointmentcontract")
	//node
	/*result, err := contract.SubmitTransaction("createAppointment", newAppointment.UserID, newAppointment.AppointmentID, newAppointment.PatientID, newAppointment.ProviderID, newAppointment.NewProviderID, newAppointment.CaregiverID,
	newAppointment.AppointmentStart, newAppointment.AppointmentEnd, newAppointment.AppointmentDescription, newAppointment.AppointmentType, newAppointment.AcceptedByPatient, newAppointment.AcceptedByProvider, newAppointment.AcceptedByCaregiver,
	newAppointment.AppointmentStatus, newAppointment.AppointmentCreationDate, newAppointment.AppointmentUpdateDate, newAppointment.CancellationReason)
	*/
	//go
	result, err := contract.SubmitTransaction("CreateAppointment", newAppointment.UserID, newAppointment.AppointmentID, newAppointment.PatientID, newAppointment.PatientName, newAppointment.ProviderID, newAppointment.ProviderName, newAppointment.NewProviderID, newAppointment.NewProviderName, newAppointment.CaregiverID, newAppointment.CaregiverName,
		newAppointment.AppointmentStart, newAppointment.AppointmentEnd, newAppointment.AppointmentDescription, newAppointment.AppointmentType, newAppointment.Percentage, newAppointment.AcceptedByPatient, newAppointment.AcceptedByProvider, newAppointment.AcceptedByCaregiver,
		newAppointment.AppointmentStatus, newAppointment.PendingWith, newAppointment.AppointmentCreationDate, newAppointment.AppointmentUpdateDate, newAppointment.AppointmentCurrentState, newAppointment.CancellationReason)

	if err != nil {
		fmt.Printf("Failed to submit transaction: %s\n", err)
		//os.Exit(1)
		w.Write([]byte(string("Request Failed!!")))
	}
	fmt.Println(string(result))

	w.Write([]byte(string(result)))
}
