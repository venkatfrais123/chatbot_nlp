    const initialize = require('../helpers/initialize.js');
    const { Gateway } = require('fabric-network');
    const caregiverContract = require("../../../../organization/patientorg/contract/lib/caregiver.js");
    const appointmentContract = require("../../../../organization/patientorg/contract/lib/appointment.js");
    
    let orgname = 'caregiverorg';
    
    let caregivers = [];
    console.log(caregivers);

    module.exports.caregivers = caregivers;

    //Registering a Provider     
    module.exports.postCaregiver = (req,res) => {
        let userId = req.swagger.params.userId.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
    
        let newCaregiver = req.body;

        postingCaregiver(newCaregiver, userId, orgname).then((data) => {
            console.log("Posting caregiver");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    postingCaregiver = async (newCaregiver, userId, orgname) => {
    
        let newCaregiverId = caregivers.length + 1;
        caregivers.push(newCaregiverId);

        console.log('NEW CAREGIVER ID: ' + newCaregiverId);
        
        let caregiverToPersist = {
            person: {
                personFirstName: newCaregiver.person.personFirstName,
                personLastName: newCaregiver.person.personLastName,
                personEmail: newCaregiver.person.personEmail,
                personPhone: newCaregiver.person.personPhone,
                address1: newCaregiver.person.address1,
                address2: newCaregiver.person.address2,
                city: newCaregiver.person.city,
                state: newCaregiver.person.state,
                zip: newCaregiver.person.zip
            },
            caregiverId: newCaregiverId
        }

        console.log("Caregiver Details:", caregiverToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let caregiverCreationResponse = await contract.submitTransaction('createCaregiver', 
            userId, JSON.stringify(caregiverToPersist.person), caregiverToPersist.caregiverId);
    
            //console.log(caregiverCreationResponse);
            let caregiverDetails = caregiverContract.fromBuffer(caregiverCreationResponse);
            console.log("caregiver details");
            console.log(caregiverDetails);
            return caregiverDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Caregiver not added to network. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    // Update existing provider info
    module.exports.updateCaregiver = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let caregiverUpdate = req.body;

        updatingCaregiver(caregiverUpdate, userId, orgname).then((data) => {
            console.log("Updating Caregiver");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingCaregiver = async (caregiverUpdate, userId, orgname) => {
    
        let caregiverToUpdate = {
            person: {
                personFirstName: caregiverUpdate.person.personFirstName,
                personLastName: caregiverUpdate.person.personLastName,
                personEmail: caregiverUpdate.person.personEmail,
                personPhone: caregiverUpdate.person.personPhone,
                address1: caregiverUpdate.person.address1,
                address2: caregiverUpdate.person.address2,
                city: caregiverUpdate.person.city,
                state: caregiverUpdate.person.state,
                zip: caregiverUpdate.person.zip
            },
            caregiverId: caregiverUpdate.caregiverId
        }

        console.log("Caregiver Details:", caregiverToUpdate);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let caregiverUpdateResponse = await contract.submitTransaction('updateCaregiver', 
            userId, JSON.stringify(caregiverToUpdate.person), caregiverToUpdate.caregiverId);
    
            console.log("Caregiver updated to the network");

            let caregiverDetails = caregiverContract.fromBuffer(caregiverUpdateResponse);
            console.log("caregiver details");
            console.log(caregiverDetails);
            return caregiverDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Provider not updated in the Ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    
    //Querying Caregivers based on Caregiver ID
    module.exports.getCaregiver = (req,res) => {
        let userId = req.swagger.params.userId.value;
        let caregiverId = req.swagger.params.caregiverId.value;

        console.log('Caregiver ID: ' + caregiverId);
        
        getCaregiverList(caregiverId, userId, orgname).then((data) => {
            console.log("Querying Caregiver");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    getCaregiverList = async (caregiverId, userId, orgname) => {
        const gateway = new Gateway();  
        const contract = await initialize.getContract(gateway, userId, orgname);
    
        try {
            let caregiverDetails = await contract.submitTransaction('listCaregiver', userId, caregiverId);
            
            let caregiverQuery = caregiverContract.fromBuffer(caregiverDetails);
            console.log("caregiver details");
            console.log(caregiverQuery);
            return caregiverQuery;
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Provider details not queried. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    // Update an appointment created by other organizations
    module.exports.updateAppointmentCg = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received for CG: ' + JSON.stringify(req.body));
        let appointmentUpdateCg = req.body;

        updatingAppointmentCG(appointmentUpdateCg, userId, orgname).then((data) => {
            console.log("Updating Appointment CG");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingAppointmentCG = async (appointmentUpdateCg, userId, orgname) => {
    
        let appointmentToUpdate = {
            appointmentId: appointmentUpdateCg.appointmentId,
            patientId: appointmentUpdateCg.patientId,
            appointmentUpdateDate: appointmentUpdateCg.appointmentUpdateDate,
            acceptedByCaregiver: appointmentUpdateCg.acceptedByCaregiver,
            cancellationReason: appointmentUpdateCg.cancellationReason
        }

        console.log("Appointment Details CG:", appointmentToUpdate);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
            
            let appointmentUpdateResponseCg = await contract.submitTransaction('updateAppointmentCg', 
            appointmentUpdateCg.patientId, appointmentUpdateCg.appointmentId, appointmentUpdateCg.appointmentUpdateDate,appointmentUpdateCg.acceptedByCaregiver, appointmentUpdateCg.cancellationReason);
            
            let appointmentDetailsCg = appointmentContract.fromBuffer(appointmentUpdateResponseCg);
            console.log("Appointment details - Updated");
            console.log(appointmentDetailsCg);
            return appointmentDetailsCg;

        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment not updated in the ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    