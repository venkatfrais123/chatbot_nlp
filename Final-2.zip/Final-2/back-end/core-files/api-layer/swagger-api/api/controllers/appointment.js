    const initialize = require('../helpers/initialize.js');
    const { Gateway } = require('fabric-network');
    const appointmentContract = require("../../../../organization/patientorg/contract/lib/appointment.js");
    
    let appointments = [];
    console.log(appointments);

    module.exports.appointments = appointments;

    //Creating an appointment
    module.exports.newAppointment = (req,res) => {
        let userId = req.swagger.params.userId.value;
        let orgname = req.swagger.params.orgname.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
    
        let newAppointment = req.body;

        createAppointment(newAppointment, userId, orgname).then((data) => {
            console.log("Creating an Appointment");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    createAppointment = async (newAppointment, userId, orgname) => {
    
        let newAppointmentId = appointments.length + 1;
        console.log('New Appointment ID: ' + newAppointmentId);
        appointments.push(newAppointmentId);
        
        let appointmentToPersist = {
            appointmentId: newAppointmentId,
            patientId: newAppointment.patientId,
            providerId: newAppointment.providerId,
            newProviderId: newAppointment.newProviderId,
            caregiverId: newAppointment.caregiverId,
            appointmentStart: newAppointment.appointmentStart,
            appointmentEnd: newAppointment.appointmentEnd,
            appointmentDescription: newAppointment.appointmentDescription,
            appointmentType: newAppointment.appointmentType,
            acceptedByPatient: newAppointment.acceptedByPatient,
            acceptedByProvider: newAppointment.acceptedByProvider,
            acceptedByCaregiver: newAppointment.acceptedByCaregiver,
            appointmentStatus: newAppointment.appointmentStatus,
            appointmentCreationDate: newAppointment.appointmentCreationDate,
            appointmentUpdateDate: newAppointment.appointmentUpdateDate,
            cancellationReason: newAppointment.cancellationReason
        }

        console.log("Appointment Details:", appointmentToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let appointmentCreationResponse = await contract.submitTransaction('createAppointment', 
                userId, appointmentToPersist.appointmentId, appointmentToPersist.patientId, appointmentToPersist.providerId, appointmentToPersist.newProviderId, appointmentToPersist.caregiverId, 
                appointmentToPersist.appointmentStart, appointmentToPersist.appointmentEnd, appointmentToPersist.appointmentDescription, appointmentToPersist.appointmentType, newAppointment.acceptedByPatient, newAppointment.acceptedByProvider, newAppointment.acceptedByCaregiver, appointmentToPersist.appointmentStatus,
                appointmentToPersist.appointmentCreationDate, appointmentToPersist.appointmentUpdateDate, appointmentToPersist.cancellationReason);
    
            console.log("Appointment added to the Ledger");

            let appointmentDetails = appointmentContract.fromBuffer(appointmentCreationResponse);
            console.log("Appointment details");
            console.log(appointmentDetails);
            return appointmentDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment not added to Ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    //Querying Appointments
    module.exports.getAppointments = (req,res) => {
        let userId = req.swagger.params.userId.value;
        let orgname = req.swagger.params.orgname.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let appointmentQuery = req.body;
                
        getAppointmentList(appointmentQuery, userId, orgname).then((data) => {
            console.log("Querying Appointment");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    getAppointmentList = async (appointmentQuery, userId, orgname) => {
        const gateway = new Gateway();  
        const contract = await initialize.getContract(gateway, userId, orgname);
    
        try {
            let appointmentDetails = await contract.submitTransaction('listAppointment', appointmentQuery.patientId, appointmentQuery.appointmentId);
            
            let appointmentInfo = appointmentContract.fromBuffer(appointmentDetails);
            console.log("Appointment details");
            console.log(appointmentInfo);
            return appointmentInfo;
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment details not queried. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }    