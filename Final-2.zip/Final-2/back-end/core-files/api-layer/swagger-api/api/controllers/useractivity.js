"user strict";

const fs = require("fs");
const { Wallets } = require("fabric-network");
const path = require("path");

//sign up module
module.exports.signup = (req, res) => {
    console.log(req)
    //console.log(JSON.stringify(req))
    let userId = req.body.userId;
    //let passkey = req.body.passkey;
    let orgname = req.body.orgname;

    signup(userId, orgname).then((data) => {
      let result = data;
      console.log("result:", result);
      samp = {status:"Added to Wallet"};
      return res.json(samp).status(200);
    });
}

signup = async (userId, orgname) => {

    console.log("Second")
    var org = "";
    var msp = "";

    if (orgname == "providerorg") {
        org = "org1";
        msp = "Org1MSP";
    } else if (orgname == "caregiverorg") {
        org = "org2";
        msp = "Org2MSP";
    } else if (orgname == "patientorg") {
        org = "org4";
        msp = "Org4MSP";
    } else {
        console.log("Invalid argument - Login Type");
    }
    
    console.log(org,msp);
    
    const fixtures = path.resolve(__dirname, "../../../../../test-network/");
    
    //const orgPath = "./"+orgname+"/identity/user/"+userId+"/wallet";
    const orgPath = "/home/venkat/hyper-samp/booking-app-2/core-files/organization/"+orgname+"/identity/user/"+userId+"/wallet"

    console.log(orgPath);
    
      try {
        // A wallet stores a collection of identities
        const wallet = await Wallets.newFileSystemWallet(orgPath);
    
        // Identity to credentials to be stored in the wallet
        const credPath = path.join(
          fixtures,
          "/organizations/peerOrganizations/"+org+".example.com/users/User1@"+org+".example.com"
        );
        console.log(credPath);
        const certificate = fs
          .readFileSync(
            path.join(credPath, "/msp/signcerts/User1@"+org+".example.com-cert.pem")
          )
          .toString();
        const privateKey = fs
          .readFileSync(path.join(credPath, "/msp/keystore/priv_sk"))
          .toString();
    
        // Load credentials into wallet
        const identityLabel = userId;
    
        const identity = {
          credentials: {
            certificate,
            privateKey,
          },
          mspId: msp,
          type: "X.509",
        };
    
        let resp = await wallet.put(identityLabel, identity);
        console.log("Signup - Done")
        console.log(resp);
        return ("Signed up");
    } catch (error) {
        console.log(`Error adding to wallet. ${error}`);
        console.log(error.stack);
        return ("false");
    }

}

//Login module
module.exports.login = (req, res) => {
    console.log(req)
    //console.log(JSON.stringify(req))
    let userId = req.body.userId;
    //let passkey = req.body.passkey;
    let orgname = req.body.orgname;

    loginUser(userId, orgname).then((data) => {
        let result = data;
        console.log("result:", result);
        samp = {status:"done"};
        return res.json(samp).status(200);
    });
}

loginUser = async (userId, orgname) => {

    const walletPath = "/home/venkat/hyper-samp/booking-app-2/core-files/organization/"+orgname+"/identity/user/"+userId+"/wallet"

    console.log(walletPath);
    
    const wallet = await Wallets.newFileSystemWallet(walletPath);

    const userExists = await wallet.get(userId);
    if (userExists) {
        console.log(`An Identity for the client user ${userId} exists`);
        return ("True");
    } else {
        console.log(`An Identity for the client user ${userId} doesnt exists`);
        return ("False");
    }

}
