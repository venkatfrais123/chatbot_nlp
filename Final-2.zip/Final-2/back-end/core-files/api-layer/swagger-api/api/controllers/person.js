/* 
let persons = [
{"personEmail":"john.smith@abc.com", "personPhone": "1234567890", "personFirstName": "John", "personLastName": "Smith", "address": {"address1":"123 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"jane.smith@abc.com", "personPhone": "1234567890","personFirstName": "Jane", "personLastName": "Smith", "address": {"address1":"345 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"jack.black@abc.com", "personPhone": "1234567890","personFirstName": "Jack", "personLastName": "Black", "address": {"address1":"678 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"james.brown@abc.com", "personPhone": "1234567890","personFirstName": "James", "personLastName": "Brown", "address": {"address1":"911 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"charlie.chaplin@abc.com", "personPhone": "1234567890","personFirstName": "Charlie", "personLastName": "Chaplin", "address": {"address1":"124 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"chuck.norris@abc.com", "personPhone": "1234567890","personFirstName": "Chuck", "personLastName": "Norris", "address": {"address1":"125 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"charles.bronson@abc.com", "personPhone": "1234567890","personFirstName": "Charles", "personLastName": "Bronson", "address": {"address1":"126 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"jill.brown@abc.com", "personPhone": "1234567890","personFirstName": "Jill", "personLastName": "Brown", "address": {"address1":"127 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"sean.black@abc.com", "personPhone": "1234567890","personFirstName": "Sean", "personLastName": "Black", "address": {"address1":"128 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}},
{"personEmail":"ingrid.bergman@abc.com", "personPhone": "1234567890","personFirstName": "Ingrid", "personLastName": "Bergman", "address": {"address1":"129 any street", "address2":"", "city":"AnyCity","state":"nj","zip":"08550"}}
]; */

let persons = [];
module.exports.persons = persons;

module.exports.getPersons = (req,res) => {
    let responsePersonsList = []

    for (let person of persons) {
        responsePersonsList.push(person)
    }

    return res.json(responsePersonsList).status(200);
}

module.exports.postPerson = (req,res) => {
    let newPerson = req.body;
    //newPerson.personEmail = persons.length + 1;
    persons.push(newPerson);
    return res.status(204).end();
}

module.exports.deletePerson = (req,res) => {
    let personEmail = req.swagger.params.personEmail.value;

    for (let i=0; i < persons.length; i++) {
        if (persons[i].personEmail == personEmail) {
            persons.splice(i,1);
            return res.status(204).end();
        }
    }
    return res.status(404).end();
}

module.exports.updatePerson = (req,res) => {
    let personEmail = req.swagger.params.personEmail.value;
    for (let i=0; i < persons.length; i++) {
        if (persons[i].personEmail == personEmail) {
            persons[i] = req.body;
            return res.status(204).end();
        }
    }
    return res.status(404).end();
}

module.exports.getPerson = (req,res) => {
    let responsePersonsList = []
    let email = req.swagger.params.personEmail.value;
    console.log('Person Email: ' + email);
    for (let i=0; i < persons.length; i++) {
        if (persons[i].personEmail == email) {
            console.log("Match found: " + persons[i]);
            responsePersonsList.push(persons[i]);
        }
    }
    return res.json(responsePersonsList).status(200);
}
