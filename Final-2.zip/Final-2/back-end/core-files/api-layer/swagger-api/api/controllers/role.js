let roles = [{"id":0,"description":"Please select a role..."}, {"id":1,"description":"Patient appointments"},{"id":2,"description":"Provider appointments"},{"id":4,"description":"Appointments  by providers with other providers"},{"id":3,"description":"Appointments for patients by care-giver"}];

module.exports.roles = roles;

module.exports.getRoles = (req,res) => {
    let responseRolesList = []

    for (let role of roles) {
        responseRolesList.push(role)
    }

    return res.json(responseRolesList).status(200);
}

module.exports.postRole = (req,res) => {
    let newRole = req.body;
    newRole.id = roles.length + 1;
    roles.push(newRole);
    return res.status(204).end();
}

module.exports.deleteRole = (req,res) => {
    let id = req.swagger.params.roleId.value;
    console.log("ID: " + id);
    console.log('Length of the roles array: ' + roles.length);
    for (let i=0; i < roles.length; i++) {
        if (roles[i].id == id) {
            roles.splice(i,1);
            return res.status(204).end();
        }
    }
    return res.status(404).end();
}

module.exports.updateRole = (req,res) => {
    let id = req.swagger.params.roleId.value;
    for (let i=0; i < roles.length; i++) {
        if (roles[i].id == id) {
            roles[i] = req.body;
            return res.status(204).end();
        }
    }
    return res.status(404).end();
}