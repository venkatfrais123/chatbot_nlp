    const initialize = require('../helpers/initialize.js');
    const { Gateway } = require('fabric-network');
    const patientContract = require("../../../../organization/patientorg/contract/lib/patient.js");
    const appointmentContract = require("../../../../organization/patientorg/contract/lib/appointment.js");
    
    let orgname = 'patientorg';
    
    let patients = [];
    console.log(patients);

    let appointments = [];
    console.log(appointments);

    module.exports.patients = patients;
    module.exports.appointments = appointments;

    //Registering a Patient     
    module.exports.postPatient = (req,res) => {
        let userId = req.swagger.params.userId.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
    
        let newPatient = req.body;

        postingPatient(newPatient, userId, orgname).then((data) => {
            console.log("Posting patient");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    postingPatient = async (newPatient, userId, orgname) => {
    
        let newPatientMemberId = patients.length + 1;
        patients.push(newPatientMemberId);

        console.log('NEW PATIENT ID: ' + newPatientMemberId);
        
        let patientToPersist = {
            person: {
                personFirstName: newPatient.person.personFirstName,
                personLastName: newPatient.person.personLastName,
                personEmail: newPatient.person.personEmail,
                personPhone: newPatient.person.personPhone,
                address1: newPatient.person.address1,
                address2: newPatient.person.address2,
                city: newPatient.person.city,
                state: newPatient.person.state,
                zip: newPatient.person.zip
            },
            memberOrganization: newPatient.memberOrganization,
            memberId: newPatient.memberId,
            patientId: newPatientMemberId,
            providerId: newPatient.providerId,
            providerName: newPatient.providerName,
            caregiverId: newPatient.caregiverId,
            caregiverName: newPatient.caregiverName
        }

        console.log("Patient Details:", patientToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let patientCreationResponse = await contract.submitTransaction('CreatePatient', 
            userId, patientToPersist.patientId, patientToPersist.memberId, patientToPersist.memberOrganization, patientToPersist.providerId, patientToPersist.providerName, patientToPersist.caregiverId, patientToPersist.caregiverName,
            JSON.stringify(patientToPersist.person));
    
            //console.log(patientCreationResponse);
            let patientDetails = patientContract.fromBuffer(patientCreationResponse);
            console.log("Patient details");
            console.log(patientDetails);
            return patientDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Patient not added to network. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    //Adding additional Provider
    module.exports.addProvider = (req,res) => {
        let userId = req.swagger.params.userId.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        
        //Will contain Provider ID and Provider Name along with Patient details from state
        let patientWithNewProvider = req.body;

        addProvidertoPatient(patientWithNewProvider, userId, orgname).then((data) => {
            console.log("Posting patient");
            console.log(data);
            return res.status(204).end();
        });
    }

    addProvidertoPatient = async (patientWithNewProvider, userId, orgname) => {
    
        let patientToPersist = {
            person: {
                personFirstName: patientWithNewProvider.person.personFirstName,
                personLastName: patientWithNewProvider.person.personLastName,
                personEmail: patientWithNewProvider.person.personEmail,
                personPhone: patientWithNewProvider.person.personPhone,
                address1: patientWithNewProvider.person.address1,
                address2: patientWithNewProvider.person.address2,
                city: patientWithNewProvider.person.city,
                state: patientWithNewProvider.person.state,
                zip: patientWithNewProvider.person.zip
            },
            memberOrganization: patientWithNewProvider.memberOrganization,
            memberId: patientWithNewProvider.memberId,
            patientId: patientWithNewProvider.patientId,
            providerId: patientWithNewProvider.providerId,
            providerName: patientWithNewProvider.providerName,
            caregiverId: patientWithNewProvider.caregiverId,
            caregiverName: patientWithNewProvider.caregiverName
        }

        console.log("Patient Details:", patientToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let patientCreationResponse = await contract.submitTransaction('createPatient', 
            userId, patientToPersist.patientId, patientToPersist.memberId, patientToPersist.memberOrganization, patientToPersist.providerId, patientToPersist.providerName, patientToPersist.caregiverId, patientToPersist.caregiverName,
            JSON.stringify(patientToPersist.person));
    
            //console.log(patientCreationResponse);
            let patientDetails = patientContract.fromBuffer(patientCreationResponse);
            console.log("Patient details");
            console.log(patientDetails);
            return patientDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Patient not added to network. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    
    // Update existing patient info
    module.exports.updatePatient = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let patientUpdate = req.body;

        updatingPatient(patientUpdate, userId, orgname).then((data) => {
            console.log("Updating Patient");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingPatient = async (patientUpdate, userId, orgname) => {
    
        let patientToUpdate = {
            person: {
                personFirstName: patientUpdate.person.personFirstName,
                personLastName: patientUpdate.person.personLastName,
                personEmail: patientUpdate.person.personEmail,
                personPhone: patientUpdate.person.personPhone,
                address1: patientUpdate.person.address1,
                address2: patientUpdate.person.address2,
                city: patientUpdate.person.city,
                state: patientUpdate.person.state,
                zip: patientUpdate.person.zip
            },
            patientId: patientUpdate.patientId,
            providerId: patientUpdate.providerId,
            providerName: patientUpdate.providerName,
            caregiverId: patientUpdate.caregiverId,
            caregiverName: patientUpdate.caregiverName
        }

        console.log("Patient Details:", patientToUpdate);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let patientUpdateResponse = await contract.submitTransaction('updatePatient', 
            userId, patientToUpdate.patientId, patientToUpdate.providerId, patientToUpdate.providerName, patientToUpdate.caregiverId, patientToUpdate.caregiverName,
            JSON.stringify(patientToUpdate.person));
    
            console.log("Patient updated to the network");

            let patientDetails = patientContract.fromBuffer(patientUpdateResponse);
            console.log("Patient details");
            console.log(patientDetails);
            return patientDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Patient not updated in the Ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    
    //Querying Patients based on Patient ID
    module.exports.getPatientByPatientId = (req,res) => {
        let userId = req.swagger.params.userId.value;
        let patientId = req.swagger.params.patientId.value;

        console.log('Patient ID: ' + patientId);
        
        getPatientList(patientId, userId, orgname).then((data) => {
            console.log("Querying Patient");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    getPatientList = async (patientId, userId, orgname) => {
        const gateway = new Gateway();  
        const contract = await initialize.getContract(gateway, userId, orgname);
    
        try {
            let patientDetails = await contract.submitTransaction('listPatient', userId, patientId);
            
            let patientQuery = patientContract.fromBuffer(patientDetails);
            console.log("Patient details");
            console.log(patientQuery);
            return patientQuery;
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Patient details not queried. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    //Creating an appointment
    module.exports.newAppointmentbyPatient = (req,res) => {
        let userId = req.swagger.params.userId.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
    
        let newAppointment = req.body;

        createAppointment(newAppointment, userId, orgname).then((data) => {
            console.log("Creating an Appointment");
            console.log(data);
            return res.status(204).end();
        });
    }
    
    createAppointment = async (newAppointment, userId, orgname) => {
    
        let newAppointmentId = appointments.length + 1;
        console.log('New Appointment ID: ' + newAppointmentId);
        appointments.push(newAppointmentId);
        
        let appointmentToPersist = {
            appointmentId: newAppointmentId,
            patientId: newAppointment.patientId,
            providerId: newAppointment.providerId,
            newProviderId: newAppointment.newProviderId,
            caregiverId: newAppointment.caregiverId,
            appointmentStart: newAppointment.appointmentStart,
            appointmentEnd: newAppointment.appointmentEnd,
            appointmentDescription: newAppointment.appointmentDescription,
            appointmentType: newAppointment.appointmentType,
            acceptedByPatient: newAppointment.acceptedByPatient,
            acceptedByProvider: newAppointment.acceptedByProvider,
            acceptedByCaregiver: newAppointment.acceptedByCaregiver,
            appointmentStatus: newAppointment.appointmentStatus,
            appointmentCreationDate: newAppointment.appointmentCreationDate,
            appointmentUpdateDate: newAppointment.appointmentUpdateDate,
            cancellationReason: newAppointment.cancellationReason
        }

        console.log("Appointment Details:", appointmentToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let appointmentCreationResponse = await contract.submitTransaction('createAppointment', 
                userId, appointmentToPersist.appointmentId, appointmentToPersist.patientId, appointmentToPersist.providerId, appointmentToPersist.newProviderId, appointmentToPersist.caregiverId, 
                appointmentToPersist.appointmentStart, appointmentToPersist.appointmentEnd, appointmentToPersist.appointmentDescription, appointmentToPersist.appointmentType, newAppointment.acceptedByPatient, newAppointment.acceptedByProvider, newAppointment.acceptedByCaregiver, appointmentToPersist.appointmentStatus,
                appointmentToPersist.appointmentCreationDate, appointmentToPersist.appointmentUpdateDate, appointmentToPersist.cancellationReason);
    
            console.log("Appointment added to the Ledger");

            let appointmentDetails = appointmentContract.fromBuffer(appointmentCreationResponse);
            console.log("Appointment details");
            console.log(appointmentDetails);
            return appointmentDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment not added to Ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    // Update an appointment created by other organizations
    module.exports.updateAppointmentPat = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let appointmentUpdatePat = req.body;

        updatingAppointmentPat(appointmentUpdatePat, userId, orgname).then((data) => {
            console.log("Updating Appointment");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingAppointmentPat = async (appointmentUpdatePat, userId, orgname) => {
    
        let appointmentToUpdatePat = {
            appointmentId: appointmentUpdatePat.appointmentId,
            patientId: appointmentUpdatePat.patientId,
            appointmentUpdateDate: appointmentUpdatePat.appointmentUpdateDate,
            acceptedByPatient: appointmentUpdatePat.acceptedByPatient,
            cancellationReason: appointmentUpdatePat.cancellationReason
        }

        console.log("Patient Details:", appointmentToUpdatePat);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let appointmentUpdateResponsePat = await contract.submitTransaction('updateAppointmentPat', 
            appointmentUpdatePat.patientId, appointmentUpdatePat.appointmentId, appointmentUpdatePat.appointmentUpdateDate,appointmentUpdatePat.acceptedByPatient, appointmentUpdatePat.cancellationReason);
    
            //console.log(appointmentUpdateResponse);
            //return appointmentUpdateResponse;
            let appointmentDetailsPat = appointmentContract.fromBuffer(appointmentUpdateResponsePat);
            console.log("Appointment details - Updated");
            console.log(appointmentDetailsPat);
            return appointmentDetailsPat;

        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment not updated in the ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    //Querying Appointments
    module.exports.getAppointmentsforPatient = (req,res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let appointmentQuery = req.body;
                
        getAppointmentList(appointmentQuery, userId, orgname).then((data) => {
            console.log("Querying Appointment");
            console.log(data);
            return res.status(204).end();
        });
    }
    
    getAppointmentList = async (appointmentQuery, userId, orgname) => {
        const gateway = new Gateway();  
        const contract = await initialize.getContract(gateway, userId, orgname);
    
        try {
            let appointmentDetails = await contract.submitTransaction('listAppointment', appointmentQuery.patientId, appointmentQuery.appointmentId);
            
            let appointmentInfo = appointmentContract.fromBuffer(appointmentDetails);
            console.log("Appointment details");
            console.log(appointmentInfo);
            return appointmentInfo;
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment details not queried. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    