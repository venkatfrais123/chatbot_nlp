    const initialize = require('../helpers/initialize.js');
    const { Gateway } = require('fabric-network');
    const providerContract = require("../../../../organization/patientorg/contract/lib/provider.js");
    const appointmentContract = require("../../../../organization/patientorg/contract/lib/appointment.js");
    
    let orgname = 'providerorg';
    
    let providers = [];
    console.log(providers);

    let appointments = [];
    console.log(appointments);

    module.exports.providers = providers;
    module.exports.appointments = appointments;

    //Registering a Provider     
    module.exports.postProvider = (req,res) => {
        let userId = req.swagger.params.userId.value;
        
        console.log('Request BODY received: ' + JSON.stringify(req.body));
    
        let newProvider = req.body;

        postingProvider(newProvider, userId, orgname).then((data) => {
            console.log("Posting provider");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    postingProvider = async (newProvider, userId, orgname) => {
    
        let newProviderId = providers.length + 1;
        providers.push(newProviderId);

        console.log('NEW PROVIDER ID: ' + newProviderId);
        
        let providerToPersist = {
            person: {
                personFirstName: newProvider.person.personFirstName,
                personLastName: newProvider.person.personLastName,
                personEmail: newProvider.person.personEmail,
                personPhone: newProvider.person.personPhone,
                address1: newProvider.person.address1,
                address2: newProvider.person.address2,
                city: newProvider.person.city,
                state: newProvider.person.state,
                zip: newProvider.person.zip
            },
            providerId: newProviderId,
            providerType: newProvider.providerType,
            institutionName: newProvider.institutionName,
            institutionPhone: newProvider.institutionPhone,
            institutionEmail: newProvider.institutionEmail,
            institutionAddress: {
                address1: newProvider.institutionAddress.address1,
                address2: newProvider.institutionAddress.address2,
                city: newProvider.institutionAddress.city,
                state: newProvider.institutionAddress.state,
                zip: newProvider.institutionAddress.zip
            }
        }

        console.log("Provider Details:", providerToPersist);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let providerCreationResponse = await contract.submitTransaction('createProvider', 
            userId, JSON.stringify(providerToPersist.person), providerToPersist.providerId, providerToPersist.providerType, providerToPersist.institutionName, providerToPersist.institutionPhone, providerToPersist.institutionEmail, JSON.stringify(providerToPersist.institutionAddress));
    
            //console.log(providerCreationResponse);
            let providerDetails = providerContract.fromBuffer(providerCreationResponse);
            console.log("Provider details");
            console.log(providerDetails);
            return providerDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Provider not added to network. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    // Update existing provider info
    module.exports.updateProvider = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let providerUpdate = req.body;

        updatingProvider(providerUpdate, userId, orgname).then((data) => {
            console.log("Updating Provider");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingProvider = async (providerUpdate, userId, orgname) => {
    
        let providerToUpdate = {
            person: {
                personFirstName: providerUpdate.person.personFirstName,
                personLastName: providerUpdate.person.personLastName,
                personEmail: providerUpdate.person.personEmail,
                personPhone: providerUpdate.person.personPhone,
                address1: providerUpdate.person.address1,
                address2: providerUpdate.person.address2,
                city: providerUpdate.person.city,
                state: providerUpdate.person.state,
                zip: providerUpdate.person.zip
            },
            providerId: providerUpdate.providerId,
            institutionName: providerUpdate.institutionName,
            institutionPhone: providerUpdate.institutionPhone,
            institutionEmail: providerUpdate.institutionEmail,
            institutionAddress: {
                institutionAddress1: providerUpdate.institutionAddress.institutionAddress1,
                institutionAddress2: providerUpdate.institutionAddress.institutionAddress2,
                institutionCity: providerUpdate.institutionAddress.institutionCity,
                institutionState: providerUpdate.institutionAddress.institutionState,
                institutionZip: providerUpdate.institutionAddress.institutionZip
            }
        }

        console.log("Provider Details:", providerToUpdate);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
    
            let providerUpdateResponse = await contract.submitTransaction('updateProvider', 
            userId, JSON.stringify(providerToUpdate.person), providerToUpdate.providerId, providerToUpdate.institutionName, providerToUpdate.institutionPhone, providerToUpdate.institutionEmail,
            JSON.stringify(providerToUpdate.institutionAddress));
    
            console.log("Provider updated to the network");

            let providerDetails = providerContract.fromBuffer(providerUpdateResponse);
            console.log("Provider details");
            console.log(providerDetails);
            return providerDetails;
            
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Provider not updated in the Ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    
    //Querying Providers based on Provider ID
    module.exports.getProvider = (req,res) => {
        let userId = req.swagger.params.userId.value;
        let providerId = req.swagger.params.providerId.value;

        console.log('Provider ID: ' + providerId);
        
        getProviderList(providerId, userId, orgname).then((data) => {
            console.log("Querying Provider");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }
    
    getProviderList = async (providerId, userId, orgname) => {
        const gateway = new Gateway();  
        const contract = await initialize.getContract(gateway, userId, orgname);
    
        try {
            let providerDetails = await contract.submitTransaction('listProvider', userId, providerId);
            
            let providerQuery = providerContract.fromBuffer(providerDetails);
            console.log("Provider details");
            console.log(providerQuery);
            return providerQuery;
        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Provider details not queried. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }

    // Update an appointment created by other organizations
    module.exports.updateAppointmentPro = (req, res) => {
        let userId = req.swagger.params.userId.value;
        console.log('Request BODY received: ' + JSON.stringify(req.body));
        let appointmentUpdatePro = req.body;

        updatingAppointmentPro(appointmentUpdatePro, userId, orgname).then((data) => {
            console.log("Updating Appointment");
            console.log(data);
            return res.json(data).status(204).end();
        });
    }

    updatingAppointmentPro = async (appointmentUpdatePro, userId, orgname) => {
    
        let appointmentToUpdatePro = {
            appointmentId: appointmentUpdatePro.appointmentId,
            patientId: appointmentUpdatePro.patientId,
            appointmentUpdateDate: appointmentUpdatePro.appointmentUpdateDate,
            acceptedByProvider: appointmentUpdatePro.acceptedByProvider,
            cancellationReason: appointmentUpdatePro.cancellationReason,
            isReferral: appointmentUpdatePro.isReferral,
            newProviderId: appointmentUpdatePro.newProviderId
        }

        console.log("Appointment Details:", appointmentToUpdatePro);
    
        const gateway = new Gateway();  
    
        const contract = await initialize.getContract(gateway, userId, orgname);
        try {
            console.log("isReferral:", appointmentUpdatePro.isReferral);
            if (appointmentUpdatePro.isReferral == 'NA') {
                console.log("Inside updateAppointmentPro");
                let appointmentUpdateResponsePro = await contract.submitTransaction('updateAppointmentPro', 
                appointmentUpdatePro.patientId, appointmentUpdatePro.appointmentId, appointmentUpdatePro.appointmentUpdateDate,appointmentUpdatePro.acceptedByProvider, appointmentUpdatePro.cancellationReason);

                let appointmentDetailsPro = appointmentContract.fromBuffer(appointmentUpdateResponsePro);
                console.log("Appointment details - Updated");
                console.log(appointmentDetailsPro);
                return appointmentDetailsPro;
            } else {
                console.log("inside referAppointment");
                let appointmentUpdateResponsePro = await contract.submitTransaction('referAppointment', 
                appointmentUpdatePro.patientId, appointmentUpdatePro.appointmentId, appointmentUpdatePro.appointmentUpdateDate,appointmentUpdatePro.newProviderId);
                
                let appointmentDetailsPro = appointmentContract.fromBuffer(appointmentUpdateResponsePro);
                console.log("Appointment details - Updated");
                console.log(appointmentDetailsPro);
                return appointmentDetailsPro;
            }

        } catch (error) {
            console.log(`Error processing transaction. ${error}`);
            console.log(error.stack);
            return ("Appointment not updated in the ledger. Please check!");
        } finally {
            console.log('Disconnect from Fabric gateway.');
            gateway.disconnect();
        }
    }
    