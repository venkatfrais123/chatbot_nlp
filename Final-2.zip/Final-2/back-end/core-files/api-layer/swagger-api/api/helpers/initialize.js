'use strict';

const fs = require('fs');
const yaml = require('js-yaml');
const { Wallets } = require('fabric-network');

class Initialize {

    static async getContract(gateway, userId, orgname) {

        var org = "";

        if (orgname == "providerorg") {
            org = "org1";
        } else if (orgname == "caregiverorg") {
            org = "org2";
        } else if (orgname == "patientorg") {
            org = "org4";
        } else {
            console.log("Invalid argument - Login Type");
        }
        
        console.log(org);
    
        const wallet = await Wallets.newFileSystemWallet(
            "/home/venkat/hyper-samp/booking-app-2/core-files/organization/"+orgname+"/identity/user/"+userId+"/wallet"
          );
    
        // Check to see if we've already enrolled the user.
        const userExists = await wallet.get(userId);
        if (!userExists) {
            console.log('An identity for the user "user1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
    
        const userName = userId;

        let connectionProfile = yaml.safeLoad(
            fs.readFileSync("/home/venkat/hyper-samp/booking-app-2/core-files/organization/"+orgname+"/gateway/connection-"+org+".yaml", "utf-8")
        );

        let connectionOptions = {
            identity: userName,
            wallet: wallet,
            discovery: { enabled: true, asLocalhost: true },
        };

        console.log("Connect to Fabric Gateway");
        await gateway.connect(connectionProfile, connectionOptions);
    
        console.log("Using mychannel");
        const network = await gateway.getNetwork("mychannel");
                   
        console.log("Using the Appointment Contract");
        const contract = await network.getContract("appointmentcontract");

        //console.log(contract);
        return contract;
    }
}

module.exports = Initialize;