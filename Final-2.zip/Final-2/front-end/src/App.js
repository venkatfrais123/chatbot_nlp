import React, { Component } from 'react';
import './App.css';
import { withRouter } from 'react-router-dom'
import Layout from './Components/Layout';

class App extends Component {

  render() {
    return (
      <div className="App">
        <Layout {...this.props}></Layout>
        {/*<Header userLoggedIn={this.state.userLoggedIn} isLoginPage={this.state.isLoginPage} history={this.props.history}></Header>
        <div style={{paddingTop: "48px"}}></div>
        <HashRouter>
          <div style={{minHeight: '86vh'}}>
            <Switch>
              <Route exact path="/" render={(props) => <Login {...props} parentCallback={this.handleCallback} />} />
              <Route exact path="/login" render={(props) => <Login {...props} parentCallback={this.handleCallback} />} />
              <Route exact path="/signup" render={(props) => <Signup {...props} parentCallback={this.handleCallback} />} />
              <Route exact path="/dashboard" render={(props) => <Caregiver {...props} parentCallback={this.handleCallback} />} />
            </Switch>
          </div>
        </HashRouter>
        <Footer></Footer>*/}
      </div>
    );
  }
}

export default withRouter(App); 