import React from 'react';
import Chart from 'chart.js';

class AreaChart extends React.Component {
  constructor(props) {
    super(props);
    this.chartRef = React.createRef();
  }

  componentDidUpdate() {
    if(this.props.data !== null && this.props.data !== undefined) {
      this.myChart.data = this.props.data;
      this.myChart.update();
    }
  }

  componentDidMount() {
    this.myChart = new Chart(this.chartRef.current, {
      type: 'line',
      data: this.props.data,
      options: {
        title: {
          display: true,
          text: 'Appointments status per month'
        },
        plugins: {
          filler: {
            propagate: true
          }
        },
        scales: {
          yAxes: [{
            stacked: true
          }]
        }
      }
    });
  }

  render() {
    return <canvas ref={this.chartRef} height="100" />;
  }
}

export default AreaChart;