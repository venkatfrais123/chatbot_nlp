import React from 'react';
import Chart from 'chart.js';

class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.chartRef = React.createRef();
    this.setChartData = this.setChartData.bind(this);
  }

  componentDidUpdate() {
    this.setChartData();
  }

  componentDidMount() {
    this.setChartData();
  }

  setChartData() {
    var displayText = 'Appointments with Patients per month';
    if(this.props.userType === 'patient') {
      displayText = 'Appointments per month';
    }
    this.myChart = new Chart(this.chartRef.current, {
      type: 'line',
      data: this.props.data,
      options: {
        title: {
          display: true,
          text: displayText
        },
        scales: {
          yAxes: [{
            stacked: true
          }]
        }
      }
    });
  }

  render() {
    return <canvas ref={this.chartRef} height="76" />;
  }
}

export default LineChart;