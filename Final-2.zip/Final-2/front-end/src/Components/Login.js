import React from 'react';
import { 
    Card,
    CardContent,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField,
    Link,
    Grid
} from '@material-ui/core';
import CarouselComponent from './CarouselComponent';
import { validateLoginAPI, userInfoAPI } from "../utils/service";
import { connect } from 'react-redux';

const map = new Map([
    ["username", "Username is required"],
    ["orgId", "OrgId is required"]
]);

class Login extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            username: "", usernameError: false, usernameErrorText: "",
            orgId: "", orgIdError: false, orgIdErrorText: "",
            loginErrorMsg: ""
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.getUserData = this.getUserData.bind(this);
        this.props.parentCallback(false, true);
    }

    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;
        const error = name + 'Error';
        const errorText = name + 'ErrorText';

        this.setState({
            [name]: value
        });

        if (value.length === 0) {
            this.setState({
                [error]: true,
                [errorText]: map.get(name)
            });
        } else {
            this.setState({
                [error]: false,
                [errorText]: ''
            });
        }
    }

    handleSubmit(event) {
        event.preventDefault();
        if (this.formValid()) {
            this.props.spinnerLoader(true);
            validateLoginAPI({userId: this.state.username, orgname: this.state.orgId + 'org'}).then(response => {
                this.props.spinnerLoader(false);
                console.log('Login response ', response);
                if(response.data === "Already Exists!!") {
                    this.getUserData();
                } else {
                    this.setState({
                        username: "",
                        orgId: "",
                        loginErrorMsg: "Invalid Username or Org Id entered, Please re-enter."
                    });
                }
            }).catch((error) => {
                this.props.spinnerLoader(false);
                this.setState({
                    username: "",
                    orgId: "",
                    loginErrorMsg: "Invalid Username or Org Id entered, Please re-enter."
                });
            });
        }
    }

    getUserData() {
        this.props.spinnerLoader(true);
        userInfoAPI(this.state.username, this.state.orgId).then(response => {
            this.props.spinnerLoader(false);
            console.log('getUserData ', response);
            let user = response.data;
            user.userType = this.state.orgId;
            this.props.dispatch({type: 'UPDATE', payload : {user: user}});
            this.props.parentCallback(true, true);
            this.props.history.push("/appointment");
        }).catch((error) => {
            this.props.spinnerLoader(false);
            console.log('Error', error)
        });
    }

    formValid() {
        var valid = true;
        for (const key of map.keys()) {
            const name = key;
            const error = name + 'Error';
            const errorText = name + 'ErrorText';

            if (this.state[name].length === 0) {
                valid = false;
                this.setState({
                    [error]: true,
                    [errorText]: map.get(name) + ' is required'
                });
            } else {
                this.setState({
                    [error]: false,
                    [errorText]: ''
                });
            }
        }
        return valid;
    }

    navigateToSignUp(event) {
        event.preventDefault();
        this.props.history.push("/signup");
    }

    render() {
        return (
            <Card style={{borderRadius: '0px'}}>
                <CardContent style={{ padding: '0px' }}>
                    <Grid container>
                        <Grid item xs={12} sm={5} style={{backgroundColor:'#336699'}}><CarouselComponent /></Grid>
                        <Grid item xs={12} sm={7}>
                            <Grid container>
                                <Grid item xs={12} sm={2}></Grid>
                                <Grid item xs={12} sm={5}>
                                    <div>
                                        <h3 style={{ float: "left", marginBottom: "0px" }}>Login</h3>
                                        <form style={{ width: '100%' }} onSubmit={this.handleSubmit}>
                                            <TextField
                                                margin="normal"
                                                fullWidth
                                                id="username"
                                                label="Username*"
                                                name="username"
                                                autoComplete="username"
                                                autoFocus
                                                value={this.state.username}
                                                error={this.state.usernameError}
                                                helperText={this.state.usernameErrorText}
                                                onChange={(event) => this.handleChange(event)}
                                            />
                                            <FormControl>
                                                <InputLabel id="orgId">Org Id*</InputLabel>
                                                <Select
                                                    margin="normal"
                                                    style={{ width: '385px' }}
                                                    fullWidth
                                                    labelId="orgId"
                                                    id="orgId"
                                                    name="orgId"
                                                    value={this.state.orgId}
                                                    error={this.state.orgIdError}
                                                    helperText={this.state.orgIdErrorText}
                                                    onChange={(event) => this.handleChange(event)}
                                                >
                                                    <MenuItem value={""}>--Select--</MenuItem>
                                                    <MenuItem value={'caregiver'}>Caregiver Org</MenuItem>
                                                    <MenuItem value={'provider'}>Provider Org</MenuItem>
                                                    <MenuItem value={'patient'}>Patient Org</MenuItem>
                                                </Select>
                                            </FormControl>
                                            <div style={{paddingTop: '20px'}}></div>
                                            {/*<TextField
                                                margin="normal"
                                                fullWidth
                                                name="orgId"
                                                label="Org Id*"
                                                type="text"
                                                id="orgId"
                                                autoComplete="current-orgId"
                                                value={this.state.orgId}
                                                error={this.state.orgIdError}
                                                helperText={this.state.orgIdErrorText}
                                                onChange={(event) => this.handleChange(event)}
                                            />*/}
                                            <div style={{ minHeight: "40px", float: 'left', fontSize: '0.950rem', color: 'red' }}>
                                                {this.state.loginErrorMsg}
                                            </div>
                                            <Button
                                                type="submit"
                                                fullWidth
                                                variant="contained"
                                                color="primary"
                                            >
                                                Sign In
                                            </Button>
                                            <div style={{ paddingTop: "30px" }}></div>
                                            <Grid container>
                                                <Grid item xs>
                                                    <Link href="#" variant="body2">
                                                        Forgot Org Id?
                                            </Link>
                                                </Grid>
                                                <Grid item>
                                                    <Link href="#" onClick={(event) => this.navigateToSignUp(event)} variant="body2">
                                                        {"Don't have an account? Sign Up"}
                                                    </Link>
                                                </Grid>
                                            </Grid>
                                        </form>
                                    </div>
                                </Grid>
                                <div style={{ paddingTop: "50px", fontSize: "25px" }}>
                                    <div className="quotes">
                                        <span>“Doctors diagnose, nurses heal, and caregivers </span><br />
                                        <span>make sense of it all.” — Brett H. Lewis...</span>
                                    </div>
                                </div>
                            </Grid>
                        </Grid>
                    </Grid>
                </CardContent>
            </Card>
        );
    }
}

// getting the data
function mapStateToProps(state) {
    return state;
}

export default connect(mapStateToProps)(Login);