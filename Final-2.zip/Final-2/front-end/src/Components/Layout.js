import React from 'react';
import clsx from 'clsx';
import { HashRouter, Switch, Route } from "react-router-dom";
import { 
  makeStyles, 
  fade, 
  useTheme,
  AppBar,
  Drawer,
  Toolbar,
  IconButton,
  Typography,
  MenuItem,
  Menu,
  ListItem,
  ListItemIcon,
  ListItemText,
  List,
  Divider,
  Button
 } from '@material-ui/core';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import AccountCircle from '@material-ui/icons/AccountCircle';
import DashboardIcon from '@material-ui/icons/Dashboard';
import MoreIcon from '@material-ui/icons/MoreVert';
import MenuIcon from '@material-ui/icons/Menu';
import PeopleIcon from '@material-ui/icons/People';
import PersonIcon from '@material-ui/icons/Person';
import EventNoteIcon from '@material-ui/icons/EventNote';
import Login from './Login';
import Signup from './SignUp';
import Footer from './Footer';
import Caregiver from './Caregiver';
import Account from './Account';
import Users from './Users';
import Appointment from './Appointment';
import Patient from './Patient';
import Provider from './Provider';
import { useDispatch, useSelector } from 'react-redux';
import LoadingOverlay from 'react-loading-overlay';
import PropagateLoader from 'react-spinners/PropagateLoader';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    display: 'none',
    [theme.breakpoints.up('sm')]: {
      display: 'block',
    },
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: '20ch',
    },
  },
  sectionDesktop: {
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'flex',
    },
  },
  sectionMobile: {
    display: 'flex',
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  openContent: {
    flexGrow: 1,
    paddingLeft: drawerWidth,
  },
  closeContent: {
    flexGrow: 1,
    paddingLeft: theme.spacing(9) + 1
  },
  noContent:{
    flexGrow: 1,
  }
}));

export default function Layout(props) {
  const classes = useStyles();
  const user = useSelector((state)=>state.user);
  const dispatch = useDispatch();
  const theme = useTheme();
  const username = user.person !== 'undefined' ? user.person.personFirstName + ' ' + user.person.personLastName : '';
  const usertype = user.userType;
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const [userLoggedIn, setUserLoggedIn] = React.useState(false);
  const [isLoginPage, setIsLoginPage] = React.useState(true);
  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
  const [spinnerIsActive, setSpinnerActive] = React.useState(false);

  function login() {
    props.history.push("/login");
  }

  function navigateToSignUp() {
    props.history.push("/signup");
  }

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const logout = () => {
    dispatch({type: 'REMOVE'});
    props.history.push("/login");
    handleMenuClose();
  }

  const navigateToProfile = () => {
    props.history.push("/account");
    handleMenuClose();
  }

  const handleCallback = (loggedInStatus, isLoginPage) => {
    setUserLoggedIn(loggedInStatus);
    setIsLoginPage(isLoginPage);
  }

  const spinnerLoader = (isActive) => {
    setSpinnerActive(isActive);
  }

  const menuId = 'primary-search-account-menu';
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      id={menuId}
      keepMounted
      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={navigateToProfile}>Profile</MenuItem>
      <MenuItem onClick={logout}>Logout</MenuItem>
    </Menu>
  );

  const mobileMenuId = 'primary-search-account-menu-mobile';
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      {/*<MenuItem>
        <IconButton aria-label="show 4 new mails" color="inherit">
          <Badge badgeContent={4} color="secondary">
            <MailIcon />
          </Badge>
        </IconButton>
        <p>Messages</p>
      </MenuItem>
      <MenuItem>
        <IconButton aria-label="show 11 new notifications" color="inherit">
          <Badge badgeContent={11} color="secondary">
            <NotificationsIcon />
          </Badge>
        </IconButton>
        <p>Notifications</p>
      </MenuItem>*/}
      <MenuItem onClick={handleProfileMenuOpen}>
        <IconButton
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>Profile</p>
      </MenuItem>
    </Menu>
  );

  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    if(userLoggedIn) {
      setOpen(true);
    }
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const navigateToDashboard = () => {
    props.history.push('/dashboard');
  };
  const navigateToUsers = () => {
    props.history.push('/users');
  };
  const navigateToAppointment = () => {
    props.history.push('/appointment');
  };
  const navigateToAccount = () => {
    props.history.push('/account');
  };

  return (
    <div className={classes.grow}>
      <AppBar position="fixed"
      className={clsx(classes.appBar, {
        [classes.appBarShift]: open,
      })}>
        <Toolbar>
        <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
            <MenuIcon />
          </IconButton>
          <Typography className={classes.title} variant="h6" noWrap>
            Appointment Booking System &nbsp;&nbsp;
          </Typography>
          <div className={classes.grow}></div>
          {/*<div className={classes.search}>
            <div className={classes.searchIcon}>
              <SearchIcon />
            </div>
            <InputBase
              placeholder="Search…"
              classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
              }}
              inputProps={{ 'aria-label': 'search' }}
            />
            </div> */}
          { userLoggedIn ?
            <div>
              <div className={classes.sectionDesktop}>
                {/*<IconButton aria-label="show 4 new mails" color="inherit">
                  <Badge badgeContent={4} color="secondary">
                    <MailIcon />
                  </Badge>
                </IconButton>
                <IconButton aria-label="show 17 new notifications" color="inherit">
                  <Badge badgeContent={17} color="secondary">
                    <NotificationsIcon />
                  </Badge>
                </IconButton>*/}
                <IconButton
                  edge="end"
                  aria-label="account of current user"
                  aria-controls={menuId}
                  aria-haspopup="true"
                  onClick={handleProfileMenuOpen}
                  color="inherit"
                >
                  <span style={{fontSize: '75%'}}>{username}</span>&nbsp;<AccountCircle />
                </IconButton>
              </div>
              <div className={classes.sectionMobile}>
                <IconButton
                  aria-label="show more"
                  aria-controls={mobileMenuId}
                  aria-haspopup="true"
                  onClick={handleMobileMenuOpen}
                  color="inherit"
                >
                  <MoreIcon />
                </IconButton>
              </div>
            </div>
            :
            <div>
              { isLoginPage ?
              <div>
              <Button
                size="small"
                style={{color:"white"}}
                onClick={navigateToSignUp}
              >
                Register
              </Button>
            </div>
            :
            <div>
              <Button
                size="small"
                style={{color:"white"}}
                onClick={login}
              >
                Login
              </Button>
            </div>
            }
            </div>
          }
        </Toolbar>
      </AppBar>
      {renderMobileMenu}
      {renderMenu}
      { userLoggedIn ?
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
      >
        <div className={classes.toolbar}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </div>
        <Divider />
        <List>
          <ListItem button onClick={navigateToDashboard}>
            <ListItemIcon><DashboardIcon /></ListItemIcon>
            <ListItemText primary='Dashboard' />
          </ListItem>
          <ListItem button onClick={navigateToAppointment}>
            <ListItemIcon><EventNoteIcon /></ListItemIcon>
            <ListItemText primary='Appointment' />
          </ListItem>
          <ListItem button onClick={navigateToUsers}>
            <ListItemIcon><PeopleIcon /></ListItemIcon>
            <ListItemText primary='Users' />
          </ListItem>
          <ListItem button onClick={navigateToAccount}>
            <ListItemIcon><PersonIcon /></ListItemIcon>
            <ListItemText primary='Account' />
          </ListItem>
        </List>
      </Drawer>
      : <div></div>
      }
      <main className={ !userLoggedIn ? classes.noContent : (open ? classes.openContent : classes.closeContent)}>
        <div className={classes.toolbar} />
        <HashRouter>
          <div style={{minHeight: '84vh', backgroundColor:'#ebedef'}}>
            <LoadingOverlay
              active={spinnerIsActive}
              spinner ={<PropagateLoader color={'white'} /> }
            >
              <Switch>
                <Route exact path="/" render={(props) => <Login {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                <Route exact path="/login" render={(props) => <Login {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                <Route exact path="/signup" render={(props) => <Signup {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                {usertype === 'caregiver' && 
                  <Route exact path="/dashboard" render={(props) => <Caregiver {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                }
                {usertype === 'provider' && 
                  <Route exact path="/dashboard" render={(props) => <Provider {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                }
                {usertype === 'patient' && 
                <Route exact path="/dashboard" render={(props) => <Patient {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                }
                <Route exact path="/account" render={(props) => <Account {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                <Route exact path="/users" render={(props) => <Users {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
                <Route exact path="/appointment" render={(props) => <Appointment {...props} parentCallback={handleCallback} spinnerLoader={spinnerLoader} />} />
              </Switch>
            </LoadingOverlay>
          </div>
        </HashRouter>
        <Footer></Footer>
      </main>
    </div>
  );
}