import React from 'react';
import {
  Button,
  TextField,
  Link,
  Grid,
  Card,
  CardContent,
  InputLabel,
  Select,
  MenuItem,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  Stepper,
  Step,
  StepLabel,
  StepContent
} from '@material-ui/core';
import { createUserAPI, registerAPI, fetchAllUsersAPI } from "../utils/service";
import { convertResponseToUserVO } from "../utils/helper";

const map = new Map([
  ["username", ["Username is required", "ALL"]],
  ["firstName", ["First Name is required", "ALL"]],
  ["lastName", ["Last Name is required", "ALL"]],
  ["email", ["E-mail is required", "ALL"]],
  ["phoneNumber", ["Phone Number is required", "ALL"]],
  ["address1", ["Address1 is required", "ALL"]],
  ["address2", ["Address2 is required", "ALL"]],
  ["city", ["City is required", "ALL"]],
  ["state", ["State is required", "ALL"]],
  ["zip", ["Zip is required", "ALL"]],
  ["memberOrganization", ["Member Organization is required", "patient"]],
  ["memberId", ["Member Id is required", "patient"]], 
  ["caregiverId", ["Caregiver ID is required", "NA"]],
  ["caregiverName", ["Caregiver Name is required", "NA"]],
  ["providerId", ["Provider Id is required", "NA"]],
  ["providerName", ["Provider Name is required", "NA"]],
  ["providerType", ["Provider Type is required", "provider"]],
  ["institutionName", ["Institution Name is required", "provider"]],
  ["institutionPhone", ["Institution Phone is required", "provider"]],
  ["institutionEmail", ["Institution E-mail is required", "provider"]],
  ["institutionAddress1", ["Institution Address1 is required", "provider"]],
  ["institutionAddress2", ["Institution Address2 is required", "provider"]],
  ["institutionCity", ["Institution City is required", "provider"]],
  ["institutionState", ["Institution State is required", "provider"]],
  ["institutionZip", ["Institution Zip is required", "provider"]]
]);

class Signup extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      activeStep: 0,
      providerMap: new Map(),
      caregiverMap: new Map(),
      steps: ['Create User Account', 'Update User Account', 'Status'],
      loginType: "caregiver", loginTypeError: false, loginTypeErrorText: "",
      firstName: "", firstNameError: false, firstNameErrorText: "",
      lastName: "", lastNameError: false, lastNameErrorText: "",
      username: "", usernameError: false, usernameErrorText: "",
      email: "", emailError: false, emailErrorText: "",
      phoneNumber: "", phoneNumberError: false, phoneNumberErrorText: "",
      address1: "", address1Error: false, address1ErrorText: "",
      address2: "", address2Error: false, address2ErrorText: "",
      city: "", cityError: false, cityErrorText: "",
      state: "", stateError: false, stateErrorText: "",
      zip: "", zipError: false, zipErrorText: "",
      memberOrganization: "", memberOrganizationError: false, memberOrganizationErrorText: "",
      memberId: "", memberIdError: false, memberIdErrorText: "",
      caregiverId: "", caregiverIdError: false, caregiverIdErrorText: "",
      caregiverName: "", caregiverNameError: false, caregiverNameErrorText: "",
      providerId: "", providerIdError: false, providerIdErrorText: "",
      providerName: "", providerNameError: false, providerNameErrorText: "",
      providerType: "", providerTypeError: false, providerTypeErrorText: "",
      institutionName: "", institutionNameError: false, institutionNameErrorText: "",
      institutionPhone: "", institutionPhoneError: false, institutionPhoneErrorText: "",
      institutionEmail: "", institutionEmailError: false, institutionEmailErrorText: "",
      institutionAddress1: "", institutionAddress1Error: false, institutionAddress1ErrorText: "",
      institutionAddress2: "", institutionAddress2Error: false, institutionAddress2ErrorText: "",
      institutionCity: "", institutionCityError: false, institutionCityErrorText: "",
      institutionState: "", institutionStateError: false, institutionStateErrorText: "",
      institutionZip: "", institutionZipError: false, institutionZipErrorText: "",
      userId: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.createUserId = this.createUserId.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleNext = this.handleNext.bind(this);
    this.handleBack = this.handleBack.bind(this);
    this.handleReset = this.handleReset.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleProviderIdChange = this.handleProviderIdChange.bind(this);
    this.handleCaregiverIdChange = this.handleCaregiverIdChange.bind(this);
    this.props.parentCallback(false, false);
  }

  handleNext() {
    let currStep = this.state.activeStep + 1;
    this.setState({
      activeStep: currStep
    })
    if(currStep === 0) {
      this.setState({
        steps: ['Create User Account', 'Update User Account', 'Status']
      });
    } else if(currStep === 1) {
      this.setState({
        steps: ['User Account created..!', 'Update User Account', 'Status']
      });
    } else {
      this.setState({
        steps: ['User Account created..!', 'User Account updated..!', 'Status']
      });
    }
  };

  handleBack() {
    let currStep = this.state.activeStep - 1;
    this.setState({
      activeStep: currStep
    });
    if(currStep === 0) {
      this.setState({
        steps: ['Create User Account', 'Update User Account', 'Status']
      });
    } else if(currStep === 1) {
      this.setState({
        steps: ['User Account created..!', 'Update User Account', 'Status']
      });
    } else {
      this.setState({
        steps: ['User Account created..!', 'User Account updated..!', 'Status']
      });
    }
  };

  handleReset() {
    this.setState({
      activeStep: 0
    });
    this.setState({
      steps: ['Create User Account', 'Update User Account', 'Status']
    });
  };

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;
    const error = name + 'Error';
    const errorText = name + 'ErrorText';

    this.setState({
      [name]: value
    });

    if (value.length === 0) {
      this.setState({
        [error]: true,
        [errorText]: map.get(name)[0]
      });
    } else {
      this.setState({
        [error]: false,
        [errorText]: ''
      });
    }
  }
  
  handleProviderIdChange(event) {
    const person = this.providerMap.get(event.target.value);
    this.setState({
      providerId: event.target.value,
      providerName: person.personFirstName + ' ' + person.personLastName
    });
  }

  handleCaregiverIdChange(event) {
    const person = this.caregiverMap.get(event.target.value);
    this.setState({
      caregiverId: event.target.value,
      caregiverName: person.personFirstName + ' ' + person.personLastName
    });
  }

  createUserId() {
    const names = ['username'];
    let isValid = true;

    for(let name of names) {
      const value = map.get(name);
      const error = name + 'Error';
      const errorText = name + 'ErrorText';
      if (this.state[name].length === 0) {
        this.setState({
          [error]: true,
          [errorText]: value[0]
        });
        isValid = false;
      } else {
        this.setState({
          [error]: false,
          [errorText]: ''
        });
      }
    }

    if(isValid) {
      this.createUser();
    }
  }

  handleSubmit(event) {
    event.preventDefault();
    if (this.formValid()) {
      this.updateUser();
    }
    //this.props.parentCallback(false, true);
    //event.preventDefault();
    // alert('Account created successfully..! Login to continue...');
    ///this.props.history.push("/login");
  }

  formValid() {
    var valid = true;
    for (const key of map.keys()) {
      const name = key;
      const value = map.get(key);
      const error = name + 'Error';
      const errorText = name + 'ErrorText';

      if ((value[1] === "ALL" || value[1] === this.state.loginType) && this.state[name].length === 0) {
        valid = false;
        this.setState({
          [error]: true,
          [errorText]: value[0]
        });
      } else {
        this.setState({
          [error]: false,
          [errorText]: ''
        });
      }
    }
    return valid;
  }

  componentDidMount() {
    /*  this.props.spinnerLoader(true);
    fetchAllUsersAPI()
        .then(res => {
          const mapObj = convertResponseToUserVO(res);
            this.setState({
              caregiverMap: mapObj.caregiverMap,
              providerMap: mapObj.providerMap
            });
            this.props.spinnerLoader(false);
        })
        .catch(err => {
          this.props.spinnerLoader(false);
          console.log("failure " + err);
        });*/
  }

  createUser() {
    this.props.spinnerLoader(true);
    createUserAPI({
      "userId": this.state.username,
      "orgname": this.state.loginType + 'org'
    }).then(res => {
      this.props.spinnerLoader(false);
      console.log('signup response', res)
        if(res.data === 'User Signed Up!!') {
          this.setState({
            userId: this.state.username
          })
          alert("Account created successfully");
          this.handleNext();
        } else {
          alert("Account not created, Username is may taken already. Please try with another username, if issue persits please contact administrator");
        }
        return res;
      })
      .catch(err => {
        this.props.spinnerLoader(false);
        console.log("failure " + err);
      });
  }

  updateUser() {
    if(this.state.caregiverId === '') {
      this.setState({
        caregiverId: 'NA',
        caregiverName: 'NA'
      });
    }
    if(this.state.providerId === '') {
      this.setState({
        providerId: 'NA',
        providerName: 'NA'
      });
    }
    this.props.spinnerLoader(true);
    registerAPI({
        "memberId": this.state.memberId,
        "memberOrganization": this.state.memberOrganization,
        "providerId": this.state.providerId,
        "providerName": this.state.providerName,
        "providerType": this.state.providerType,
        "caregiverId": this.state.caregiverId,
        "caregiverName": this.state.caregiverName,
        "personEmail": this.state.email,
        "personPhone": this.state.phoneNumber,
        "personFirstName": this.state.firstName,
        "personLastName": this.state.lastName,
        "personAddress1": this.state.address1,
        "personAddress2": this.state.address2,
        "personCity": this.state.city,
        "personState": this.state.state,
        "personZip": this.state.zip,
        "institutionName": this.state.institutionName,
        "institutionPhone": this.state.institutionPhone,
        "institutionEmail": this.state.institutionEmail,
        "insAddress1": this.state.institutionAddress1,
        "insAddress2": this.state.institutionAddress2,
        "insCity": this.state.institutionCity,
        "insState": this.state.institutionState,
        "insZip": this.state.institutionZip,
        userId: this.state.userId
      }, this.state.loginType)
      .then(res => {
        this.props.spinnerLoader(false);
        console.log("success regsitration ", res);
        console.log("success " + JSON.stringify(res));
        this.handleNext();
        alert("Account updated successfully...");
        return res;
      })
      .catch(err => {
        this.props.spinnerLoader(false);
        console.log("failure " + err);
      });
  }

  navigateToLogin(event) {
    event.preventDefault();
    this.props.history.push("/login");
  }

  render() {
    return (
      <Card style={{borderRadius: '0px'}}>
      <CardContent style={{ padding: '0px', minHeight:'607px' }}>
      <Grid container>
            <Grid item xs={12} sm={5}>
              <div style={{ position: "fixed",backgroundColor:'#336699', color: "white" }}>
                {this.state.loginType === 'caregiver' &&
                  <div>
                    <img src='assets/Caregiver123.jpg' alt="Caregiver" width="700" height="528" /><br />
                    <span style={{ fontSize: "1.5em" }}>Caregiver</span><br />
                    <span>A caregiver is a paid or unpaid member of a person's social network who helps <br/>them with activities of daily living.!</span>
                  </div>
                }
                {
                  this.state.loginType === 'provider' &&
                  <div>
                    <img src='assets/Provider.jpg' alt="Provider" width="700" height="528" /><br />
                    <span style={{ fontSize: "1.5em" }}>Provider</span><br />
                    <span>A doctor is someone who maintains or restores human health through the practice of medicine.!</span>
                  </div>
                }
                {
                  this.state.loginType === 'patient' &&
                  <div>
                    <img src='assets/Patient123.jpg' alt="Patient" width="700" height="528" /><br />
                    <span style={{ fontSize: "1.5em" }}>Patient</span><br />
                    <span>A person who is receiving medical care, or who is cared for by a <br></br>particular doctor or dentist when necessary.!</span>
                  </div>
                }

              </div>
            </Grid>
        <Grid item xs={12} sm={7}>
          <h3 style={{ paddingRight: '500px' }}>Sign Up</h3>
          <Grid container>
            <Grid item xs={12} sm={3}></Grid>
            <Grid item xs={12} sm={6}>
              <form style={{ width: '100%' }}>
                <div style={{ width: '100%' }}>
                  <Stepper activeStep={this.state.activeStep} orientation="vertical">
                    {this.state.steps.map((label, index) => (
                      <Step key={label}>
                        <StepLabel><span style={{fontWeight:'bold', fontSize:'1.1em'}}>{label}</span></StepLabel>
                        <StepContent>
                          {/*<Typography>{this.getStepContent(index)}</Typography>*/}
                          {index === 0 ?
                            <div>
                              <Grid container spacing={3}>
                                <Grid item xs={12}>
                                  <p style={{ float: "left", color: "rgba(0, 0, 0, 0.54)" }}>Choose user type*</p>
                                  <FormControl component="fieldset">
                                    <RadioGroup aria-label="gender" name="loginType" value={this.state.loginType} id="loginType" onChange={(event) => this.handleChange(event)}>
                                      <Grid container>
                                        <Grid item xs={12} sm={4}>
                                          <FormControlLabel value="caregiver" style={{ opacity: this.state.loginType === 'caregiver' ? 1 : 0.5 }} control={<Radio color="primary" />}
                                            label={
                                              <img src="assets/caregiver1.jpg" alt="Caregiver" width="70" height="70" />
                                            } />
                                        </Grid>
                                        <Grid item xs={12} sm={4}>
                                          <FormControlLabel value="provider" style={{ opacity: this.state.loginType === 'provider' ? 1 : 0.5 }} control={<Radio color="primary" />}
                                            label={
                                              <img src="assets/doctor.png" alt="Provider" width="70" height="70" />
                                            } />
                                        </Grid>
                                        <Grid item xs={12} sm={4}>
                                          <FormControlLabel value="patient" style={{ opacity: this.state.loginType === 'patient' ? 1 : 0.5 }} control={<Radio color="primary"  />}
                                            label={
                                              <img src="assets/patientRadio.jpg" alt="Patient"width="70" height="70" />
                                            } />
                                        </Grid>
                                      </Grid>
                                    </RadioGroup>
                                  </FormControl>
                                </Grid>
                                <Grid item xs={12}>
                                  <TextField
                                    fullWidth
                                    id="username"
                                    label="User Name*"
                                    name="username"
                                    autoComplete="off"
                                    value={this.state.username}
                                    error={this.state.usernameError}
                                    helperText={this.state.usernameErrorText}
                                    onChange={(event) => this.handleChange(event)}
                                  />
                                </Grid>
                                <Grid item xs={12}>
                                  <Link href="#" onClick={(event) => this.navigateToLogin(event)} style={{ float: 'left' }} variant="body2">
                                    Already have an account? Sign in
                                  </Link>
                                </Grid>
                                <Grid item xs={12} sm={4}>
                                  <Button
                                    type="button"
                                    fullWidth
                                    id="signUp"
                                    variant="contained"
                                    color="primary"
                                    onClick={this.createUserId}
                                  >
                                    Sign up
                                  </Button>
                                </Grid>
                                <Grid item xs={12} sm={1}></Grid>
                                <Grid item xs={12} sm={4}>
                                  <Button
                                    type="button"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    onClick={(event) => this.navigateToLogin(event)}
                                  >
                                    Cancel
                                  </Button>
                                </Grid>
                              </Grid>
                            </div>
                            :
                            <div>
                              {index === 1 ?
                                <div>
                                  <Grid container spacing={2}>
                                    <Grid item xs={12} sm={6}>
                                      <TextField
                                        autoComplete="off"
                                        name="firstName"
                                        fullWidth
                                        id="firstName"
                                        label="First Name*"
                                        autoFocus
                                        value={this.state.firstName}
                                        error={this.state.firstNameError}
                                        helperText={this.state.firstNameErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                      <TextField
                                        fullWidth
                                        id="lastName"
                                        label="Last Name*"
                                        name="lastName"
                                        autoComplete="off"
                                        value={this.state.lastName}
                                        error={this.state.lastNameError}
                                        helperText={this.state.lastNameErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        id="email"
                                        label="Email Address*"
                                        name="email"
                                        autoComplete="off"
                                        value={this.state.email}
                                        error={this.state.emailError}
                                        helperText={this.state.emailErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        id="phoneNumber"
                                        label="Phone Number*"
                                        name="phoneNumber"
                                        autoComplete="off"
                                        value={this.state.phoneNumber}
                                        error={this.state.phoneNumberError}
                                        helperText={this.state.phoneNumberErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        name="address1"
                                        label="Address Line 1*"
                                        type="text"
                                        id="address1"
                                        autoComplete="off"
                                        value={this.state.address1}
                                        error={this.state.address1Error}
                                        helperText={this.state.address1ErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        name="address2"
                                        label="Address Line 2*"
                                        type="text"
                                        id="address2"
                                        autoComplete="off"
                                        value={this.state.address2}
                                        error={this.state.address2Error}
                                        helperText={this.state.address2ErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        name="city"
                                        label="City*"
                                        type="text"
                                        id="city"
                                        autoComplete="off"
                                        value={this.state.city}
                                        error={this.state.cityError}
                                        helperText={this.state.cityErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        name="state"
                                        label="State*"
                                        type="text"
                                        id="state"
                                        autoComplete="off"
                                        value={this.state.state}
                                        error={this.state.stateError}
                                        helperText={this.state.stateErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      <TextField
                                        fullWidth
                                        name="zip"
                                        label="Zip*"
                                        type="text"
                                        id="zip"
                                        autoComplete="off"
                                        value={this.state.zip}
                                        error={this.state.zipError}
                                        helperText={this.state.zipErrorText}
                                        onChange={(event) => this.handleChange(event)}
                                      />
                                    </Grid>
                                    <Grid item xs={12}>
                                      {this.state.loginType === 'patient' ?
                                        <Grid container spacing={2}>
                                          <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="memberOrganization"
                                              label="Member Organization*"
                                              type="text"
                                              id="memberOrganization"
                                              autoComplete="off"
                                              value={this.state.memberOrganization}
                                              error={this.state.memberOrganizationError}
                                              helperText={this.state.memberOrganizationErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                          <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="memberId"
                                              label="Member ID*"
                                              type="text"
                                              id="memberId"
                                              autoComplete="off"
                                              value={this.state.memberId}
                                              error={this.state.memberIdError}
                                              helperText={this.state.memberIdErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                          <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="providerId"
                                              label="Provider Id"
                                              type="text"
                                              id="providerId"
                                              autoComplete="off"
                                              value={this.state.providerId}
                                              //error={this.state.providerIdError}
                                              //helperText={this.state.providerIdErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                          {/*<Grid item xs={12}>
                                            <FormControl>
                                              <InputLabel id="providerId">Provider Id*</InputLabel>
                                              <Select
                                                margin="normal"
                                                style={{ width: '385px' }}
                                                fullWidth
                                                name="providerId"
                                                labelId="providerId"
                                                id="providerId"
                                                error={this.state.providerIdError}
                                                helperText={this.state.providerIdErrorText}
                                                value={this.state.providerId}
                                                onChange={(event) => this.handleProviderIdChange(event)}
                                              >
                                                <MenuItem value=''></MenuItem>
                                                  {
                                                    [...this.state.providerMap].map(([key, value]) => {
                                                      return <MenuItem key={key} value={value.userId}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                    })
                                                  }
                                                </Select>
                                              </FormControl>
                                            </Grid>*/}
                                            <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="providerName"
                                              label="Provider Name"
                                              type="text"
                                              id="providerName"
                                              autoComplete="off"
                                              value={this.state.providerName}
                                              //error={this.state.providerNameError}
                                              //helperText={this.state.providerNameErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                          <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="caregiverId"
                                              label="Caregiver Id"
                                              type="text"
                                              id="caregiverId"
                                              autoComplete="off"
                                              value={this.state.caregiverId}
                                              //error={this.state.caregiverIdError}
                                              //helperText={this.state.caregiverIdErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                          {/*<Grid item xs={12}>
                                            <FormControl>
                                              <InputLabel id="caregiverId">Caregiver Id*</InputLabel>
                                              <Select
                                                margin="normal"
                                                style={{ width: '385px' }}
                                                fullWidth
                                                name="caregiverId"
                                                labelId="caregiverId"
                                                id="caregiverId"
                                                value={this.state.caregiverId}
                                                error={this.state.caregiverIdError}
                                                helperText={this.state.caregiverIdErrorText}
                                                onChange={(event) => this.handleCaregiverIdChange(event)}
                                              >
                                                <MenuItem value=''></MenuItem>
                                                  {
                                                    [...this.state.caregiverMap].map(([key, value]) => {
                                                      return <MenuItem key={key} value={value.userId}>{value.person.personFirstName}&nbsp;{value.person.personLastName}</MenuItem>
                                                    })
                                                  }
                                              </Select>
                                            </FormControl>
                                          </Grid>*/}
                                          <Grid item xs={12}>
                                            <TextField
                                              fullWidth
                                              name="caregiverName"
                                              label="Caregiver Name"
                                              type="text"
                                              id="caregiverName"
                                              autoComplete="off"
                                              value={this.state.caregiverName}
                                              //error={this.state.caregiverNameError}
                                              //helperText={this.state.caregiverNameErrorText}
                                              onChange={(event) => this.handleChange(event)}
                                            />
                                          </Grid>
                                        </Grid>
                                        :
                                        this.state.loginType === 'provider' ?
                                          <div>
                                            <Grid container spacing={2}>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="providerType"
                                                  label="Provider Type*"
                                                  type="text"
                                                  id="providerType"
                                                  autoComplete="off"
                                                  value={this.state.providerType}
                                                  error={this.state.providerTypeError}
                                                  helperText={this.state.providerTypeErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionName"
                                                  label="Institution Name*"
                                                  type="text"
                                                  id="institutionName"
                                                  autoComplete="off"
                                                  value={this.state.institutionName}
                                                  error={this.state.institutionNameError}
                                                  helperText={this.state.institutionNameErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionPhone"
                                                  label="Institution Phone*"
                                                  type="text"
                                                  id="institutionPhone"
                                                  autoComplete="off"
                                                  value={this.state.institutionPhone}
                                                  error={this.state.institutionPhoneError}
                                                  helperText={this.state.institutionPhoneErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionEmail"
                                                  label="Institution Email*"
                                                  type="email"
                                                  id="institutionEmail"
                                                  autoComplete="off"
                                                  value={this.state.institutionEmail}
                                                  error={this.state.institutionEmailError}
                                                  helperText={this.state.institutionEmailErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionAddress1"
                                                  label="Institution Address 1*"
                                                  type="text"
                                                  id="institutionAddress1"
                                                  autoComplete="off"
                                                  value={this.state.institutionAddress1}
                                                  error={this.state.institutionAddress1Error}
                                                  helperText={this.state.institutionAddress1ErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionAddress2"
                                                  label="Institution Address 2*"
                                                  type="text"
                                                  id="institutionAddress2"
                                                  autoComplete="off"
                                                  value={this.state.institutionAddress2}
                                                  error={this.state.institutionAddress2Error}
                                                  helperText={this.state.institutionAddress2ErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionCity"
                                                  label="Institution City*"
                                                  type="text"
                                                  id="institutionCity"
                                                  autoComplete="off"
                                                  value={this.state.institutionCity}
                                                  error={this.state.institutionCityError}
                                                  helperText={this.state.institutionCityErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionState"
                                                  label="Institution State*"
                                                  type="text"
                                                  id="institutionState"
                                                  autoComplete="off"
                                                  value={this.state.institutionState}
                                                  error={this.state.institutionStateError}
                                                  helperText={this.state.institutionStateErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  name="institutionZip"
                                                  label="Institution ZIP*"
                                                  type="text"
                                                  id="institutionZip"
                                                  autoComplete="off"
                                                  value={this.state.institutionZip}
                                                  error={this.state.institutionZipError}
                                                  helperText={this.state.institutionZipErrorText}
                                                  onChange={(event) => this.handleChange(event)}
                                                />
                                              </Grid>
                                            </Grid>
                                          </div>
                                          :
                                          <div>
                                          </div>
                                      }
                                    </Grid>
                                    <Grid container>
                                    <Grid item xs={12} sm={1}></Grid>
                                      <Grid item xs={12} sm={4}>
                                        <Button
                                          type="button"
                                          id="update"
                                          fullWidth
                                          variant="contained"
                                          color="primary"
                                          onClick={(event) => this.handleSubmit(event)}
                                        >
                                          Update
                                        </Button>
                                      </Grid>
                                      <Grid item xs={12} sm={1}></Grid>
                                      <Grid item xs={12} sm={5}>
                                        <Button
                                          type="button"
                                          fullWidth
                                          variant="contained"
                                          color="primary"
                                          onClick={(event) => this.navigateToLogin(event)}
                                        >
                                          Update later
                                        </Button>
                                      </Grid>
                                    </Grid>
                                  </Grid>
                                </div>
                                :
                                <div>
                                  <div>
                                    <Grid container>
                                      User details successfully updated..! Click&nbsp;
                                      <Link href="#" style={{paddingTop: '3px'}} onClick={(event) => this.navigateToLogin(event)} variant="body2">
                                        Login
                                      </Link> &nbsp; to go to Login page.
                                    </Grid>
                                  </div>
                                </div>
                              }
                            </div>
                          }
                          {/*<div>
                            <Button
                              disabled={this.state.activeStep === 0}
                              onClick={this.handleBack}
                            >
                              Back
                            </Button>
                            <Button
                              variant="contained"
                              color="primary"
                              onClick={this.handleNext}
                            >
                              {this.state.activeStep === this.state.steps.length - 1 ? 'Finish' : 'Next'}
                            </Button>
                          </div>*/}
                        </StepContent>
                      </Step>
                    ))}
                  </Stepper>
                </div>
              </form>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      </CardContent>
      </Card>
    );
  }
}

export default Signup;