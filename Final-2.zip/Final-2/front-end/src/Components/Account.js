import React, { useState } from 'react';
import moment from 'moment';
import {
    Container,
    Grid,
    makeStyles,
    Box,
    Avatar,
    Button,
    Card,
    CardActions,
    CardContent,
    Divider,
    TextField,
    Typography
} from '@material-ui/core';
import { getUserDetailsAsState } from '../utils/helper';
import { updateUserAPI } from "../utils/service";
import { useSelector, useDispatch } from 'react-redux';

const useStyles = makeStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.background.dark,
        minHeight: '100%',
        paddingBottom: theme.spacing(3),
        paddingTop: theme.spacing(3)
    },
    avatar: {
        height: 100,
        width: 100
    }
}));

const Account = (props) => {
    props.parentCallback(true, true);
    const classes = useStyles();
    const dispatch = useDispatch();
    const userState = useSelector((state)=>state.user);
    const userType = userState.userType;
    const [user, setUser] = useState(getUserDetailsAsState(userState));

    const handleChange = (event) => {
        setUser({
            ...user,
            [event.target.name]: event.target.value
        });
    };

    const updateUserDetails = (event) => {
        event.preventDefault();
        props.spinnerLoader(true);
        alert(user.providerType);
        updateUserAPI({
                class: userState.class,
                key: userState.key,
                currentState: userState.currentState,
                "memberId": user.memberId,
                "memberOrganization": user.memberOrganization,
                "providerID": user.providerId,
                "providerName": user.providerName,
                "providerType": user.providerType,
                "caregiverID": user.caregiverId,
                "caregiverName": user.caregiverName,
                "personEmail": user.email,
                "personPhone": user.phoneNumber,
                "personFirstName": user.firstName,
                "personLastName": user.lastName,
                "personAddress1": user.address1,
                "personAddress2": user.address2,
                "personCity": user.city,
                "personState": user.state,
                "personZip": user.zip,
                "institutionName": user.institutionName,
                "institutionPhone": user.institutionPhone,
                "institutionEmail": user.institutionEmail,
                "insAddress1": user.institutionAddress1,
                "insAddress2": user.institutionAddress2,
                "insCity": user.institutionCity,
                "insState": user.institutionState,
                "insZip": user.institutionZip,
                userId: userState.userID
            }, userType)
            .then(results =>{ 
                props.spinnerLoader(false);
                alert('Account details updated successfully..!');
                console.log('response', results);
                results.data.userType = userType;
                dispatch({type: 'UPDATE', payload : {user: results.data}});
                setUser(getUserDetailsAsState(results.data));
            });
    }

    return (
        <Container maxWidth="lg" style={{ paddingTop: '10px' }}>
            <Grid
                container
                spacing={3}
            >
                <Grid
                    item
                    lg={4}
                    md={6}
                    xs={12}
                >
                    <Card>
                        <CardContent>
                            <Box
                                alignItems="center"
                                display="flex"
                                flexDirection="column"
                            >
                                <Avatar
                                    className={classes.avatar}
                                    src='assets/image.jpg'
                                />
                                <Typography
                                    color="textPrimary"
                                    gutterBottom
                                    variant="h5"
                                >
                                    {user.username}
                                </Typography>
                                <Typography
                                    color="textSecondary"
                                    variant="body1"
                                >
                                    {`${user.city}, ${user.state}`}
                                </Typography>
                                <Typography
                                    className={classes.dateText}
                                    color="textSecondary"
                                    variant="body1"
                                >
                                    {`${moment().format('hh:mm A')}`}
                                </Typography>
                            </Box>
                        </CardContent>
                        <Divider />
                        <CardActions>
                            <Button
                                color="primary"
                                fullWidth
                                variant="text"
                            >
                                Upload picture
                            </Button>
                        </CardActions>
                    </Card>
                </Grid>
                <Grid
                    item
                    lg={8}
                    md={6}
                    xs={12}
                >
                    <form
                        autoComplete="off"
                        onSubmit={updateUserDetails}
                    >
                        <Card>
                            <CardContent>
                                <div style={{ float: 'left', fontSize: '1.0125rem', fontWeight: '500' }}>Profile</div><br />
                                <div style={{ float: 'left', fontWeight: '400', color: '#546e7a' }}>The information can be edited</div><br />
                            </CardContent>
                            <Divider />
                            <CardContent>
                                <Grid
                                    container
                                    spacing={1}
                                >
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="First name"
                                            name="firstName"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.firstName}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Last name"
                                            name="lastName"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.lastName}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Username"
                                            name="username"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            type="text"
                                            value={user.username}
                                            disabled={true}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Email Address"
                                            name="email"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.email}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Phone Number"
                                            name="phoneNumber"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            type="text"
                                            value={user.phoneNumber}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Address Line 1"
                                            name="address1"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.address1}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Address Line 2"
                                            name="address2"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.address2}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="City"
                                            name="city"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.city}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="State"
                                            name="state"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.state}
                                            variant="outlined"
                                        />
                                    </Grid>
                                    <Grid
                                        item
                                        md={6}
                                        xs={12}
                                    >
                                        <TextField
                                            fullWidth
                                            label="Zip"
                                            name="zip"
                                            margin="dense"
                                            onChange={handleChange}
                                            required
                                            value={user.zip}
                                            variant="outlined"
                                        />
                                    </Grid>
                                </Grid>
                                {userType === 'patient' ?
                                    (<Grid container spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                fullWidth
                                                name="memberOrganization"
                                                label="Member Organization"
                                                type="text"
                                                id="memberOrganization"
                                                margin="dense"
                                                onChange={handleChange}
                                                required
                                                value={user.memberOrganization}
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                fullWidth
                                                name="memberId"
                                                label="Member ID"
                                                type="text"
                                                id="memberId"
                                                margin="dense"
                                                onChange={handleChange}
                                                required
                                                value={user.memberId}
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                fullWidth
                                                name="patientId"
                                                label="Patient ID"
                                                type="text"
                                                id="patientId"
                                                margin="dense"
                                                onChange={handleChange}
                                                required
                                                disabled
                                                value={user.patientId}
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                fullWidth
                                                name="caregiverId"
                                                label="Caregiver ID"
                                                type="text"
                                                id="caregiverId"
                                                margin="dense"
                                                onChange={handleChange}
                                                required
                                                value={user.caregiverId}
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                fullWidth
                                                name="caregiverName"
                                                label="Caregiver Name"
                                                type="text"
                                                id="caregiverName"
                                                margin="dense"
                                                onChange={handleChange}
                                                required
                                                value={user.caregiverName}
                                                variant="outlined"
                                            />
                                        </Grid>
                                    </Grid>
                                    )
                                    :
                                    userType === 'provider' ?
                                        <Grid container spacing={1}>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="providerId"
                                                    label="Provider ID"
                                                    type="text"
                                                    id="providerId"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    disabled
                                                    value={user.providerId}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="providerType"
                                                    label="Provider Type"
                                                    type="text"
                                                    id="providerType"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.providerType}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionName"
                                                    label="Institution Name"
                                                    type="text"
                                                    id="institutionName"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionName}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionPhone"
                                                    label="Institution Phone"
                                                    type="text"
                                                    id="institutionPhone"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionPhone}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionEmail"
                                                    label="Institution Email"
                                                    type="email"
                                                    id="institutionEmail"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionEmail}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionAddress1"
                                                    label="Institution Address 1"
                                                    type="text"
                                                    id="institutionAddress1"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionAddress1}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionAddress2"
                                                    label="Institution Address 2"
                                                    type="text"
                                                    id="institutionAddress2"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionAddress2}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionCity"
                                                    label="Institution City"
                                                    type="text"
                                                    id="institutionCity"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionCity}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionState"
                                                    label="Institution State"
                                                    type="text"
                                                    id="institutionState"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionState}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                            <Grid item xs={12} md={6}>
                                                <TextField
                                                    fullWidth
                                                    name="institutionZip"
                                                    label="Institution ZIP"
                                                    type="text"
                                                    id="institutionZip"
                                                    margin="dense"
                                                    onChange={handleChange}
                                                    required
                                                    value={user.institutionZip}
                                                    variant="outlined"
                                                />
                                            </Grid>
                                        </Grid>
                                        :
                                        <div>
                                        </div>
                                }
                            </CardContent>
                            <Divider />
                            <Box
                                display="flex"
                                justifyContent="flex-end"
                                p={2}
                            >
                                <Button
                                    color="primary"
                                    type="submit"
                                    variant="contained"
                                >
                                    Save details
                                </Button>
                            </Box>
                        </Card>
                    </form>
                </Grid>
            </Grid>
        </Container>
    );
};

export default Account;